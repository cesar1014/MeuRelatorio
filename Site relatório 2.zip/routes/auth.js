export function registerAuthRoutes(app, deps) {
  const {
    sendLoginFile,
    getAuthSessionFromRequest,
    getRolePermissions,
    getAllowedProjectsFromSession,
    getProjectCodeFromSession,
    getProjectSummaries,
    isProjectSelectionRequired,
    getProjectName,
    getProjectBrandName,
    parseJsonBody,
    isLoginRateLimited,
    authenticateUser,
    registerLoginAttempt,
    createAuthSession,
    setActiveProjectForSession,
    setAuthCookie,
    writeAuditLog,
    removeAuthSessionByRequest,
    clearAuthCookie,
  } = deps;

  function buildAuthResponse(session, extra = {}) {
    const permissions = getRolePermissions(session?.role);
    const activeProjectCode = getProjectCodeFromSession(session);
    const requiresProjectSelection = isProjectSelectionRequired(session);
    const allowedProjects = getProjectSummaries(getAllowedProjectsFromSession(session));

    return {
      authenticated: true,
      username: String(session?.username ?? ""),
      role: permissions.role,
      permissions,
      allowedProjects,
      requiresProjectSelection,
      projectCode: activeProjectCode,
      activeProjectCode,
      projectName: activeProjectCode ? getProjectName(activeProjectCode) : "",
      projectBrandName: activeProjectCode ? getProjectBrandName(activeProjectCode) : "",
      expiresAt: Number.isFinite(Number(session?.expiresAt))
        ? new Date(Number(session.expiresAt)).toISOString()
        : null,
      ...extra,
    };
  }

  app.get("/login", (req, res) => {
    sendLoginFile(req, res);
  });

  app.get("/login.html", (_req, res) => {
    res.redirect("/login");
  });

  app.get("/api/auth/status", (req, res) => {
    const session = getAuthSessionFromRequest(req);
    if (!session) {
      res.json({ authenticated: false });
      return;
    }

    res.json(buildAuthResponse(session));
  });

  app.post("/api/auth/login", async (req, res) => {
    const body = parseJsonBody(req, res);
    if (!body) return;

    const username = String(body.username ?? "").trim();
    const password = String(body.password ?? "");
    if (isLoginRateLimited(req, username)) {
      res.status(429).json({
        error: "Muitas tentativas de login. Aguarde alguns minutos e tente novamente.",
      });
      return;
    }

    const authenticatedAccount = authenticateUser(username, password);
    if (!authenticatedAccount) {
      registerLoginAttempt(req, username, false);
      res.status(401).json({ error: "Credenciais inválidas." });
      return;
    }

    registerLoginAttempt(req, username, true);
    const created = await createAuthSession(authenticatedAccount);
    if (!created?.token || !created?.session) {
      res.status(500).json({ error: "Falha ao iniciar sessao." });
      return;
    }

    req._authSessionCache = created.session;
    setAuthCookie(req, res, created.token);
    await writeAuditLog(req, "auth.login", "session", created.session.sessionId, null, {
      username: created.session.username,
      role: created.session.role,
    });

    res.json({
      ok: true,
      ...buildAuthResponse(created.session),
    });
  });

  app.post("/api/auth/active-project", async (req, res) => {
    const session = getAuthSessionFromRequest(req);
    if (!session) {
      res.status(401).json({ error: "Não autenticado. Faça login para continuar." });
      return;
    }

    const body = parseJsonBody(req, res);
    if (!body) return;
    const projectCode = String(body.projectCode ?? "").trim();
    if (!projectCode) {
      res.status(400).json({ error: "Informe o codigo do projeto." });
      return;
    }

    const updated = await setActiveProjectForSession(session.sessionId, projectCode);
    if (!updated?.session || !updated?.token) {
      res.status(403).json({ error: "Projeto inválido ou sem permissão para o usuário." });
      return;
    }

    req._authSessionCache = updated.session;
    setAuthCookie(req, res, updated.token);
    await writeAuditLog(req, "auth.active_project.update", "session", updated.session.sessionId, {
      previousProjectCode: getProjectCodeFromSession(session),
    }, {
      activeProjectCode: getProjectCodeFromSession(updated.session),
    });

    res.json({
      ok: true,
      ...buildAuthResponse(updated.session),
    });
  });

  app.post("/api/auth/logout", async (req, res) => {
    const session = getAuthSessionFromRequest(req);
    await removeAuthSessionByRequest(req);
    clearAuthCookie(req, res);
    if (session) {
      await writeAuditLog(req, "auth.logout", "session", session.sessionId, {
        username: session.username,
        role: session.role,
      }, null);
    }
    res.json({ ok: true });
  });
}
