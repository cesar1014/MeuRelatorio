import React, { useCallback, useEffect, useMemo, useState } from "react";
import { AlertCircle, X } from "lucide-react";
import { createTopico, deleteTopico, getAuthStatus, getTopicos, updateTopico } from "./api.js";
import { subscribeThemeChange } from "./theme.js";
import ConfigHeader from "./components/ConfigHeader.jsx";
import ConfigFiltersCard from "./components/ConfigFiltersCard.jsx";
import ConfigBudgetCard from "./components/ConfigBudgetCard.jsx";
import ConfigTopicsTable from "./components/ConfigTopicsTable.jsx";

const ALL_GROUPS_VALUE = "Todos";
const DEFAULT_GROUP_KEYS = ["TEAM HIRES", "COMMUNICATIONS & PUBLICATIONS", "THIRD PARTY SERVICES"];
const GROUP_LABELS_PT = {
  "TEAM HIRES": "Contratações da Equipe",
  "COMMUNICATIONS & PUBLICATIONS": "Comunicação e Publicações",
  "THIRD PARTY SERVICES": "Serviços de Terceiros",
};

function getGroupLabelPt(groupName) {
  return GROUP_LABELS_PT[groupName] || groupName || "Sem grupo";
}

function normalizeTopico(item) {
  return {
    id: String(item?.id ?? ""),
    nome: String(item?.nome ?? ""),
    grupo: String(item?.grupo ?? ""),
    orcamentoProgramaBRL: Number(item?.orcamentoProgramaBRL ?? 0),
    incluirNoResumo: Boolean(item?.incluirNoResumo),
    permitirLancamento: Boolean(item?.permitirLancamento),
    permitirLancamentoEfetivo: Boolean(item?.permitirLancamentoEfetivo),
  };
}

function buildDraftMap(topicos) {
  const entries = {};
  for (const topic of topicos) {
    entries[topic.id] = {
      nome: topic.nome,
      orcamentoProgramaBRL: String(Number(topic.orcamentoProgramaBRL ?? 0)),
      incluirNoResumo: Boolean(topic.incluirNoResumo),
      permitirLancamento: Boolean(topic.permitirLancamento),
    };
  }
  return entries;
}

function parseBudget(value) {
  const parsed = Number(String(value ?? "").replace(",", "."));
  if (!Number.isFinite(parsed)) return NaN;
  return parsed;
}

function formatCurrency(value) {
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
  }).format(Number(value ?? 0));
}

function addSetValue(currentSet, value) {
  const next = new Set(currentSet);
  next.add(value);
  return next;
}

function removeSetValue(currentSet, value) {
  const next = new Set(currentSet);
  next.delete(value);
  return next;
}

export default function ConfigApp({ onError }) {
  const [isDark, setIsDark] = useState(() => document.body.classList.contains("theme-dark"));
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [auth, setAuth] = useState(null);
  const [topics, setTopics] = useState([]);
  const [drafts, setDrafts] = useState({});
  const [filterGroup, setFilterGroup] = useState(ALL_GROUPS_VALUE);
  const [isEditMode, setIsEditMode] = useState(false);
  const [savingIds, setSavingIds] = useState(new Set());
  const [deletingIds, setDeletingIds] = useState(new Set());
  const [isCreating, setIsCreating] = useState(false);
  const [showCreatePanel, setShowCreatePanel] = useState(false);
  const [newTopic, setNewTopic] = useState({
    nome: "",
    grupo: "COMMUNICATIONS & PUBLICATIONS",
    orcamentoProgramaBRL: "0",
    incluirNoResumo: true,
    permitirLancamento: true,
  });

  const canManageConfig = Boolean(auth?.permissions?.canManageConfig);

  const emitTopicsChanged = useCallback(() => {
    window.dispatchEvent(new CustomEvent("config:topics-changed"));
  }, []);

  const pushError = useCallback(
    (message) => {
      const finalMessage = String(message || "Falha ao processar requisição.");
      setError(finalMessage);
      if (typeof onError === "function") {
        onError(finalMessage);
      }
    },
    [onError]
  );

  const loadTopics = useCallback(async () => {
    const payload = await getTopicos();
    const normalized = Array.isArray(payload) ? payload.map(normalizeTopico) : [];
    setTopics(normalized);
    setDrafts(buildDraftMap(normalized));
    return normalized;
  }, []);

  const loadAuth = useCallback(async () => {
    const status = await getAuthStatus();
    if (!status?.authenticated) {
      window.location.href = "/login";
      return null;
    }
    setAuth(status);
    return status;
  }, []);

  useEffect(() => {
    let active = true;
    (async () => {
      try {
        setLoading(true);
        await Promise.all([loadAuth(), loadTopics()]);
      } catch (loadError) {
        if (!active) return;
        pushError(loadError?.message || "Falha ao carregar dados da configuracao.");
      } finally {
        if (active) setLoading(false);
      }
    })();

    return () => {
      active = false;
    };
  }, [loadAuth, loadTopics, pushError]);

  useEffect(() => {
    const unsubscribe = subscribeThemeChange(setIsDark);
    return unsubscribe;
  }, []);

  useEffect(() => {
    if (!canManageConfig) {
      setIsEditMode(false);
      setShowCreatePanel(false);
    }
  }, [canManageConfig]);

  useEffect(() => {
    if (!error) return () => {};
    const timer = setTimeout(() => setError(""), 3600);
    return () => clearTimeout(timer);
  }, [error]);

  useEffect(() => {
    if (!notice) return () => {};
    const timer = setTimeout(() => setNotice(""), 2400);
    return () => clearTimeout(timer);
  }, [notice]);

  const groups = useMemo(() => {
    const map = new Map(DEFAULT_GROUP_KEYS.map((group) => [group, getGroupLabelPt(group)]));
    for (const topic of topics) {
      if (!topic.grupo) continue;
      map.set(topic.grupo, getGroupLabelPt(topic.grupo));
    }
    return [
      { value: ALL_GROUPS_VALUE, label: "Todos os Macro-Tópicos" },
      ...[...map.entries()]
        .sort((a, b) => a[1].localeCompare(b[1]))
        .map(([value, label]) => ({ value, label })),
    ];
  }, [topics]);

  const filteredTopics = useMemo(() => {
    if (filterGroup === ALL_GROUPS_VALUE) return topics;
    return topics.filter((topic) => topic.grupo === filterGroup);
  }, [topics, filterGroup]);

  const totalBudget = useMemo(() => {
    return filteredTopics.reduce((sum, topic) => {
      const draft = drafts[topic.id];
      const fallback = Number(topic.orcamentoProgramaBRL ?? 0);
      const value = draft ? parseBudget(draft.orcamentoProgramaBRL) : fallback;
      return sum + (Number.isFinite(value) ? value : fallback);
    }, 0);
  }, [filteredTopics, drafts]);

  const selectedFilterLabel =
    groups.find((group) => group.value === filterGroup)?.label || "Todos os Macro-Tópicos";

  const onFieldChange = useCallback((topicId, field, value) => {
    setDrafts((current) => ({
      ...current,
      [topicId]: {
        ...(current[topicId] || {}),
        [field]: value,
      },
    }));
  }, []);

  const onToggleField = useCallback((topicId, field) => {
    setDrafts((current) => ({
      ...current,
      [topicId]: {
        ...(current[topicId] || {}),
        [field]: !Boolean(current?.[topicId]?.[field]),
      },
    }));
  }, []);

  const onSaveTopic = useCallback(
    async (topicId) => {
      if (!canManageConfig || !isEditMode) return;
      const draft = drafts[topicId];
      if (!draft) return;

      const nome = String(draft.nome ?? "").trim();
      if (!nome) {
        pushError("Nome do tópico é obrigatório.");
        return;
      }

      const orcamento = parseBudget(draft.orcamentoProgramaBRL);
      if (!Number.isFinite(orcamento) || orcamento < 0) {
        pushError("Orçamento inválido.");
        return;
      }

      setSavingIds((current) => addSetValue(current, topicId));
      try {
        await updateTopico(topicId, {
          nome,
          orcamentoProgramaBRL: orcamento,
          incluirNoResumo: Boolean(draft.incluirNoResumo),
          permitirLancamento: Boolean(draft.permitirLancamento),
        });
        await loadTopics();
        emitTopicsChanged();
        setNotice("Tópico atualizado com sucesso.");
      } catch (saveError) {
        pushError(saveError?.message || "Falha ao atualizar tópico.");
      } finally {
        setSavingIds((current) => removeSetValue(current, topicId));
      }
    },
    [canManageConfig, drafts, emitTopicsChanged, isEditMode, loadTopics, pushError]
  );

  const onDeleteTopic = useCallback(
    async (topicId) => {
      if (!canManageConfig || !isEditMode) return;

      const topic = topics.find((item) => item.id === topicId);
      const topicLabel = topic?.nome || topicId;
      const confirmed = window.confirm(`Deseja remover o tópico "${topicLabel}"? Esta ação não pode ser desfeita.`);
      if (!confirmed) return;

      setDeletingIds((current) => addSetValue(current, topicId));
      try {
        await deleteTopico(topicId);
        await loadTopics();
        emitTopicsChanged();
        setNotice("Tópico removido com sucesso.");
      } catch (deleteError) {
        pushError(deleteError?.message || "Falha ao remover tópico.");
      } finally {
        setDeletingIds((current) => removeSetValue(current, topicId));
      }
    },
    [canManageConfig, emitTopicsChanged, isEditMode, loadTopics, pushError, topics]
  );

  const openCreatePanel = useCallback(() => {
    if (!canManageConfig || !isEditMode) {
      pushError("Ative o modo edição para acrescentar tópicos.");
      return;
    }
    const suggestedGroup = filterGroup !== ALL_GROUPS_VALUE ? filterGroup : topics[0]?.grupo || "COMMUNICATIONS & PUBLICATIONS";
    setNewTopic({
      nome: "",
      grupo: suggestedGroup,
      orcamentoProgramaBRL: "0",
      incluirNoResumo: true,
      permitirLancamento: suggestedGroup !== "TEAM HIRES",
    });
    setShowCreatePanel(true);
  }, [canManageConfig, filterGroup, isEditMode, pushError, topics]);

  const closeCreatePanel = useCallback(() => {
    setShowCreatePanel(false);
  }, []);

  const onCreateFieldChange = useCallback((field, value) => {
    setNewTopic((current) => {
      if (field === "grupo") {
        const shouldAllowLaunch = value !== "TEAM HIRES";
        return {
          ...current,
          grupo: value,
          permitirLancamento: shouldAllowLaunch ? current.permitirLancamento : false,
        };
      }
      return {
        ...current,
        [field]: value,
      };
    });
  }, []);

  const onCreateSubmit = useCallback(
    async (event) => {
      event.preventDefault();
      if (!canManageConfig || !isEditMode) {
        pushError("Ative o modo edição para salvar tópicos.");
        return;
      }

      const nome = String(newTopic.nome ?? "").trim();
      const grupo = String(newTopic.grupo ?? "").trim();
      const orcamento = parseBudget(newTopic.orcamentoProgramaBRL);

      if (!nome) {
        pushError("Nome do tópico é obrigatório.");
        return;
      }
      if (!grupo) {
        pushError("Grupo do tópico é obrigatório.");
        return;
      }
      if (!Number.isFinite(orcamento) || orcamento < 0) {
        pushError("Orçamento inválido.");
        return;
      }

      setIsCreating(true);
      try {
        const created = await createTopico({
          nome,
          grupo,
          orcamentoProgramaBRL: orcamento,
          incluirNoResumo: Boolean(newTopic.incluirNoResumo),
          permitirLancamento: Boolean(newTopic.permitirLancamento),
        });
        setFilterGroup(created?.grupo || grupo);
        setShowCreatePanel(false);
        await loadTopics();
        emitTopicsChanged();
        setNotice("Tópico criado com sucesso.");
      } catch (createError) {
        pushError(createError?.message || "Falha ao criar tópico.");
      } finally {
        setIsCreating(false);
      }
    },
    [canManageConfig, emitTopicsChanged, isEditMode, loadTopics, newTopic, pushError]
  );

  if (loading) {
    return (
      <div className={`config-react-scope rounded-2xl border p-6 ${
        isDark ? "border-slate-800/60 bg-slate-900/45 text-slate-300" : "border-slate-200 bg-white text-slate-700"
      }`}>
        Carregando configurações...
      </div>
    );
  }

  return (
    <div className={`config-react-scope space-y-6 ${isDark ? "text-slate-200" : "text-slate-900"}`}>
      <ConfigHeader
        canManageConfig={canManageConfig}
        isEditMode={isEditMode}
        onToggleEditMode={() => setIsEditMode((current) => !current)}
        onOpenCreateModal={openCreatePanel}
        isDark={isDark}
      />

      {error ? (
        <div
          className={`flex items-start gap-2 rounded-xl border px-4 py-3 text-sm ${
            isDark ? "border-rose-500/40 bg-rose-500/10 text-rose-200" : "border-rose-300 bg-rose-50 text-rose-700"
          }`}
        >
          <AlertCircle size={16} className="mt-0.5 shrink-0" />
          <span>{error}</span>
        </div>
      ) : null}

      {notice ? (
        <div
          className={`rounded-xl border px-4 py-3 text-sm ${
            isDark ? "border-emerald-400/40 bg-emerald-500/10 text-emerald-200" : "border-emerald-300 bg-emerald-50 text-emerald-700"
          }`}
        >
          {notice}
        </div>
      ) : null}

      {showCreatePanel ? (
        <div
          className={`rounded-2xl border p-5 shadow-xl ${
            isDark ? "border-slate-800/60 bg-slate-900/45" : "border-slate-200 bg-white"
          }`}
        >
          <div className="mb-4 flex items-center justify-between">
            <h4 className="text-lg font-bold">Novo tópico</h4>
            <button
              type="button"
              onClick={closeCreatePanel}
              className={`inline-flex h-8 w-8 items-center justify-center rounded-lg transition-colors ${
                isDark ? "text-slate-400 hover:bg-slate-800 hover:text-slate-200" : "text-slate-500 hover:bg-slate-100 hover:text-slate-800"
              }`}
            >
              <X size={16} />
            </button>
          </div>
          <form className="grid gap-3 md:grid-cols-2" onSubmit={onCreateSubmit}>
            <label className="flex flex-col gap-1 text-sm font-semibold">
              Nome do tópico
              <input
                type="text"
                value={newTopic.nome}
                onChange={(event) => onCreateFieldChange("nome", event.target.value)}
                className={`rounded-lg border px-3 py-2 outline-none transition-all ${
                  isDark
                    ? "border-slate-700 bg-slate-950/45 text-slate-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500/60"
                    : "border-slate-300 bg-white text-slate-900 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500/40"
                }`}
                required
              />
            </label>

            <label className="flex flex-col gap-1 text-sm font-semibold">
              Grupo
              <select
                value={newTopic.grupo}
                onChange={(event) => onCreateFieldChange("grupo", event.target.value)}
                className={`rounded-lg border px-3 py-2 outline-none transition-all ${
                  isDark
                    ? "border-slate-700 bg-slate-950/45 text-slate-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500/60"
                    : "border-slate-300 bg-white text-slate-900 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500/40"
                }`}
              >
                {groups
                  .filter((group) => group.value !== ALL_GROUPS_VALUE)
                  .map((group) => (
                    <option key={group.value} value={group.value}>
                      {group.label}
                    </option>
                  ))}
              </select>
            </label>

            <label className="flex flex-col gap-1 text-sm font-semibold">
              Orçamento (BRL)
              <input
                type="number"
                min="0"
                step="0.01"
                value={newTopic.orcamentoProgramaBRL}
                onChange={(event) => onCreateFieldChange("orcamentoProgramaBRL", event.target.value)}
                className={`rounded-lg border px-3 py-2 outline-none transition-all ${
                  isDark
                    ? "border-slate-700 bg-slate-950/45 text-slate-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500/60"
                    : "border-slate-300 bg-white text-slate-900 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500/40"
                }`}
              />
            </label>

            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
              <label className="inline-flex items-center gap-2 text-sm font-semibold">
                <input
                  type="checkbox"
                  checked={newTopic.incluirNoResumo}
                  onChange={(event) => onCreateFieldChange("incluirNoResumo", event.target.checked)}
                />
                Incluir no resumo
              </label>
              <label className="inline-flex items-center gap-2 text-sm font-semibold">
                <input
                  type="checkbox"
                  checked={newTopic.permitirLancamento}
                  onChange={(event) => onCreateFieldChange("permitirLancamento", event.target.checked)}
                  disabled={newTopic.grupo === "TEAM HIRES"}
                />
                Lançamento ativo
              </label>
            </div>

            <div className="col-span-full flex justify-end gap-2 pt-1">
              <button
                type="button"
                onClick={closeCreatePanel}
                className={`rounded-lg border px-4 py-2 text-sm font-semibold ${
                  isDark
                    ? "border-slate-700 text-slate-300 hover:bg-slate-800"
                    : "border-slate-300 text-slate-700 hover:bg-slate-100"
                }`}
              >
                Cancelar
              </button>
              <button
                type="submit"
                disabled={isCreating}
                className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white hover:bg-indigo-500 disabled:cursor-not-allowed disabled:opacity-60"
              >
                {isCreating ? "Salvando..." : "Criar tópico"}
              </button>
            </div>
          </form>
        </div>
      ) : null}

      <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
        <ConfigFiltersCard
          filterGroup={filterGroup}
          groups={groups}
          onChangeFilter={setFilterGroup}
          isDark={isDark}
        />
        <ConfigBudgetCard
          totalBudget={totalBudget}
          formatCurrency={formatCurrency}
          filterLabel={filterGroup === ALL_GROUPS_VALUE ? "Geral" : selectedFilterLabel}
          isDark={isDark}
        />
      </div>

      <ConfigTopicsTable
        filteredTopics={filteredTopics}
        drafts={drafts}
        filterLabel={selectedFilterLabel}
        isEditMode={isEditMode}
        canManageConfig={canManageConfig}
        isDark={isDark}
        savingIds={savingIds}
        deletingIds={deletingIds}
        getGroupLabel={getGroupLabelPt}
        onFieldChange={onFieldChange}
        onToggleField={onToggleField}
        onSaveTopic={onSaveTopic}
        onDeleteTopic={onDeleteTopic}
      />

      <div
        className={`flex flex-col items-center justify-between gap-4 rounded-xl border px-4 py-3 text-xs font-semibold sm:flex-row ${
          isDark ? "border-slate-800/60 bg-slate-950/35 text-slate-400" : "border-slate-200 bg-slate-50 text-slate-500"
        }`}
      >
        <div className="inline-flex items-center gap-2 rounded-full border border-amber-500/30 bg-amber-500/10 px-3 py-1.5 text-amber-500/90">
          <AlertCircle size={14} />
          <span>As alterações ficam pendentes até clicar em salvar.</span>
        </div>
        <span>
          A mostrar {filteredTopics.length} de {topics.length} tópicos
        </span>
      </div>
    </div>
  );
}
