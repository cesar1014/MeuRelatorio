import React from "react";
import EmptyState from "./EmptyState.jsx";
import ConfigTopicRow from "./ConfigTopicRow.jsx";

export default function ConfigTopicsTable({
  filteredTopics,
  drafts,
  filterLabel,
  isEditMode,
  canManageConfig,
  isDark,
  savingIds,
  deletingIds,
  getGroupLabel,
  onFieldChange,
  onToggleField,
  onSaveTopic,
  onDeleteTopic,
}) {
  return (
    <div
      className={`overflow-hidden rounded-2xl border shadow-2xl ${
        isDark ? "border-slate-800/60 bg-slate-900/45" : "border-slate-200 bg-white/95"
      }`}
    >
      <div className="overflow-x-auto">
        <table className="w-full border-collapse">
          <thead>
            <tr
              className={`border-b text-left text-xs font-bold uppercase tracking-[0.14em] ${
                isDark ? "border-slate-800/60 bg-slate-950/55 text-slate-400" : "border-slate-200 bg-slate-100 text-slate-500"
              }`}
            >
              <th className="whitespace-nowrap px-6 py-5">Tópico</th>
              <th className="whitespace-nowrap px-6 py-5">Grupo</th>
              <th className="whitespace-nowrap px-6 py-5 text-right">Orçamento</th>
              <th className="whitespace-nowrap px-6 py-5 text-center">No Resumo</th>
              <th className="whitespace-nowrap px-6 py-5 text-center">Lançamento</th>
              <th className="whitespace-nowrap px-6 py-5 text-right">Ações</th>
            </tr>
          </thead>

          <tbody className={isDark ? "divide-y divide-slate-800/55" : "divide-y divide-slate-200"}>
            {filteredTopics.length === 0 ? (
              <EmptyState filterLabel={filterLabel} isDark={isDark} />
            ) : (
              filteredTopics.map((topic) => (
                <ConfigTopicRow
                  key={topic.id}
                  topic={topic}
                  draft={drafts[topic.id]}
                  isEditMode={isEditMode}
                  canManageConfig={canManageConfig}
                  isDark={isDark}
                  isSaving={savingIds.has(topic.id)}
                  isDeleting={deletingIds.has(topic.id)}
                  getGroupLabel={getGroupLabel}
                  onFieldChange={onFieldChange}
                  onToggleField={onToggleField}
                  onSave={onSaveTopic}
                  onDelete={onDeleteTopic}
                />
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
