var sf = { exports: {} }, Au = {};
var Sd;
function uy() {
  if (Sd) return Au;
  Sd = 1;
  var g = /* @__PURE__ */ Symbol.for("react.transitional.element"), x = /* @__PURE__ */ Symbol.for("react.fragment");
  function _(r, H, G) {
    var nl = null;
    if (G !== void 0 && (nl = "" + G), H.key !== void 0 && (nl = "" + H.key), "key" in H) {
      G = {};
      for (var cl in H)
        cl !== "key" && (G[cl] = H[cl]);
    } else G = H;
    return H = G.ref, {
      $$typeof: g,
      type: r,
      key: nl,
      ref: H !== void 0 ? H : null,
      props: G
    };
  }
  return Au.Fragment = x, Au.jsx = _, Au.jsxs = _, Au;
}
var pd;
function ny() {
  return pd || (pd = 1, sf.exports = uy()), sf.exports;
}
var A = ny(), of = { exports: {} }, L = {};
var Td;
function iy() {
  if (Td) return L;
  Td = 1;
  var g = /* @__PURE__ */ Symbol.for("react.transitional.element"), x = /* @__PURE__ */ Symbol.for("react.portal"), _ = /* @__PURE__ */ Symbol.for("react.fragment"), r = /* @__PURE__ */ Symbol.for("react.strict_mode"), H = /* @__PURE__ */ Symbol.for("react.profiler"), G = /* @__PURE__ */ Symbol.for("react.consumer"), nl = /* @__PURE__ */ Symbol.for("react.context"), cl = /* @__PURE__ */ Symbol.for("react.forward_ref"), U = /* @__PURE__ */ Symbol.for("react.suspense"), E = /* @__PURE__ */ Symbol.for("react.memo"), w = /* @__PURE__ */ Symbol.for("react.lazy"), j = /* @__PURE__ */ Symbol.for("react.activity"), P = Symbol.iterator;
  function rl(o) {
    return o === null || typeof o != "object" ? null : (o = P && o[P] || o["@@iterator"], typeof o == "function" ? o : null);
  }
  var _l = {
    isMounted: function() {
      return !1;
    },
    enqueueForceUpdate: function() {
    },
    enqueueReplaceState: function() {
    },
    enqueueSetState: function() {
    }
  }, Sl = Object.assign, gt = {};
  function zl(o, z, O) {
    this.props = o, this.context = z, this.refs = gt, this.updater = O || _l;
  }
  zl.prototype.isReactComponent = {}, zl.prototype.setState = function(o, z) {
    if (typeof o != "object" && typeof o != "function" && o != null)
      throw Error(
        "takes an object of state variables to update or a function which returns an object of state variables."
      );
    this.updater.enqueueSetState(this, o, z, "setState");
  }, zl.prototype.forceUpdate = function(o) {
    this.updater.enqueueForceUpdate(this, o, "forceUpdate");
  };
  function Ut() {
  }
  Ut.prototype = zl.prototype;
  function Yl(o, z, O) {
    this.props = o, this.context = z, this.refs = gt, this.updater = O || _l;
  }
  var Il = Yl.prototype = new Ut();
  Il.constructor = Yl, Sl(Il, zl.prototype), Il.isPureReactComponent = !0;
  var bt = Array.isArray;
  function Ll() {
  }
  var $ = { H: null, A: null, T: null, S: null }, Zl = Object.prototype.hasOwnProperty;
  function St(o, z, O) {
    var C = O.ref;
    return {
      $$typeof: g,
      type: o,
      key: z,
      ref: C !== void 0 ? C : null,
      props: O
    };
  }
  function Dt(o, z) {
    return St(o.type, z, o.props);
  }
  function Al(o) {
    return typeof o == "object" && o !== null && o.$$typeof === g;
  }
  function Vl(o) {
    var z = { "=": "=0", ":": "=2" };
    return "$" + o.replace(/[=:]/g, function(O) {
      return z[O];
    });
  }
  var Cl = /\/+/g;
  function kl(o, z) {
    return typeof o == "object" && o !== null && o.key != null ? Vl("" + o.key) : z.toString(36);
  }
  function ml(o) {
    switch (o.status) {
      case "fulfilled":
        return o.value;
      case "rejected":
        throw o.reason;
      default:
        switch (typeof o.status == "string" ? o.then(Ll, Ll) : (o.status = "pending", o.then(
          function(z) {
            o.status === "pending" && (o.status = "fulfilled", o.value = z);
          },
          function(z) {
            o.status === "pending" && (o.status = "rejected", o.reason = z);
          }
        )), o.status) {
          case "fulfilled":
            return o.value;
          case "rejected":
            throw o.reason;
        }
    }
    throw o;
  }
  function b(o, z, O, C, Q) {
    var K = typeof o;
    (K === "undefined" || K === "boolean") && (o = null);
    var al = !1;
    if (o === null) al = !0;
    else
      switch (K) {
        case "bigint":
        case "string":
        case "number":
          al = !0;
          break;
        case "object":
          switch (o.$$typeof) {
            case g:
            case x:
              al = !0;
              break;
            case w:
              return al = o._init, b(
                al(o._payload),
                z,
                O,
                C,
                Q
              );
          }
      }
    if (al)
      return Q = Q(o), al = C === "" ? "." + kl(o, 0) : C, bt(Q) ? (O = "", al != null && (O = al.replace(Cl, "$&/") + "/"), b(Q, z, O, "", function(M) {
        return M;
      })) : Q != null && (Al(Q) && (Q = Dt(
        Q,
        O + (Q.key == null || o && o.key === Q.key ? "" : ("" + Q.key).replace(
          Cl,
          "$&/"
        ) + "/") + al
      )), z.push(Q)), 1;
    al = 0;
    var Ol = C === "" ? "." : C + ":";
    if (bt(o))
      for (var xl = 0; xl < o.length; xl++)
        C = o[xl], K = Ol + kl(C, xl), al += b(
          C,
          z,
          O,
          K,
          Q
        );
    else if (xl = rl(o), typeof xl == "function")
      for (o = xl.call(o), xl = 0; !(C = o.next()).done; )
        C = C.value, K = Ol + kl(C, xl++), al += b(
          C,
          z,
          O,
          K,
          Q
        );
    else if (K === "object") {
      if (typeof o.then == "function")
        return b(
          ml(o),
          z,
          O,
          C,
          Q
        );
      throw z = String(o), Error(
        "Objects are not valid as a React child (found: " + (z === "[object Object]" ? "object with keys {" + Object.keys(o).join(", ") + "}" : z) + "). If you meant to render a collection of children, use an array instead."
      );
    }
    return al;
  }
  function N(o, z, O) {
    if (o == null) return o;
    var C = [], Q = 0;
    return b(o, C, "", "", function(K) {
      return z.call(O, K, Q++);
    }), C;
  }
  function q(o) {
    if (o._status === -1) {
      var z = o._result;
      z = z(), z.then(
        function(O) {
          (o._status === 0 || o._status === -1) && (o._status = 1, o._result = O);
        },
        function(O) {
          (o._status === 0 || o._status === -1) && (o._status = 2, o._result = O);
        }
      ), o._status === -1 && (o._status = 0, o._result = z);
    }
    if (o._status === 1) return o._result.default;
    throw o._result;
  }
  var tl = typeof reportError == "function" ? reportError : function(o) {
    if (typeof window == "object" && typeof window.ErrorEvent == "function") {
      var z = new window.ErrorEvent("error", {
        bubbles: !0,
        cancelable: !0,
        message: typeof o == "object" && o !== null && typeof o.message == "string" ? String(o.message) : String(o),
        error: o
      });
      if (!window.dispatchEvent(z)) return;
    } else if (typeof process == "object" && typeof process.emit == "function") {
      process.emit("uncaughtException", o);
      return;
    }
    console.error(o);
  }, fl = {
    map: N,
    forEach: function(o, z, O) {
      N(
        o,
        function() {
          z.apply(this, arguments);
        },
        O
      );
    },
    count: function(o) {
      var z = 0;
      return N(o, function() {
        z++;
      }), z;
    },
    toArray: function(o) {
      return N(o, function(z) {
        return z;
      }) || [];
    },
    only: function(o) {
      if (!Al(o))
        throw Error(
          "React.Children.only expected to receive a single React element child."
        );
      return o;
    }
  };
  return L.Activity = j, L.Children = fl, L.Component = zl, L.Fragment = _, L.Profiler = H, L.PureComponent = Yl, L.StrictMode = r, L.Suspense = U, L.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = $, L.__COMPILER_RUNTIME = {
    __proto__: null,
    c: function(o) {
      return $.H.useMemoCache(o);
    }
  }, L.cache = function(o) {
    return function() {
      return o.apply(null, arguments);
    };
  }, L.cacheSignal = function() {
    return null;
  }, L.cloneElement = function(o, z, O) {
    if (o == null)
      throw Error(
        "The argument must be a React element, but you passed " + o + "."
      );
    var C = Sl({}, o.props), Q = o.key;
    if (z != null)
      for (K in z.key !== void 0 && (Q = "" + z.key), z)
        !Zl.call(z, K) || K === "key" || K === "__self" || K === "__source" || K === "ref" && z.ref === void 0 || (C[K] = z[K]);
    var K = arguments.length - 2;
    if (K === 1) C.children = O;
    else if (1 < K) {
      for (var al = Array(K), Ol = 0; Ol < K; Ol++)
        al[Ol] = arguments[Ol + 2];
      C.children = al;
    }
    return St(o.type, Q, C);
  }, L.createContext = function(o) {
    return o = {
      $$typeof: nl,
      _currentValue: o,
      _currentValue2: o,
      _threadCount: 0,
      Provider: null,
      Consumer: null
    }, o.Provider = o, o.Consumer = {
      $$typeof: G,
      _context: o
    }, o;
  }, L.createElement = function(o, z, O) {
    var C, Q = {}, K = null;
    if (z != null)
      for (C in z.key !== void 0 && (K = "" + z.key), z)
        Zl.call(z, C) && C !== "key" && C !== "__self" && C !== "__source" && (Q[C] = z[C]);
    var al = arguments.length - 2;
    if (al === 1) Q.children = O;
    else if (1 < al) {
      for (var Ol = Array(al), xl = 0; xl < al; xl++)
        Ol[xl] = arguments[xl + 2];
      Q.children = Ol;
    }
    if (o && o.defaultProps)
      for (C in al = o.defaultProps, al)
        Q[C] === void 0 && (Q[C] = al[C]);
    return St(o, K, Q);
  }, L.createRef = function() {
    return { current: null };
  }, L.forwardRef = function(o) {
    return { $$typeof: cl, render: o };
  }, L.isValidElement = Al, L.lazy = function(o) {
    return {
      $$typeof: w,
      _payload: { _status: -1, _result: o },
      _init: q
    };
  }, L.memo = function(o, z) {
    return {
      $$typeof: E,
      type: o,
      compare: z === void 0 ? null : z
    };
  }, L.startTransition = function(o) {
    var z = $.T, O = {};
    $.T = O;
    try {
      var C = o(), Q = $.S;
      Q !== null && Q(O, C), typeof C == "object" && C !== null && typeof C.then == "function" && C.then(Ll, tl);
    } catch (K) {
      tl(K);
    } finally {
      z !== null && O.types !== null && (z.types = O.types), $.T = z;
    }
  }, L.unstable_useCacheRefresh = function() {
    return $.H.useCacheRefresh();
  }, L.use = function(o) {
    return $.H.use(o);
  }, L.useActionState = function(o, z, O) {
    return $.H.useActionState(o, z, O);
  }, L.useCallback = function(o, z) {
    return $.H.useCallback(o, z);
  }, L.useContext = function(o) {
    return $.H.useContext(o);
  }, L.useDebugValue = function() {
  }, L.useDeferredValue = function(o, z) {
    return $.H.useDeferredValue(o, z);
  }, L.useEffect = function(o, z) {
    return $.H.useEffect(o, z);
  }, L.useEffectEvent = function(o) {
    return $.H.useEffectEvent(o);
  }, L.useId = function() {
    return $.H.useId();
  }, L.useImperativeHandle = function(o, z, O) {
    return $.H.useImperativeHandle(o, z, O);
  }, L.useInsertionEffect = function(o, z) {
    return $.H.useInsertionEffect(o, z);
  }, L.useLayoutEffect = function(o, z) {
    return $.H.useLayoutEffect(o, z);
  }, L.useMemo = function(o, z) {
    return $.H.useMemo(o, z);
  }, L.useOptimistic = function(o, z) {
    return $.H.useOptimistic(o, z);
  }, L.useReducer = function(o, z, O) {
    return $.H.useReducer(o, z, O);
  }, L.useRef = function(o) {
    return $.H.useRef(o);
  }, L.useState = function(o) {
    return $.H.useState(o);
  }, L.useSyncExternalStore = function(o, z, O) {
    return $.H.useSyncExternalStore(
      o,
      z,
      O
    );
  }, L.useTransition = function() {
    return $.H.useTransition();
  }, L.version = "19.2.4", L;
}
var zd;
function gf() {
  return zd || (zd = 1, of.exports = iy()), of.exports;
}
var J = gf(), df = { exports: {} }, xu = {}, rf = { exports: {} }, mf = {};
var Ed;
function cy() {
  return Ed || (Ed = 1, (function(g) {
    function x(b, N) {
      var q = b.length;
      b.push(N);
      l: for (; 0 < q; ) {
        var tl = q - 1 >>> 1, fl = b[tl];
        if (0 < H(fl, N))
          b[tl] = N, b[q] = fl, q = tl;
        else break l;
      }
    }
    function _(b) {
      return b.length === 0 ? null : b[0];
    }
    function r(b) {
      if (b.length === 0) return null;
      var N = b[0], q = b.pop();
      if (q !== N) {
        b[0] = q;
        l: for (var tl = 0, fl = b.length, o = fl >>> 1; tl < o; ) {
          var z = 2 * (tl + 1) - 1, O = b[z], C = z + 1, Q = b[C];
          if (0 > H(O, q))
            C < fl && 0 > H(Q, O) ? (b[tl] = Q, b[C] = q, tl = C) : (b[tl] = O, b[z] = q, tl = z);
          else if (C < fl && 0 > H(Q, q))
            b[tl] = Q, b[C] = q, tl = C;
          else break l;
        }
      }
      return N;
    }
    function H(b, N) {
      var q = b.sortIndex - N.sortIndex;
      return q !== 0 ? q : b.id - N.id;
    }
    if (g.unstable_now = void 0, typeof performance == "object" && typeof performance.now == "function") {
      var G = performance;
      g.unstable_now = function() {
        return G.now();
      };
    } else {
      var nl = Date, cl = nl.now();
      g.unstable_now = function() {
        return nl.now() - cl;
      };
    }
    var U = [], E = [], w = 1, j = null, P = 3, rl = !1, _l = !1, Sl = !1, gt = !1, zl = typeof setTimeout == "function" ? setTimeout : null, Ut = typeof clearTimeout == "function" ? clearTimeout : null, Yl = typeof setImmediate < "u" ? setImmediate : null;
    function Il(b) {
      for (var N = _(E); N !== null; ) {
        if (N.callback === null) r(E);
        else if (N.startTime <= b)
          r(E), N.sortIndex = N.expirationTime, x(U, N);
        else break;
        N = _(E);
      }
    }
    function bt(b) {
      if (Sl = !1, Il(b), !_l)
        if (_(U) !== null)
          _l = !0, Ll || (Ll = !0, Vl());
        else {
          var N = _(E);
          N !== null && ml(bt, N.startTime - b);
        }
    }
    var Ll = !1, $ = -1, Zl = 5, St = -1;
    function Dt() {
      return gt ? !0 : !(g.unstable_now() - St < Zl);
    }
    function Al() {
      if (gt = !1, Ll) {
        var b = g.unstable_now();
        St = b;
        var N = !0;
        try {
          l: {
            _l = !1, Sl && (Sl = !1, Ut($), $ = -1), rl = !0;
            var q = P;
            try {
              t: {
                for (Il(b), j = _(U); j !== null && !(j.expirationTime > b && Dt()); ) {
                  var tl = j.callback;
                  if (typeof tl == "function") {
                    j.callback = null, P = j.priorityLevel;
                    var fl = tl(
                      j.expirationTime <= b
                    );
                    if (b = g.unstable_now(), typeof fl == "function") {
                      j.callback = fl, Il(b), N = !0;
                      break t;
                    }
                    j === _(U) && r(U), Il(b);
                  } else r(U);
                  j = _(U);
                }
                if (j !== null) N = !0;
                else {
                  var o = _(E);
                  o !== null && ml(
                    bt,
                    o.startTime - b
                  ), N = !1;
                }
              }
              break l;
            } finally {
              j = null, P = q, rl = !1;
            }
            N = void 0;
          }
        } finally {
          N ? Vl() : Ll = !1;
        }
      }
    }
    var Vl;
    if (typeof Yl == "function")
      Vl = function() {
        Yl(Al);
      };
    else if (typeof MessageChannel < "u") {
      var Cl = new MessageChannel(), kl = Cl.port2;
      Cl.port1.onmessage = Al, Vl = function() {
        kl.postMessage(null);
      };
    } else
      Vl = function() {
        zl(Al, 0);
      };
    function ml(b, N) {
      $ = zl(function() {
        b(g.unstable_now());
      }, N);
    }
    g.unstable_IdlePriority = 5, g.unstable_ImmediatePriority = 1, g.unstable_LowPriority = 4, g.unstable_NormalPriority = 3, g.unstable_Profiling = null, g.unstable_UserBlockingPriority = 2, g.unstable_cancelCallback = function(b) {
      b.callback = null;
    }, g.unstable_forceFrameRate = function(b) {
      0 > b || 125 < b ? console.error(
        "forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"
      ) : Zl = 0 < b ? Math.floor(1e3 / b) : 5;
    }, g.unstable_getCurrentPriorityLevel = function() {
      return P;
    }, g.unstable_next = function(b) {
      switch (P) {
        case 1:
        case 2:
        case 3:
          var N = 3;
          break;
        default:
          N = P;
      }
      var q = P;
      P = N;
      try {
        return b();
      } finally {
        P = q;
      }
    }, g.unstable_requestPaint = function() {
      gt = !0;
    }, g.unstable_runWithPriority = function(b, N) {
      switch (b) {
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
          break;
        default:
          b = 3;
      }
      var q = P;
      P = b;
      try {
        return N();
      } finally {
        P = q;
      }
    }, g.unstable_scheduleCallback = function(b, N, q) {
      var tl = g.unstable_now();
      switch (typeof q == "object" && q !== null ? (q = q.delay, q = typeof q == "number" && 0 < q ? tl + q : tl) : q = tl, b) {
        case 1:
          var fl = -1;
          break;
        case 2:
          fl = 250;
          break;
        case 5:
          fl = 1073741823;
          break;
        case 4:
          fl = 1e4;
          break;
        default:
          fl = 5e3;
      }
      return fl = q + fl, b = {
        id: w++,
        callback: N,
        priorityLevel: b,
        startTime: q,
        expirationTime: fl,
        sortIndex: -1
      }, q > tl ? (b.sortIndex = q, x(E, b), _(U) === null && b === _(E) && (Sl ? (Ut($), $ = -1) : Sl = !0, ml(bt, q - tl))) : (b.sortIndex = fl, x(U, b), _l || rl || (_l = !0, Ll || (Ll = !0, Vl()))), b;
    }, g.unstable_shouldYield = Dt, g.unstable_wrapCallback = function(b) {
      var N = P;
      return function() {
        var q = P;
        P = N;
        try {
          return b.apply(this, arguments);
        } finally {
          P = q;
        }
      };
    };
  })(mf)), mf;
}
var Ad;
function fy() {
  return Ad || (Ad = 1, rf.exports = cy()), rf.exports;
}
var yf = { exports: {} }, Fl = {};
var xd;
function sy() {
  if (xd) return Fl;
  xd = 1;
  var g = gf();
  function x(U) {
    var E = "https://react.dev/errors/" + U;
    if (1 < arguments.length) {
      E += "?args[]=" + encodeURIComponent(arguments[1]);
      for (var w = 2; w < arguments.length; w++)
        E += "&args[]=" + encodeURIComponent(arguments[w]);
    }
    return "Minified React error #" + U + "; visit " + E + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
  }
  function _() {
  }
  var r = {
    d: {
      f: _,
      r: function() {
        throw Error(x(522));
      },
      D: _,
      C: _,
      L: _,
      m: _,
      X: _,
      S: _,
      M: _
    },
    p: 0,
    findDOMNode: null
  }, H = /* @__PURE__ */ Symbol.for("react.portal");
  function G(U, E, w) {
    var j = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
    return {
      $$typeof: H,
      key: j == null ? null : "" + j,
      children: U,
      containerInfo: E,
      implementation: w
    };
  }
  var nl = g.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;
  function cl(U, E) {
    if (U === "font") return "";
    if (typeof E == "string")
      return E === "use-credentials" ? E : "";
  }
  return Fl.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = r, Fl.createPortal = function(U, E) {
    var w = 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
    if (!E || E.nodeType !== 1 && E.nodeType !== 9 && E.nodeType !== 11)
      throw Error(x(299));
    return G(U, E, null, w);
  }, Fl.flushSync = function(U) {
    var E = nl.T, w = r.p;
    try {
      if (nl.T = null, r.p = 2, U) return U();
    } finally {
      nl.T = E, r.p = w, r.d.f();
    }
  }, Fl.preconnect = function(U, E) {
    typeof U == "string" && (E ? (E = E.crossOrigin, E = typeof E == "string" ? E === "use-credentials" ? E : "" : void 0) : E = null, r.d.C(U, E));
  }, Fl.prefetchDNS = function(U) {
    typeof U == "string" && r.d.D(U);
  }, Fl.preinit = function(U, E) {
    if (typeof U == "string" && E && typeof E.as == "string") {
      var w = E.as, j = cl(w, E.crossOrigin), P = typeof E.integrity == "string" ? E.integrity : void 0, rl = typeof E.fetchPriority == "string" ? E.fetchPriority : void 0;
      w === "style" ? r.d.S(
        U,
        typeof E.precedence == "string" ? E.precedence : void 0,
        {
          crossOrigin: j,
          integrity: P,
          fetchPriority: rl
        }
      ) : w === "script" && r.d.X(U, {
        crossOrigin: j,
        integrity: P,
        fetchPriority: rl,
        nonce: typeof E.nonce == "string" ? E.nonce : void 0
      });
    }
  }, Fl.preinitModule = function(U, E) {
    if (typeof U == "string")
      if (typeof E == "object" && E !== null) {
        if (E.as == null || E.as === "script") {
          var w = cl(
            E.as,
            E.crossOrigin
          );
          r.d.M(U, {
            crossOrigin: w,
            integrity: typeof E.integrity == "string" ? E.integrity : void 0,
            nonce: typeof E.nonce == "string" ? E.nonce : void 0
          });
        }
      } else E == null && r.d.M(U);
  }, Fl.preload = function(U, E) {
    if (typeof U == "string" && typeof E == "object" && E !== null && typeof E.as == "string") {
      var w = E.as, j = cl(w, E.crossOrigin);
      r.d.L(U, w, {
        crossOrigin: j,
        integrity: typeof E.integrity == "string" ? E.integrity : void 0,
        nonce: typeof E.nonce == "string" ? E.nonce : void 0,
        type: typeof E.type == "string" ? E.type : void 0,
        fetchPriority: typeof E.fetchPriority == "string" ? E.fetchPriority : void 0,
        referrerPolicy: typeof E.referrerPolicy == "string" ? E.referrerPolicy : void 0,
        imageSrcSet: typeof E.imageSrcSet == "string" ? E.imageSrcSet : void 0,
        imageSizes: typeof E.imageSizes == "string" ? E.imageSizes : void 0,
        media: typeof E.media == "string" ? E.media : void 0
      });
    }
  }, Fl.preloadModule = function(U, E) {
    if (typeof U == "string")
      if (E) {
        var w = cl(E.as, E.crossOrigin);
        r.d.m(U, {
          as: typeof E.as == "string" && E.as !== "script" ? E.as : void 0,
          crossOrigin: w,
          integrity: typeof E.integrity == "string" ? E.integrity : void 0
        });
      } else r.d.m(U);
  }, Fl.requestFormReset = function(U) {
    r.d.r(U);
  }, Fl.unstable_batchedUpdates = function(U, E) {
    return U(E);
  }, Fl.useFormState = function(U, E, w) {
    return nl.H.useFormState(U, E, w);
  }, Fl.useFormStatus = function() {
    return nl.H.useHostTransitionStatus();
  }, Fl.version = "19.2.4", Fl;
}
var _d;
function oy() {
  if (_d) return yf.exports;
  _d = 1;
  function g() {
    if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function"))
      try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(g);
      } catch (x) {
        console.error(x);
      }
  }
  return g(), yf.exports = sy(), yf.exports;
}
var Nd;
function dy() {
  if (Nd) return xu;
  Nd = 1;
  var g = fy(), x = gf(), _ = oy();
  function r(l) {
    var t = "https://react.dev/errors/" + l;
    if (1 < arguments.length) {
      t += "?args[]=" + encodeURIComponent(arguments[1]);
      for (var a = 2; a < arguments.length; a++)
        t += "&args[]=" + encodeURIComponent(arguments[a]);
    }
    return "Minified React error #" + l + "; visit " + t + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
  }
  function H(l) {
    return !(!l || l.nodeType !== 1 && l.nodeType !== 9 && l.nodeType !== 11);
  }
  function G(l) {
    var t = l, a = l;
    if (l.alternate) for (; t.return; ) t = t.return;
    else {
      l = t;
      do
        t = l, (t.flags & 4098) !== 0 && (a = t.return), l = t.return;
      while (l);
    }
    return t.tag === 3 ? a : null;
  }
  function nl(l) {
    if (l.tag === 13) {
      var t = l.memoizedState;
      if (t === null && (l = l.alternate, l !== null && (t = l.memoizedState)), t !== null) return t.dehydrated;
    }
    return null;
  }
  function cl(l) {
    if (l.tag === 31) {
      var t = l.memoizedState;
      if (t === null && (l = l.alternate, l !== null && (t = l.memoizedState)), t !== null) return t.dehydrated;
    }
    return null;
  }
  function U(l) {
    if (G(l) !== l)
      throw Error(r(188));
  }
  function E(l) {
    var t = l.alternate;
    if (!t) {
      if (t = G(l), t === null) throw Error(r(188));
      return t !== l ? null : l;
    }
    for (var a = l, e = t; ; ) {
      var u = a.return;
      if (u === null) break;
      var n = u.alternate;
      if (n === null) {
        if (e = u.return, e !== null) {
          a = e;
          continue;
        }
        break;
      }
      if (u.child === n.child) {
        for (n = u.child; n; ) {
          if (n === a) return U(u), l;
          if (n === e) return U(u), t;
          n = n.sibling;
        }
        throw Error(r(188));
      }
      if (a.return !== e.return) a = u, e = n;
      else {
        for (var i = !1, c = u.child; c; ) {
          if (c === a) {
            i = !0, a = u, e = n;
            break;
          }
          if (c === e) {
            i = !0, e = u, a = n;
            break;
          }
          c = c.sibling;
        }
        if (!i) {
          for (c = n.child; c; ) {
            if (c === a) {
              i = !0, a = n, e = u;
              break;
            }
            if (c === e) {
              i = !0, e = n, a = u;
              break;
            }
            c = c.sibling;
          }
          if (!i) throw Error(r(189));
        }
      }
      if (a.alternate !== e) throw Error(r(190));
    }
    if (a.tag !== 3) throw Error(r(188));
    return a.stateNode.current === a ? l : t;
  }
  function w(l) {
    var t = l.tag;
    if (t === 5 || t === 26 || t === 27 || t === 6) return l;
    for (l = l.child; l !== null; ) {
      if (t = w(l), t !== null) return t;
      l = l.sibling;
    }
    return null;
  }
  var j = Object.assign, P = /* @__PURE__ */ Symbol.for("react.element"), rl = /* @__PURE__ */ Symbol.for("react.transitional.element"), _l = /* @__PURE__ */ Symbol.for("react.portal"), Sl = /* @__PURE__ */ Symbol.for("react.fragment"), gt = /* @__PURE__ */ Symbol.for("react.strict_mode"), zl = /* @__PURE__ */ Symbol.for("react.profiler"), Ut = /* @__PURE__ */ Symbol.for("react.consumer"), Yl = /* @__PURE__ */ Symbol.for("react.context"), Il = /* @__PURE__ */ Symbol.for("react.forward_ref"), bt = /* @__PURE__ */ Symbol.for("react.suspense"), Ll = /* @__PURE__ */ Symbol.for("react.suspense_list"), $ = /* @__PURE__ */ Symbol.for("react.memo"), Zl = /* @__PURE__ */ Symbol.for("react.lazy"), St = /* @__PURE__ */ Symbol.for("react.activity"), Dt = /* @__PURE__ */ Symbol.for("react.memo_cache_sentinel"), Al = Symbol.iterator;
  function Vl(l) {
    return l === null || typeof l != "object" ? null : (l = Al && l[Al] || l["@@iterator"], typeof l == "function" ? l : null);
  }
  var Cl = /* @__PURE__ */ Symbol.for("react.client.reference");
  function kl(l) {
    if (l == null) return null;
    if (typeof l == "function")
      return l.$$typeof === Cl ? null : l.displayName || l.name || null;
    if (typeof l == "string") return l;
    switch (l) {
      case Sl:
        return "Fragment";
      case zl:
        return "Profiler";
      case gt:
        return "StrictMode";
      case bt:
        return "Suspense";
      case Ll:
        return "SuspenseList";
      case St:
        return "Activity";
    }
    if (typeof l == "object")
      switch (l.$$typeof) {
        case _l:
          return "Portal";
        case Yl:
          return l.displayName || "Context";
        case Ut:
          return (l._context.displayName || "Context") + ".Consumer";
        case Il:
          var t = l.render;
          return l = l.displayName, l || (l = t.displayName || t.name || "", l = l !== "" ? "ForwardRef(" + l + ")" : "ForwardRef"), l;
        case $:
          return t = l.displayName || null, t !== null ? t : kl(l.type) || "Memo";
        case Zl:
          t = l._payload, l = l._init;
          try {
            return kl(l(t));
          } catch {
          }
      }
    return null;
  }
  var ml = Array.isArray, b = x.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, N = _.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, q = {
    pending: !1,
    data: null,
    method: null,
    action: null
  }, tl = [], fl = -1;
  function o(l) {
    return { current: l };
  }
  function z(l) {
    0 > fl || (l.current = tl[fl], tl[fl] = null, fl--);
  }
  function O(l, t) {
    fl++, tl[fl] = l.current, l.current = t;
  }
  var C = o(null), Q = o(null), K = o(null), al = o(null);
  function Ol(l, t) {
    switch (O(K, t), O(Q, l), O(C, null), t.nodeType) {
      case 9:
      case 11:
        l = (l = t.documentElement) && (l = l.namespaceURI) ? L0(l) : 0;
        break;
      default:
        if (l = t.tagName, t = t.namespaceURI)
          t = L0(t), l = Z0(t, l);
        else
          switch (l) {
            case "svg":
              l = 1;
              break;
            case "math":
              l = 2;
              break;
            default:
              l = 0;
          }
    }
    z(C), O(C, l);
  }
  function xl() {
    z(C), z(Q), z(K);
  }
  function M(l) {
    l.memoizedState !== null && O(al, l);
    var t = C.current, a = Z0(t, l.type);
    t !== a && (O(Q, l), O(C, a));
  }
  function X(l) {
    Q.current === l && (z(C), z(Q)), al.current === l && (z(al), pu._currentValue = q);
  }
  var sl, Gl;
  function yl(l) {
    if (sl === void 0)
      try {
        throw Error();
      } catch (a) {
        var t = a.stack.trim().match(/\n( *(at )?)/);
        sl = t && t[1] || "", Gl = -1 < a.stack.indexOf(`
    at`) ? " (<anonymous>)" : -1 < a.stack.indexOf("@") ? "@unknown:0:0" : "";
      }
    return `
` + sl + l + Gl;
  }
  var Kn = !1;
  function Jn(l, t) {
    if (!l || Kn) return "";
    Kn = !0;
    var a = Error.prepareStackTrace;
    Error.prepareStackTrace = void 0;
    try {
      var e = {
        DetermineComponentFrameRoot: function() {
          try {
            if (t) {
              var T = function() {
                throw Error();
              };
              if (Object.defineProperty(T.prototype, "props", {
                set: function() {
                  throw Error();
                }
              }), typeof Reflect == "object" && Reflect.construct) {
                try {
                  Reflect.construct(T, []);
                } catch (h) {
                  var v = h;
                }
                Reflect.construct(l, [], T);
              } else {
                try {
                  T.call();
                } catch (h) {
                  v = h;
                }
                l.call(T.prototype);
              }
            } else {
              try {
                throw Error();
              } catch (h) {
                v = h;
              }
              (T = l()) && typeof T.catch == "function" && T.catch(function() {
              });
            }
          } catch (h) {
            if (h && v && typeof h.stack == "string")
              return [h.stack, v.stack];
          }
          return [null, null];
        }
      };
      e.DetermineComponentFrameRoot.displayName = "DetermineComponentFrameRoot";
      var u = Object.getOwnPropertyDescriptor(
        e.DetermineComponentFrameRoot,
        "name"
      );
      u && u.configurable && Object.defineProperty(
        e.DetermineComponentFrameRoot,
        "name",
        { value: "DetermineComponentFrameRoot" }
      );
      var n = e.DetermineComponentFrameRoot(), i = n[0], c = n[1];
      if (i && c) {
        var f = i.split(`
`), y = c.split(`
`);
        for (u = e = 0; e < f.length && !f[e].includes("DetermineComponentFrameRoot"); )
          e++;
        for (; u < y.length && !y[u].includes(
          "DetermineComponentFrameRoot"
        ); )
          u++;
        if (e === f.length || u === y.length)
          for (e = f.length - 1, u = y.length - 1; 1 <= e && 0 <= u && f[e] !== y[u]; )
            u--;
        for (; 1 <= e && 0 <= u; e--, u--)
          if (f[e] !== y[u]) {
            if (e !== 1 || u !== 1)
              do
                if (e--, u--, 0 > u || f[e] !== y[u]) {
                  var S = `
` + f[e].replace(" at new ", " at ");
                  return l.displayName && S.includes("<anonymous>") && (S = S.replace("<anonymous>", l.displayName)), S;
                }
              while (1 <= e && 0 <= u);
            break;
          }
      }
    } finally {
      Kn = !1, Error.prepareStackTrace = a;
    }
    return (a = l ? l.displayName || l.name : "") ? yl(a) : "";
  }
  function Hd(l, t) {
    switch (l.tag) {
      case 26:
      case 27:
      case 5:
        return yl(l.type);
      case 16:
        return yl("Lazy");
      case 13:
        return l.child !== t && t !== null ? yl("Suspense Fallback") : yl("Suspense");
      case 19:
        return yl("SuspenseList");
      case 0:
      case 15:
        return Jn(l.type, !1);
      case 11:
        return Jn(l.type.render, !1);
      case 1:
        return Jn(l.type, !0);
      case 31:
        return yl("Activity");
      default:
        return "";
    }
  }
  function bf(l) {
    try {
      var t = "", a = null;
      do
        t += Hd(l, a), a = l, l = l.return;
      while (l);
      return t;
    } catch (e) {
      return `
Error generating stack: ` + e.message + `
` + e.stack;
    }
  }
  var wn = Object.prototype.hasOwnProperty, $n = g.unstable_scheduleCallback, Wn = g.unstable_cancelCallback, Bd = g.unstable_shouldYield, qd = g.unstable_requestPaint, ct = g.unstable_now, Yd = g.unstable_getCurrentPriorityLevel, Sf = g.unstable_ImmediatePriority, pf = g.unstable_UserBlockingPriority, Nu = g.unstable_NormalPriority, Gd = g.unstable_LowPriority, Tf = g.unstable_IdlePriority, Xd = g.log, Qd = g.unstable_setDisableYieldValue, Ce = null, ft = null;
  function ua(l) {
    if (typeof Xd == "function" && Qd(l), ft && typeof ft.setStrictMode == "function")
      try {
        ft.setStrictMode(Ce, l);
      } catch {
      }
  }
  var st = Math.clz32 ? Math.clz32 : Vd, Ld = Math.log, Zd = Math.LN2;
  function Vd(l) {
    return l >>>= 0, l === 0 ? 32 : 31 - (Ld(l) / Zd | 0) | 0;
  }
  var Mu = 256, Ou = 262144, Uu = 4194304;
  function Oa(l) {
    var t = l & 42;
    if (t !== 0) return t;
    switch (l & -l) {
      case 1:
        return 1;
      case 2:
        return 2;
      case 4:
        return 4;
      case 8:
        return 8;
      case 16:
        return 16;
      case 32:
        return 32;
      case 64:
        return 64;
      case 128:
        return 128;
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
        return l & 261888;
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return l & 3932160;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
        return l & 62914560;
      case 67108864:
        return 67108864;
      case 134217728:
        return 134217728;
      case 268435456:
        return 268435456;
      case 536870912:
        return 536870912;
      case 1073741824:
        return 0;
      default:
        return l;
    }
  }
  function Du(l, t, a) {
    var e = l.pendingLanes;
    if (e === 0) return 0;
    var u = 0, n = l.suspendedLanes, i = l.pingedLanes;
    l = l.warmLanes;
    var c = e & 134217727;
    return c !== 0 ? (e = c & ~n, e !== 0 ? u = Oa(e) : (i &= c, i !== 0 ? u = Oa(i) : a || (a = c & ~l, a !== 0 && (u = Oa(a))))) : (c = e & ~n, c !== 0 ? u = Oa(c) : i !== 0 ? u = Oa(i) : a || (a = e & ~l, a !== 0 && (u = Oa(a)))), u === 0 ? 0 : t !== 0 && t !== u && (t & n) === 0 && (n = u & -u, a = t & -t, n >= a || n === 32 && (a & 4194048) !== 0) ? t : u;
  }
  function je(l, t) {
    return (l.pendingLanes & ~(l.suspendedLanes & ~l.pingedLanes) & t) === 0;
  }
  function Kd(l, t) {
    switch (l) {
      case 1:
      case 2:
      case 4:
      case 8:
      case 64:
        return t + 250;
      case 16:
      case 32:
      case 128:
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return t + 5e3;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
        return -1;
      case 67108864:
      case 134217728:
      case 268435456:
      case 536870912:
      case 1073741824:
        return -1;
      default:
        return -1;
    }
  }
  function zf() {
    var l = Uu;
    return Uu <<= 1, (Uu & 62914560) === 0 && (Uu = 4194304), l;
  }
  function kn(l) {
    for (var t = [], a = 0; 31 > a; a++) t.push(l);
    return t;
  }
  function Re(l, t) {
    l.pendingLanes |= t, t !== 268435456 && (l.suspendedLanes = 0, l.pingedLanes = 0, l.warmLanes = 0);
  }
  function Jd(l, t, a, e, u, n) {
    var i = l.pendingLanes;
    l.pendingLanes = a, l.suspendedLanes = 0, l.pingedLanes = 0, l.warmLanes = 0, l.expiredLanes &= a, l.entangledLanes &= a, l.errorRecoveryDisabledLanes &= a, l.shellSuspendCounter = 0;
    var c = l.entanglements, f = l.expirationTimes, y = l.hiddenUpdates;
    for (a = i & ~a; 0 < a; ) {
      var S = 31 - st(a), T = 1 << S;
      c[S] = 0, f[S] = -1;
      var v = y[S];
      if (v !== null)
        for (y[S] = null, S = 0; S < v.length; S++) {
          var h = v[S];
          h !== null && (h.lane &= -536870913);
        }
      a &= ~T;
    }
    e !== 0 && Ef(l, e, 0), n !== 0 && u === 0 && l.tag !== 0 && (l.suspendedLanes |= n & ~(i & ~t));
  }
  function Ef(l, t, a) {
    l.pendingLanes |= t, l.suspendedLanes &= ~t;
    var e = 31 - st(t);
    l.entangledLanes |= t, l.entanglements[e] = l.entanglements[e] | 1073741824 | a & 261930;
  }
  function Af(l, t) {
    var a = l.entangledLanes |= t;
    for (l = l.entanglements; a; ) {
      var e = 31 - st(a), u = 1 << e;
      u & t | l[e] & t && (l[e] |= t), a &= ~u;
    }
  }
  function xf(l, t) {
    var a = t & -t;
    return a = (a & 42) !== 0 ? 1 : Fn(a), (a & (l.suspendedLanes | t)) !== 0 ? 0 : a;
  }
  function Fn(l) {
    switch (l) {
      case 2:
        l = 1;
        break;
      case 8:
        l = 4;
        break;
      case 32:
        l = 16;
        break;
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
        l = 128;
        break;
      case 268435456:
        l = 134217728;
        break;
      default:
        l = 0;
    }
    return l;
  }
  function In(l) {
    return l &= -l, 2 < l ? 8 < l ? (l & 134217727) !== 0 ? 32 : 268435456 : 8 : 2;
  }
  function _f() {
    var l = N.p;
    return l !== 0 ? l : (l = window.event, l === void 0 ? 32 : rd(l.type));
  }
  function Nf(l, t) {
    var a = N.p;
    try {
      return N.p = l, t();
    } finally {
      N.p = a;
    }
  }
  var na = Math.random().toString(36).slice(2), Kl = "__reactFiber$" + na, lt = "__reactProps$" + na, wa = "__reactContainer$" + na, Pn = "__reactEvents$" + na, wd = "__reactListeners$" + na, $d = "__reactHandles$" + na, Mf = "__reactResources$" + na, He = "__reactMarker$" + na;
  function li(l) {
    delete l[Kl], delete l[lt], delete l[Pn], delete l[wd], delete l[$d];
  }
  function $a(l) {
    var t = l[Kl];
    if (t) return t;
    for (var a = l.parentNode; a; ) {
      if (t = a[wa] || a[Kl]) {
        if (a = t.alternate, t.child !== null || a !== null && a.child !== null)
          for (l = k0(l); l !== null; ) {
            if (a = l[Kl]) return a;
            l = k0(l);
          }
        return t;
      }
      l = a, a = l.parentNode;
    }
    return null;
  }
  function Wa(l) {
    if (l = l[Kl] || l[wa]) {
      var t = l.tag;
      if (t === 5 || t === 6 || t === 13 || t === 31 || t === 26 || t === 27 || t === 3)
        return l;
    }
    return null;
  }
  function Be(l) {
    var t = l.tag;
    if (t === 5 || t === 26 || t === 27 || t === 6) return l.stateNode;
    throw Error(r(33));
  }
  function ka(l) {
    var t = l[Mf];
    return t || (t = l[Mf] = { hoistableStyles: /* @__PURE__ */ new Map(), hoistableScripts: /* @__PURE__ */ new Map() }), t;
  }
  function Xl(l) {
    l[He] = !0;
  }
  var Of = /* @__PURE__ */ new Set(), Uf = {};
  function Ua(l, t) {
    Fa(l, t), Fa(l + "Capture", t);
  }
  function Fa(l, t) {
    for (Uf[l] = t, l = 0; l < t.length; l++)
      Of.add(t[l]);
  }
  var Wd = RegExp(
    "^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"
  ), Df = {}, Cf = {};
  function kd(l) {
    return wn.call(Cf, l) ? !0 : wn.call(Df, l) ? !1 : Wd.test(l) ? Cf[l] = !0 : (Df[l] = !0, !1);
  }
  function Cu(l, t, a) {
    if (kd(t))
      if (a === null) l.removeAttribute(t);
      else {
        switch (typeof a) {
          case "undefined":
          case "function":
          case "symbol":
            l.removeAttribute(t);
            return;
          case "boolean":
            var e = t.toLowerCase().slice(0, 5);
            if (e !== "data-" && e !== "aria-") {
              l.removeAttribute(t);
              return;
            }
        }
        l.setAttribute(t, "" + a);
      }
  }
  function ju(l, t, a) {
    if (a === null) l.removeAttribute(t);
    else {
      switch (typeof a) {
        case "undefined":
        case "function":
        case "symbol":
        case "boolean":
          l.removeAttribute(t);
          return;
      }
      l.setAttribute(t, "" + a);
    }
  }
  function Gt(l, t, a, e) {
    if (e === null) l.removeAttribute(a);
    else {
      switch (typeof e) {
        case "undefined":
        case "function":
        case "symbol":
        case "boolean":
          l.removeAttribute(a);
          return;
      }
      l.setAttributeNS(t, a, "" + e);
    }
  }
  function pt(l) {
    switch (typeof l) {
      case "bigint":
      case "boolean":
      case "number":
      case "string":
      case "undefined":
        return l;
      case "object":
        return l;
      default:
        return "";
    }
  }
  function jf(l) {
    var t = l.type;
    return (l = l.nodeName) && l.toLowerCase() === "input" && (t === "checkbox" || t === "radio");
  }
  function Fd(l, t, a) {
    var e = Object.getOwnPropertyDescriptor(
      l.constructor.prototype,
      t
    );
    if (!l.hasOwnProperty(t) && typeof e < "u" && typeof e.get == "function" && typeof e.set == "function") {
      var u = e.get, n = e.set;
      return Object.defineProperty(l, t, {
        configurable: !0,
        get: function() {
          return u.call(this);
        },
        set: function(i) {
          a = "" + i, n.call(this, i);
        }
      }), Object.defineProperty(l, t, {
        enumerable: e.enumerable
      }), {
        getValue: function() {
          return a;
        },
        setValue: function(i) {
          a = "" + i;
        },
        stopTracking: function() {
          l._valueTracker = null, delete l[t];
        }
      };
    }
  }
  function ti(l) {
    if (!l._valueTracker) {
      var t = jf(l) ? "checked" : "value";
      l._valueTracker = Fd(
        l,
        t,
        "" + l[t]
      );
    }
  }
  function Rf(l) {
    if (!l) return !1;
    var t = l._valueTracker;
    if (!t) return !0;
    var a = t.getValue(), e = "";
    return l && (e = jf(l) ? l.checked ? "true" : "false" : l.value), l = e, l !== a ? (t.setValue(l), !0) : !1;
  }
  function Ru(l) {
    if (l = l || (typeof document < "u" ? document : void 0), typeof l > "u") return null;
    try {
      return l.activeElement || l.body;
    } catch {
      return l.body;
    }
  }
  var Id = /[\n"\\]/g;
  function Tt(l) {
    return l.replace(
      Id,
      function(t) {
        return "\\" + t.charCodeAt(0).toString(16) + " ";
      }
    );
  }
  function ai(l, t, a, e, u, n, i, c) {
    l.name = "", i != null && typeof i != "function" && typeof i != "symbol" && typeof i != "boolean" ? l.type = i : l.removeAttribute("type"), t != null ? i === "number" ? (t === 0 && l.value === "" || l.value != t) && (l.value = "" + pt(t)) : l.value !== "" + pt(t) && (l.value = "" + pt(t)) : i !== "submit" && i !== "reset" || l.removeAttribute("value"), t != null ? ei(l, i, pt(t)) : a != null ? ei(l, i, pt(a)) : e != null && l.removeAttribute("value"), u == null && n != null && (l.defaultChecked = !!n), u != null && (l.checked = u && typeof u != "function" && typeof u != "symbol"), c != null && typeof c != "function" && typeof c != "symbol" && typeof c != "boolean" ? l.name = "" + pt(c) : l.removeAttribute("name");
  }
  function Hf(l, t, a, e, u, n, i, c) {
    if (n != null && typeof n != "function" && typeof n != "symbol" && typeof n != "boolean" && (l.type = n), t != null || a != null) {
      if (!(n !== "submit" && n !== "reset" || t != null)) {
        ti(l);
        return;
      }
      a = a != null ? "" + pt(a) : "", t = t != null ? "" + pt(t) : a, c || t === l.value || (l.value = t), l.defaultValue = t;
    }
    e = e ?? u, e = typeof e != "function" && typeof e != "symbol" && !!e, l.checked = c ? l.checked : !!e, l.defaultChecked = !!e, i != null && typeof i != "function" && typeof i != "symbol" && typeof i != "boolean" && (l.name = i), ti(l);
  }
  function ei(l, t, a) {
    t === "number" && Ru(l.ownerDocument) === l || l.defaultValue === "" + a || (l.defaultValue = "" + a);
  }
  function Ia(l, t, a, e) {
    if (l = l.options, t) {
      t = {};
      for (var u = 0; u < a.length; u++)
        t["$" + a[u]] = !0;
      for (a = 0; a < l.length; a++)
        u = t.hasOwnProperty("$" + l[a].value), l[a].selected !== u && (l[a].selected = u), u && e && (l[a].defaultSelected = !0);
    } else {
      for (a = "" + pt(a), t = null, u = 0; u < l.length; u++) {
        if (l[u].value === a) {
          l[u].selected = !0, e && (l[u].defaultSelected = !0);
          return;
        }
        t !== null || l[u].disabled || (t = l[u]);
      }
      t !== null && (t.selected = !0);
    }
  }
  function Bf(l, t, a) {
    if (t != null && (t = "" + pt(t), t !== l.value && (l.value = t), a == null)) {
      l.defaultValue !== t && (l.defaultValue = t);
      return;
    }
    l.defaultValue = a != null ? "" + pt(a) : "";
  }
  function qf(l, t, a, e) {
    if (t == null) {
      if (e != null) {
        if (a != null) throw Error(r(92));
        if (ml(e)) {
          if (1 < e.length) throw Error(r(93));
          e = e[0];
        }
        a = e;
      }
      a == null && (a = ""), t = a;
    }
    a = pt(t), l.defaultValue = a, e = l.textContent, e === a && e !== "" && e !== null && (l.value = e), ti(l);
  }
  function Pa(l, t) {
    if (t) {
      var a = l.firstChild;
      if (a && a === l.lastChild && a.nodeType === 3) {
        a.nodeValue = t;
        return;
      }
    }
    l.textContent = t;
  }
  var Pd = new Set(
    "animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(
      " "
    )
  );
  function Yf(l, t, a) {
    var e = t.indexOf("--") === 0;
    a == null || typeof a == "boolean" || a === "" ? e ? l.setProperty(t, "") : t === "float" ? l.cssFloat = "" : l[t] = "" : e ? l.setProperty(t, a) : typeof a != "number" || a === 0 || Pd.has(t) ? t === "float" ? l.cssFloat = a : l[t] = ("" + a).trim() : l[t] = a + "px";
  }
  function Gf(l, t, a) {
    if (t != null && typeof t != "object")
      throw Error(r(62));
    if (l = l.style, a != null) {
      for (var e in a)
        !a.hasOwnProperty(e) || t != null && t.hasOwnProperty(e) || (e.indexOf("--") === 0 ? l.setProperty(e, "") : e === "float" ? l.cssFloat = "" : l[e] = "");
      for (var u in t)
        e = t[u], t.hasOwnProperty(u) && a[u] !== e && Yf(l, u, e);
    } else
      for (var n in t)
        t.hasOwnProperty(n) && Yf(l, n, t[n]);
  }
  function ui(l) {
    if (l.indexOf("-") === -1) return !1;
    switch (l) {
      case "annotation-xml":
      case "color-profile":
      case "font-face":
      case "font-face-src":
      case "font-face-uri":
      case "font-face-format":
      case "font-face-name":
      case "missing-glyph":
        return !1;
      default:
        return !0;
    }
  }
  var lr = /* @__PURE__ */ new Map([
    ["acceptCharset", "accept-charset"],
    ["htmlFor", "for"],
    ["httpEquiv", "http-equiv"],
    ["crossOrigin", "crossorigin"],
    ["accentHeight", "accent-height"],
    ["alignmentBaseline", "alignment-baseline"],
    ["arabicForm", "arabic-form"],
    ["baselineShift", "baseline-shift"],
    ["capHeight", "cap-height"],
    ["clipPath", "clip-path"],
    ["clipRule", "clip-rule"],
    ["colorInterpolation", "color-interpolation"],
    ["colorInterpolationFilters", "color-interpolation-filters"],
    ["colorProfile", "color-profile"],
    ["colorRendering", "color-rendering"],
    ["dominantBaseline", "dominant-baseline"],
    ["enableBackground", "enable-background"],
    ["fillOpacity", "fill-opacity"],
    ["fillRule", "fill-rule"],
    ["floodColor", "flood-color"],
    ["floodOpacity", "flood-opacity"],
    ["fontFamily", "font-family"],
    ["fontSize", "font-size"],
    ["fontSizeAdjust", "font-size-adjust"],
    ["fontStretch", "font-stretch"],
    ["fontStyle", "font-style"],
    ["fontVariant", "font-variant"],
    ["fontWeight", "font-weight"],
    ["glyphName", "glyph-name"],
    ["glyphOrientationHorizontal", "glyph-orientation-horizontal"],
    ["glyphOrientationVertical", "glyph-orientation-vertical"],
    ["horizAdvX", "horiz-adv-x"],
    ["horizOriginX", "horiz-origin-x"],
    ["imageRendering", "image-rendering"],
    ["letterSpacing", "letter-spacing"],
    ["lightingColor", "lighting-color"],
    ["markerEnd", "marker-end"],
    ["markerMid", "marker-mid"],
    ["markerStart", "marker-start"],
    ["overlinePosition", "overline-position"],
    ["overlineThickness", "overline-thickness"],
    ["paintOrder", "paint-order"],
    ["panose-1", "panose-1"],
    ["pointerEvents", "pointer-events"],
    ["renderingIntent", "rendering-intent"],
    ["shapeRendering", "shape-rendering"],
    ["stopColor", "stop-color"],
    ["stopOpacity", "stop-opacity"],
    ["strikethroughPosition", "strikethrough-position"],
    ["strikethroughThickness", "strikethrough-thickness"],
    ["strokeDasharray", "stroke-dasharray"],
    ["strokeDashoffset", "stroke-dashoffset"],
    ["strokeLinecap", "stroke-linecap"],
    ["strokeLinejoin", "stroke-linejoin"],
    ["strokeMiterlimit", "stroke-miterlimit"],
    ["strokeOpacity", "stroke-opacity"],
    ["strokeWidth", "stroke-width"],
    ["textAnchor", "text-anchor"],
    ["textDecoration", "text-decoration"],
    ["textRendering", "text-rendering"],
    ["transformOrigin", "transform-origin"],
    ["underlinePosition", "underline-position"],
    ["underlineThickness", "underline-thickness"],
    ["unicodeBidi", "unicode-bidi"],
    ["unicodeRange", "unicode-range"],
    ["unitsPerEm", "units-per-em"],
    ["vAlphabetic", "v-alphabetic"],
    ["vHanging", "v-hanging"],
    ["vIdeographic", "v-ideographic"],
    ["vMathematical", "v-mathematical"],
    ["vectorEffect", "vector-effect"],
    ["vertAdvY", "vert-adv-y"],
    ["vertOriginX", "vert-origin-x"],
    ["vertOriginY", "vert-origin-y"],
    ["wordSpacing", "word-spacing"],
    ["writingMode", "writing-mode"],
    ["xmlnsXlink", "xmlns:xlink"],
    ["xHeight", "x-height"]
  ]), tr = /^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;
  function Hu(l) {
    return tr.test("" + l) ? "javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')" : l;
  }
  function Xt() {
  }
  var ni = null;
  function ii(l) {
    return l = l.target || l.srcElement || window, l.correspondingUseElement && (l = l.correspondingUseElement), l.nodeType === 3 ? l.parentNode : l;
  }
  var le = null, te = null;
  function Xf(l) {
    var t = Wa(l);
    if (t && (l = t.stateNode)) {
      var a = l[lt] || null;
      l: switch (l = t.stateNode, t.type) {
        case "input":
          if (ai(
            l,
            a.value,
            a.defaultValue,
            a.defaultValue,
            a.checked,
            a.defaultChecked,
            a.type,
            a.name
          ), t = a.name, a.type === "radio" && t != null) {
            for (a = l; a.parentNode; ) a = a.parentNode;
            for (a = a.querySelectorAll(
              'input[name="' + Tt(
                "" + t
              ) + '"][type="radio"]'
            ), t = 0; t < a.length; t++) {
              var e = a[t];
              if (e !== l && e.form === l.form) {
                var u = e[lt] || null;
                if (!u) throw Error(r(90));
                ai(
                  e,
                  u.value,
                  u.defaultValue,
                  u.defaultValue,
                  u.checked,
                  u.defaultChecked,
                  u.type,
                  u.name
                );
              }
            }
            for (t = 0; t < a.length; t++)
              e = a[t], e.form === l.form && Rf(e);
          }
          break l;
        case "textarea":
          Bf(l, a.value, a.defaultValue);
          break l;
        case "select":
          t = a.value, t != null && Ia(l, !!a.multiple, t, !1);
      }
    }
  }
  var ci = !1;
  function Qf(l, t, a) {
    if (ci) return l(t, a);
    ci = !0;
    try {
      var e = l(t);
      return e;
    } finally {
      if (ci = !1, (le !== null || te !== null) && (En(), le && (t = le, l = te, te = le = null, Xf(t), l)))
        for (t = 0; t < l.length; t++) Xf(l[t]);
    }
  }
  function qe(l, t) {
    var a = l.stateNode;
    if (a === null) return null;
    var e = a[lt] || null;
    if (e === null) return null;
    a = e[t];
    l: switch (t) {
      case "onClick":
      case "onClickCapture":
      case "onDoubleClick":
      case "onDoubleClickCapture":
      case "onMouseDown":
      case "onMouseDownCapture":
      case "onMouseMove":
      case "onMouseMoveCapture":
      case "onMouseUp":
      case "onMouseUpCapture":
      case "onMouseEnter":
        (e = !e.disabled) || (l = l.type, e = !(l === "button" || l === "input" || l === "select" || l === "textarea")), l = !e;
        break l;
      default:
        l = !1;
    }
    if (l) return null;
    if (a && typeof a != "function")
      throw Error(
        r(231, t, typeof a)
      );
    return a;
  }
  var Qt = !(typeof window > "u" || typeof window.document > "u" || typeof window.document.createElement > "u"), fi = !1;
  if (Qt)
    try {
      var Ye = {};
      Object.defineProperty(Ye, "passive", {
        get: function() {
          fi = !0;
        }
      }), window.addEventListener("test", Ye, Ye), window.removeEventListener("test", Ye, Ye);
    } catch {
      fi = !1;
    }
  var ia = null, si = null, Bu = null;
  function Lf() {
    if (Bu) return Bu;
    var l, t = si, a = t.length, e, u = "value" in ia ? ia.value : ia.textContent, n = u.length;
    for (l = 0; l < a && t[l] === u[l]; l++) ;
    var i = a - l;
    for (e = 1; e <= i && t[a - e] === u[n - e]; e++) ;
    return Bu = u.slice(l, 1 < e ? 1 - e : void 0);
  }
  function qu(l) {
    var t = l.keyCode;
    return "charCode" in l ? (l = l.charCode, l === 0 && t === 13 && (l = 13)) : l = t, l === 10 && (l = 13), 32 <= l || l === 13 ? l : 0;
  }
  function Yu() {
    return !0;
  }
  function Zf() {
    return !1;
  }
  function tt(l) {
    function t(a, e, u, n, i) {
      this._reactName = a, this._targetInst = u, this.type = e, this.nativeEvent = n, this.target = i, this.currentTarget = null;
      for (var c in l)
        l.hasOwnProperty(c) && (a = l[c], this[c] = a ? a(n) : n[c]);
      return this.isDefaultPrevented = (n.defaultPrevented != null ? n.defaultPrevented : n.returnValue === !1) ? Yu : Zf, this.isPropagationStopped = Zf, this;
    }
    return j(t.prototype, {
      preventDefault: function() {
        this.defaultPrevented = !0;
        var a = this.nativeEvent;
        a && (a.preventDefault ? a.preventDefault() : typeof a.returnValue != "unknown" && (a.returnValue = !1), this.isDefaultPrevented = Yu);
      },
      stopPropagation: function() {
        var a = this.nativeEvent;
        a && (a.stopPropagation ? a.stopPropagation() : typeof a.cancelBubble != "unknown" && (a.cancelBubble = !0), this.isPropagationStopped = Yu);
      },
      persist: function() {
      },
      isPersistent: Yu
    }), t;
  }
  var Da = {
    eventPhase: 0,
    bubbles: 0,
    cancelable: 0,
    timeStamp: function(l) {
      return l.timeStamp || Date.now();
    },
    defaultPrevented: 0,
    isTrusted: 0
  }, Gu = tt(Da), Ge = j({}, Da, { view: 0, detail: 0 }), ar = tt(Ge), oi, di, Xe, Xu = j({}, Ge, {
    screenX: 0,
    screenY: 0,
    clientX: 0,
    clientY: 0,
    pageX: 0,
    pageY: 0,
    ctrlKey: 0,
    shiftKey: 0,
    altKey: 0,
    metaKey: 0,
    getModifierState: mi,
    button: 0,
    buttons: 0,
    relatedTarget: function(l) {
      return l.relatedTarget === void 0 ? l.fromElement === l.srcElement ? l.toElement : l.fromElement : l.relatedTarget;
    },
    movementX: function(l) {
      return "movementX" in l ? l.movementX : (l !== Xe && (Xe && l.type === "mousemove" ? (oi = l.screenX - Xe.screenX, di = l.screenY - Xe.screenY) : di = oi = 0, Xe = l), oi);
    },
    movementY: function(l) {
      return "movementY" in l ? l.movementY : di;
    }
  }), Vf = tt(Xu), er = j({}, Xu, { dataTransfer: 0 }), ur = tt(er), nr = j({}, Ge, { relatedTarget: 0 }), ri = tt(nr), ir = j({}, Da, {
    animationName: 0,
    elapsedTime: 0,
    pseudoElement: 0
  }), cr = tt(ir), fr = j({}, Da, {
    clipboardData: function(l) {
      return "clipboardData" in l ? l.clipboardData : window.clipboardData;
    }
  }), sr = tt(fr), or = j({}, Da, { data: 0 }), Kf = tt(or), dr = {
    Esc: "Escape",
    Spacebar: " ",
    Left: "ArrowLeft",
    Up: "ArrowUp",
    Right: "ArrowRight",
    Down: "ArrowDown",
    Del: "Delete",
    Win: "OS",
    Menu: "ContextMenu",
    Apps: "ContextMenu",
    Scroll: "ScrollLock",
    MozPrintableKey: "Unidentified"
  }, rr = {
    8: "Backspace",
    9: "Tab",
    12: "Clear",
    13: "Enter",
    16: "Shift",
    17: "Control",
    18: "Alt",
    19: "Pause",
    20: "CapsLock",
    27: "Escape",
    32: " ",
    33: "PageUp",
    34: "PageDown",
    35: "End",
    36: "Home",
    37: "ArrowLeft",
    38: "ArrowUp",
    39: "ArrowRight",
    40: "ArrowDown",
    45: "Insert",
    46: "Delete",
    112: "F1",
    113: "F2",
    114: "F3",
    115: "F4",
    116: "F5",
    117: "F6",
    118: "F7",
    119: "F8",
    120: "F9",
    121: "F10",
    122: "F11",
    123: "F12",
    144: "NumLock",
    145: "ScrollLock",
    224: "Meta"
  }, mr = {
    Alt: "altKey",
    Control: "ctrlKey",
    Meta: "metaKey",
    Shift: "shiftKey"
  };
  function yr(l) {
    var t = this.nativeEvent;
    return t.getModifierState ? t.getModifierState(l) : (l = mr[l]) ? !!t[l] : !1;
  }
  function mi() {
    return yr;
  }
  var vr = j({}, Ge, {
    key: function(l) {
      if (l.key) {
        var t = dr[l.key] || l.key;
        if (t !== "Unidentified") return t;
      }
      return l.type === "keypress" ? (l = qu(l), l === 13 ? "Enter" : String.fromCharCode(l)) : l.type === "keydown" || l.type === "keyup" ? rr[l.keyCode] || "Unidentified" : "";
    },
    code: 0,
    location: 0,
    ctrlKey: 0,
    shiftKey: 0,
    altKey: 0,
    metaKey: 0,
    repeat: 0,
    locale: 0,
    getModifierState: mi,
    charCode: function(l) {
      return l.type === "keypress" ? qu(l) : 0;
    },
    keyCode: function(l) {
      return l.type === "keydown" || l.type === "keyup" ? l.keyCode : 0;
    },
    which: function(l) {
      return l.type === "keypress" ? qu(l) : l.type === "keydown" || l.type === "keyup" ? l.keyCode : 0;
    }
  }), hr = tt(vr), gr = j({}, Xu, {
    pointerId: 0,
    width: 0,
    height: 0,
    pressure: 0,
    tangentialPressure: 0,
    tiltX: 0,
    tiltY: 0,
    twist: 0,
    pointerType: 0,
    isPrimary: 0
  }), Jf = tt(gr), br = j({}, Ge, {
    touches: 0,
    targetTouches: 0,
    changedTouches: 0,
    altKey: 0,
    metaKey: 0,
    ctrlKey: 0,
    shiftKey: 0,
    getModifierState: mi
  }), Sr = tt(br), pr = j({}, Da, {
    propertyName: 0,
    elapsedTime: 0,
    pseudoElement: 0
  }), Tr = tt(pr), zr = j({}, Xu, {
    deltaX: function(l) {
      return "deltaX" in l ? l.deltaX : "wheelDeltaX" in l ? -l.wheelDeltaX : 0;
    },
    deltaY: function(l) {
      return "deltaY" in l ? l.deltaY : "wheelDeltaY" in l ? -l.wheelDeltaY : "wheelDelta" in l ? -l.wheelDelta : 0;
    },
    deltaZ: 0,
    deltaMode: 0
  }), Er = tt(zr), Ar = j({}, Da, {
    newState: 0,
    oldState: 0
  }), xr = tt(Ar), _r = [9, 13, 27, 32], yi = Qt && "CompositionEvent" in window, Qe = null;
  Qt && "documentMode" in document && (Qe = document.documentMode);
  var Nr = Qt && "TextEvent" in window && !Qe, wf = Qt && (!yi || Qe && 8 < Qe && 11 >= Qe), $f = " ", Wf = !1;
  function kf(l, t) {
    switch (l) {
      case "keyup":
        return _r.indexOf(t.keyCode) !== -1;
      case "keydown":
        return t.keyCode !== 229;
      case "keypress":
      case "mousedown":
      case "focusout":
        return !0;
      default:
        return !1;
    }
  }
  function Ff(l) {
    return l = l.detail, typeof l == "object" && "data" in l ? l.data : null;
  }
  var ae = !1;
  function Mr(l, t) {
    switch (l) {
      case "compositionend":
        return Ff(t);
      case "keypress":
        return t.which !== 32 ? null : (Wf = !0, $f);
      case "textInput":
        return l = t.data, l === $f && Wf ? null : l;
      default:
        return null;
    }
  }
  function Or(l, t) {
    if (ae)
      return l === "compositionend" || !yi && kf(l, t) ? (l = Lf(), Bu = si = ia = null, ae = !1, l) : null;
    switch (l) {
      case "paste":
        return null;
      case "keypress":
        if (!(t.ctrlKey || t.altKey || t.metaKey) || t.ctrlKey && t.altKey) {
          if (t.char && 1 < t.char.length)
            return t.char;
          if (t.which) return String.fromCharCode(t.which);
        }
        return null;
      case "compositionend":
        return wf && t.locale !== "ko" ? null : t.data;
      default:
        return null;
    }
  }
  var Ur = {
    color: !0,
    date: !0,
    datetime: !0,
    "datetime-local": !0,
    email: !0,
    month: !0,
    number: !0,
    password: !0,
    range: !0,
    search: !0,
    tel: !0,
    text: !0,
    time: !0,
    url: !0,
    week: !0
  };
  function If(l) {
    var t = l && l.nodeName && l.nodeName.toLowerCase();
    return t === "input" ? !!Ur[l.type] : t === "textarea";
  }
  function Pf(l, t, a, e) {
    le ? te ? te.push(e) : te = [e] : le = e, t = Un(t, "onChange"), 0 < t.length && (a = new Gu(
      "onChange",
      "change",
      null,
      a,
      e
    ), l.push({ event: a, listeners: t }));
  }
  var Le = null, Ze = null;
  function Dr(l) {
    B0(l, 0);
  }
  function Qu(l) {
    var t = Be(l);
    if (Rf(t)) return l;
  }
  function ls(l, t) {
    if (l === "change") return t;
  }
  var ts = !1;
  if (Qt) {
    var vi;
    if (Qt) {
      var hi = "oninput" in document;
      if (!hi) {
        var as = document.createElement("div");
        as.setAttribute("oninput", "return;"), hi = typeof as.oninput == "function";
      }
      vi = hi;
    } else vi = !1;
    ts = vi && (!document.documentMode || 9 < document.documentMode);
  }
  function es() {
    Le && (Le.detachEvent("onpropertychange", us), Ze = Le = null);
  }
  function us(l) {
    if (l.propertyName === "value" && Qu(Ze)) {
      var t = [];
      Pf(
        t,
        Ze,
        l,
        ii(l)
      ), Qf(Dr, t);
    }
  }
  function Cr(l, t, a) {
    l === "focusin" ? (es(), Le = t, Ze = a, Le.attachEvent("onpropertychange", us)) : l === "focusout" && es();
  }
  function jr(l) {
    if (l === "selectionchange" || l === "keyup" || l === "keydown")
      return Qu(Ze);
  }
  function Rr(l, t) {
    if (l === "click") return Qu(t);
  }
  function Hr(l, t) {
    if (l === "input" || l === "change")
      return Qu(t);
  }
  function Br(l, t) {
    return l === t && (l !== 0 || 1 / l === 1 / t) || l !== l && t !== t;
  }
  var ot = typeof Object.is == "function" ? Object.is : Br;
  function Ve(l, t) {
    if (ot(l, t)) return !0;
    if (typeof l != "object" || l === null || typeof t != "object" || t === null)
      return !1;
    var a = Object.keys(l), e = Object.keys(t);
    if (a.length !== e.length) return !1;
    for (e = 0; e < a.length; e++) {
      var u = a[e];
      if (!wn.call(t, u) || !ot(l[u], t[u]))
        return !1;
    }
    return !0;
  }
  function ns(l) {
    for (; l && l.firstChild; ) l = l.firstChild;
    return l;
  }
  function is(l, t) {
    var a = ns(l);
    l = 0;
    for (var e; a; ) {
      if (a.nodeType === 3) {
        if (e = l + a.textContent.length, l <= t && e >= t)
          return { node: a, offset: t - l };
        l = e;
      }
      l: {
        for (; a; ) {
          if (a.nextSibling) {
            a = a.nextSibling;
            break l;
          }
          a = a.parentNode;
        }
        a = void 0;
      }
      a = ns(a);
    }
  }
  function cs(l, t) {
    return l && t ? l === t ? !0 : l && l.nodeType === 3 ? !1 : t && t.nodeType === 3 ? cs(l, t.parentNode) : "contains" in l ? l.contains(t) : l.compareDocumentPosition ? !!(l.compareDocumentPosition(t) & 16) : !1 : !1;
  }
  function fs(l) {
    l = l != null && l.ownerDocument != null && l.ownerDocument.defaultView != null ? l.ownerDocument.defaultView : window;
    for (var t = Ru(l.document); t instanceof l.HTMLIFrameElement; ) {
      try {
        var a = typeof t.contentWindow.location.href == "string";
      } catch {
        a = !1;
      }
      if (a) l = t.contentWindow;
      else break;
      t = Ru(l.document);
    }
    return t;
  }
  function gi(l) {
    var t = l && l.nodeName && l.nodeName.toLowerCase();
    return t && (t === "input" && (l.type === "text" || l.type === "search" || l.type === "tel" || l.type === "url" || l.type === "password") || t === "textarea" || l.contentEditable === "true");
  }
  var qr = Qt && "documentMode" in document && 11 >= document.documentMode, ee = null, bi = null, Ke = null, Si = !1;
  function ss(l, t, a) {
    var e = a.window === a ? a.document : a.nodeType === 9 ? a : a.ownerDocument;
    Si || ee == null || ee !== Ru(e) || (e = ee, "selectionStart" in e && gi(e) ? e = { start: e.selectionStart, end: e.selectionEnd } : (e = (e.ownerDocument && e.ownerDocument.defaultView || window).getSelection(), e = {
      anchorNode: e.anchorNode,
      anchorOffset: e.anchorOffset,
      focusNode: e.focusNode,
      focusOffset: e.focusOffset
    }), Ke && Ve(Ke, e) || (Ke = e, e = Un(bi, "onSelect"), 0 < e.length && (t = new Gu(
      "onSelect",
      "select",
      null,
      t,
      a
    ), l.push({ event: t, listeners: e }), t.target = ee)));
  }
  function Ca(l, t) {
    var a = {};
    return a[l.toLowerCase()] = t.toLowerCase(), a["Webkit" + l] = "webkit" + t, a["Moz" + l] = "moz" + t, a;
  }
  var ue = {
    animationend: Ca("Animation", "AnimationEnd"),
    animationiteration: Ca("Animation", "AnimationIteration"),
    animationstart: Ca("Animation", "AnimationStart"),
    transitionrun: Ca("Transition", "TransitionRun"),
    transitionstart: Ca("Transition", "TransitionStart"),
    transitioncancel: Ca("Transition", "TransitionCancel"),
    transitionend: Ca("Transition", "TransitionEnd")
  }, pi = {}, os = {};
  Qt && (os = document.createElement("div").style, "AnimationEvent" in window || (delete ue.animationend.animation, delete ue.animationiteration.animation, delete ue.animationstart.animation), "TransitionEvent" in window || delete ue.transitionend.transition);
  function ja(l) {
    if (pi[l]) return pi[l];
    if (!ue[l]) return l;
    var t = ue[l], a;
    for (a in t)
      if (t.hasOwnProperty(a) && a in os)
        return pi[l] = t[a];
    return l;
  }
  var ds = ja("animationend"), rs = ja("animationiteration"), ms = ja("animationstart"), Yr = ja("transitionrun"), Gr = ja("transitionstart"), Xr = ja("transitioncancel"), ys = ja("transitionend"), vs = /* @__PURE__ */ new Map(), Ti = "abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(
    " "
  );
  Ti.push("scrollEnd");
  function Ct(l, t) {
    vs.set(l, t), Ua(t, [l]);
  }
  var Lu = typeof reportError == "function" ? reportError : function(l) {
    if (typeof window == "object" && typeof window.ErrorEvent == "function") {
      var t = new window.ErrorEvent("error", {
        bubbles: !0,
        cancelable: !0,
        message: typeof l == "object" && l !== null && typeof l.message == "string" ? String(l.message) : String(l),
        error: l
      });
      if (!window.dispatchEvent(t)) return;
    } else if (typeof process == "object" && typeof process.emit == "function") {
      process.emit("uncaughtException", l);
      return;
    }
    console.error(l);
  }, zt = [], ne = 0, zi = 0;
  function Zu() {
    for (var l = ne, t = zi = ne = 0; t < l; ) {
      var a = zt[t];
      zt[t++] = null;
      var e = zt[t];
      zt[t++] = null;
      var u = zt[t];
      zt[t++] = null;
      var n = zt[t];
      if (zt[t++] = null, e !== null && u !== null) {
        var i = e.pending;
        i === null ? u.next = u : (u.next = i.next, i.next = u), e.pending = u;
      }
      n !== 0 && hs(a, u, n);
    }
  }
  function Vu(l, t, a, e) {
    zt[ne++] = l, zt[ne++] = t, zt[ne++] = a, zt[ne++] = e, zi |= e, l.lanes |= e, l = l.alternate, l !== null && (l.lanes |= e);
  }
  function Ei(l, t, a, e) {
    return Vu(l, t, a, e), Ku(l);
  }
  function Ra(l, t) {
    return Vu(l, null, null, t), Ku(l);
  }
  function hs(l, t, a) {
    l.lanes |= a;
    var e = l.alternate;
    e !== null && (e.lanes |= a);
    for (var u = !1, n = l.return; n !== null; )
      n.childLanes |= a, e = n.alternate, e !== null && (e.childLanes |= a), n.tag === 22 && (l = n.stateNode, l === null || l._visibility & 1 || (u = !0)), l = n, n = n.return;
    return l.tag === 3 ? (n = l.stateNode, u && t !== null && (u = 31 - st(a), l = n.hiddenUpdates, e = l[u], e === null ? l[u] = [t] : e.push(t), t.lane = a | 536870912), n) : null;
  }
  function Ku(l) {
    if (50 < mu)
      throw mu = 0, Cc = null, Error(r(185));
    for (var t = l.return; t !== null; )
      l = t, t = l.return;
    return l.tag === 3 ? l.stateNode : null;
  }
  var ie = {};
  function Qr(l, t, a, e) {
    this.tag = l, this.key = a, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.refCleanup = this.ref = null, this.pendingProps = t, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = e, this.subtreeFlags = this.flags = 0, this.deletions = null, this.childLanes = this.lanes = 0, this.alternate = null;
  }
  function dt(l, t, a, e) {
    return new Qr(l, t, a, e);
  }
  function Ai(l) {
    return l = l.prototype, !(!l || !l.isReactComponent);
  }
  function Lt(l, t) {
    var a = l.alternate;
    return a === null ? (a = dt(
      l.tag,
      t,
      l.key,
      l.mode
    ), a.elementType = l.elementType, a.type = l.type, a.stateNode = l.stateNode, a.alternate = l, l.alternate = a) : (a.pendingProps = t, a.type = l.type, a.flags = 0, a.subtreeFlags = 0, a.deletions = null), a.flags = l.flags & 65011712, a.childLanes = l.childLanes, a.lanes = l.lanes, a.child = l.child, a.memoizedProps = l.memoizedProps, a.memoizedState = l.memoizedState, a.updateQueue = l.updateQueue, t = l.dependencies, a.dependencies = t === null ? null : { lanes: t.lanes, firstContext: t.firstContext }, a.sibling = l.sibling, a.index = l.index, a.ref = l.ref, a.refCleanup = l.refCleanup, a;
  }
  function gs(l, t) {
    l.flags &= 65011714;
    var a = l.alternate;
    return a === null ? (l.childLanes = 0, l.lanes = t, l.child = null, l.subtreeFlags = 0, l.memoizedProps = null, l.memoizedState = null, l.updateQueue = null, l.dependencies = null, l.stateNode = null) : (l.childLanes = a.childLanes, l.lanes = a.lanes, l.child = a.child, l.subtreeFlags = 0, l.deletions = null, l.memoizedProps = a.memoizedProps, l.memoizedState = a.memoizedState, l.updateQueue = a.updateQueue, l.type = a.type, t = a.dependencies, l.dependencies = t === null ? null : {
      lanes: t.lanes,
      firstContext: t.firstContext
    }), l;
  }
  function Ju(l, t, a, e, u, n) {
    var i = 0;
    if (e = l, typeof l == "function") Ai(l) && (i = 1);
    else if (typeof l == "string")
      i = Jm(
        l,
        a,
        C.current
      ) ? 26 : l === "html" || l === "head" || l === "body" ? 27 : 5;
    else
      l: switch (l) {
        case St:
          return l = dt(31, a, t, u), l.elementType = St, l.lanes = n, l;
        case Sl:
          return Ha(a.children, u, n, t);
        case gt:
          i = 8, u |= 24;
          break;
        case zl:
          return l = dt(12, a, t, u | 2), l.elementType = zl, l.lanes = n, l;
        case bt:
          return l = dt(13, a, t, u), l.elementType = bt, l.lanes = n, l;
        case Ll:
          return l = dt(19, a, t, u), l.elementType = Ll, l.lanes = n, l;
        default:
          if (typeof l == "object" && l !== null)
            switch (l.$$typeof) {
              case Yl:
                i = 10;
                break l;
              case Ut:
                i = 9;
                break l;
              case Il:
                i = 11;
                break l;
              case $:
                i = 14;
                break l;
              case Zl:
                i = 16, e = null;
                break l;
            }
          i = 29, a = Error(
            r(130, l === null ? "null" : typeof l, "")
          ), e = null;
      }
    return t = dt(i, a, t, u), t.elementType = l, t.type = e, t.lanes = n, t;
  }
  function Ha(l, t, a, e) {
    return l = dt(7, l, e, t), l.lanes = a, l;
  }
  function xi(l, t, a) {
    return l = dt(6, l, null, t), l.lanes = a, l;
  }
  function bs(l) {
    var t = dt(18, null, null, 0);
    return t.stateNode = l, t;
  }
  function _i(l, t, a) {
    return t = dt(
      4,
      l.children !== null ? l.children : [],
      l.key,
      t
    ), t.lanes = a, t.stateNode = {
      containerInfo: l.containerInfo,
      pendingChildren: null,
      implementation: l.implementation
    }, t;
  }
  var Ss = /* @__PURE__ */ new WeakMap();
  function Et(l, t) {
    if (typeof l == "object" && l !== null) {
      var a = Ss.get(l);
      return a !== void 0 ? a : (t = {
        value: l,
        source: t,
        stack: bf(t)
      }, Ss.set(l, t), t);
    }
    return {
      value: l,
      source: t,
      stack: bf(t)
    };
  }
  var ce = [], fe = 0, wu = null, Je = 0, At = [], xt = 0, ca = null, Ht = 1, Bt = "";
  function Zt(l, t) {
    ce[fe++] = Je, ce[fe++] = wu, wu = l, Je = t;
  }
  function ps(l, t, a) {
    At[xt++] = Ht, At[xt++] = Bt, At[xt++] = ca, ca = l;
    var e = Ht;
    l = Bt;
    var u = 32 - st(e) - 1;
    e &= ~(1 << u), a += 1;
    var n = 32 - st(t) + u;
    if (30 < n) {
      var i = u - u % 5;
      n = (e & (1 << i) - 1).toString(32), e >>= i, u -= i, Ht = 1 << 32 - st(t) + u | a << u | e, Bt = n + l;
    } else
      Ht = 1 << n | a << u | e, Bt = l;
  }
  function Ni(l) {
    l.return !== null && (Zt(l, 1), ps(l, 1, 0));
  }
  function Mi(l) {
    for (; l === wu; )
      wu = ce[--fe], ce[fe] = null, Je = ce[--fe], ce[fe] = null;
    for (; l === ca; )
      ca = At[--xt], At[xt] = null, Bt = At[--xt], At[xt] = null, Ht = At[--xt], At[xt] = null;
  }
  function Ts(l, t) {
    At[xt++] = Ht, At[xt++] = Bt, At[xt++] = ca, Ht = t.id, Bt = t.overflow, ca = l;
  }
  var Jl = null, pl = null, ll = !1, fa = null, _t = !1, Oi = Error(r(519));
  function sa(l) {
    var t = Error(
      r(
        418,
        1 < arguments.length && arguments[1] !== void 0 && arguments[1] ? "text" : "HTML",
        ""
      )
    );
    throw we(Et(t, l)), Oi;
  }
  function zs(l) {
    var t = l.stateNode, a = l.type, e = l.memoizedProps;
    switch (t[Kl] = l, t[lt] = e, a) {
      case "dialog":
        k("cancel", t), k("close", t);
        break;
      case "iframe":
      case "object":
      case "embed":
        k("load", t);
        break;
      case "video":
      case "audio":
        for (a = 0; a < vu.length; a++)
          k(vu[a], t);
        break;
      case "source":
        k("error", t);
        break;
      case "img":
      case "image":
      case "link":
        k("error", t), k("load", t);
        break;
      case "details":
        k("toggle", t);
        break;
      case "input":
        k("invalid", t), Hf(
          t,
          e.value,
          e.defaultValue,
          e.checked,
          e.defaultChecked,
          e.type,
          e.name,
          !0
        );
        break;
      case "select":
        k("invalid", t);
        break;
      case "textarea":
        k("invalid", t), qf(t, e.value, e.defaultValue, e.children);
    }
    a = e.children, typeof a != "string" && typeof a != "number" && typeof a != "bigint" || t.textContent === "" + a || e.suppressHydrationWarning === !0 || X0(t.textContent, a) ? (e.popover != null && (k("beforetoggle", t), k("toggle", t)), e.onScroll != null && k("scroll", t), e.onScrollEnd != null && k("scrollend", t), e.onClick != null && (t.onclick = Xt), t = !0) : t = !1, t || sa(l, !0);
  }
  function Es(l) {
    for (Jl = l.return; Jl; )
      switch (Jl.tag) {
        case 5:
        case 31:
        case 13:
          _t = !1;
          return;
        case 27:
        case 3:
          _t = !0;
          return;
        default:
          Jl = Jl.return;
      }
  }
  function se(l) {
    if (l !== Jl) return !1;
    if (!ll) return Es(l), ll = !0, !1;
    var t = l.tag, a;
    if ((a = t !== 3 && t !== 27) && ((a = t === 5) && (a = l.type, a = !(a !== "form" && a !== "button") || wc(l.type, l.memoizedProps)), a = !a), a && pl && sa(l), Es(l), t === 13) {
      if (l = l.memoizedState, l = l !== null ? l.dehydrated : null, !l) throw Error(r(317));
      pl = W0(l);
    } else if (t === 31) {
      if (l = l.memoizedState, l = l !== null ? l.dehydrated : null, !l) throw Error(r(317));
      pl = W0(l);
    } else
      t === 27 ? (t = pl, Ea(l.type) ? (l = Ic, Ic = null, pl = l) : pl = t) : pl = Jl ? Mt(l.stateNode.nextSibling) : null;
    return !0;
  }
  function Ba() {
    pl = Jl = null, ll = !1;
  }
  function Ui() {
    var l = fa;
    return l !== null && (nt === null ? nt = l : nt.push.apply(
      nt,
      l
    ), fa = null), l;
  }
  function we(l) {
    fa === null ? fa = [l] : fa.push(l);
  }
  var Di = o(null), qa = null, Vt = null;
  function oa(l, t, a) {
    O(Di, t._currentValue), t._currentValue = a;
  }
  function Kt(l) {
    l._currentValue = Di.current, z(Di);
  }
  function Ci(l, t, a) {
    for (; l !== null; ) {
      var e = l.alternate;
      if ((l.childLanes & t) !== t ? (l.childLanes |= t, e !== null && (e.childLanes |= t)) : e !== null && (e.childLanes & t) !== t && (e.childLanes |= t), l === a) break;
      l = l.return;
    }
  }
  function ji(l, t, a, e) {
    var u = l.child;
    for (u !== null && (u.return = l); u !== null; ) {
      var n = u.dependencies;
      if (n !== null) {
        var i = u.child;
        n = n.firstContext;
        l: for (; n !== null; ) {
          var c = n;
          n = u;
          for (var f = 0; f < t.length; f++)
            if (c.context === t[f]) {
              n.lanes |= a, c = n.alternate, c !== null && (c.lanes |= a), Ci(
                n.return,
                a,
                l
              ), e || (i = null);
              break l;
            }
          n = c.next;
        }
      } else if (u.tag === 18) {
        if (i = u.return, i === null) throw Error(r(341));
        i.lanes |= a, n = i.alternate, n !== null && (n.lanes |= a), Ci(i, a, l), i = null;
      } else i = u.child;
      if (i !== null) i.return = u;
      else
        for (i = u; i !== null; ) {
          if (i === l) {
            i = null;
            break;
          }
          if (u = i.sibling, u !== null) {
            u.return = i.return, i = u;
            break;
          }
          i = i.return;
        }
      u = i;
    }
  }
  function oe(l, t, a, e) {
    l = null;
    for (var u = t, n = !1; u !== null; ) {
      if (!n) {
        if ((u.flags & 524288) !== 0) n = !0;
        else if ((u.flags & 262144) !== 0) break;
      }
      if (u.tag === 10) {
        var i = u.alternate;
        if (i === null) throw Error(r(387));
        if (i = i.memoizedProps, i !== null) {
          var c = u.type;
          ot(u.pendingProps.value, i.value) || (l !== null ? l.push(c) : l = [c]);
        }
      } else if (u === al.current) {
        if (i = u.alternate, i === null) throw Error(r(387));
        i.memoizedState.memoizedState !== u.memoizedState.memoizedState && (l !== null ? l.push(pu) : l = [pu]);
      }
      u = u.return;
    }
    l !== null && ji(
      t,
      l,
      a,
      e
    ), t.flags |= 262144;
  }
  function $u(l) {
    for (l = l.firstContext; l !== null; ) {
      if (!ot(
        l.context._currentValue,
        l.memoizedValue
      ))
        return !0;
      l = l.next;
    }
    return !1;
  }
  function Ya(l) {
    qa = l, Vt = null, l = l.dependencies, l !== null && (l.firstContext = null);
  }
  function wl(l) {
    return As(qa, l);
  }
  function Wu(l, t) {
    return qa === null && Ya(l), As(l, t);
  }
  function As(l, t) {
    var a = t._currentValue;
    if (t = { context: t, memoizedValue: a, next: null }, Vt === null) {
      if (l === null) throw Error(r(308));
      Vt = t, l.dependencies = { lanes: 0, firstContext: t }, l.flags |= 524288;
    } else Vt = Vt.next = t;
    return a;
  }
  var Lr = typeof AbortController < "u" ? AbortController : function() {
    var l = [], t = this.signal = {
      aborted: !1,
      addEventListener: function(a, e) {
        l.push(e);
      }
    };
    this.abort = function() {
      t.aborted = !0, l.forEach(function(a) {
        return a();
      });
    };
  }, Zr = g.unstable_scheduleCallback, Vr = g.unstable_NormalPriority, jl = {
    $$typeof: Yl,
    Consumer: null,
    Provider: null,
    _currentValue: null,
    _currentValue2: null,
    _threadCount: 0
  };
  function Ri() {
    return {
      controller: new Lr(),
      data: /* @__PURE__ */ new Map(),
      refCount: 0
    };
  }
  function $e(l) {
    l.refCount--, l.refCount === 0 && Zr(Vr, function() {
      l.controller.abort();
    });
  }
  var We = null, Hi = 0, de = 0, re = null;
  function Kr(l, t) {
    if (We === null) {
      var a = We = [];
      Hi = 0, de = Yc(), re = {
        status: "pending",
        value: void 0,
        then: function(e) {
          a.push(e);
        }
      };
    }
    return Hi++, t.then(xs, xs), t;
  }
  function xs() {
    if (--Hi === 0 && We !== null) {
      re !== null && (re.status = "fulfilled");
      var l = We;
      We = null, de = 0, re = null;
      for (var t = 0; t < l.length; t++) (0, l[t])();
    }
  }
  function Jr(l, t) {
    var a = [], e = {
      status: "pending",
      value: null,
      reason: null,
      then: function(u) {
        a.push(u);
      }
    };
    return l.then(
      function() {
        e.status = "fulfilled", e.value = t;
        for (var u = 0; u < a.length; u++) (0, a[u])(t);
      },
      function(u) {
        for (e.status = "rejected", e.reason = u, u = 0; u < a.length; u++)
          (0, a[u])(void 0);
      }
    ), e;
  }
  var _s = b.S;
  b.S = function(l, t) {
    o0 = ct(), typeof t == "object" && t !== null && typeof t.then == "function" && Kr(l, t), _s !== null && _s(l, t);
  };
  var Ga = o(null);
  function Bi() {
    var l = Ga.current;
    return l !== null ? l : bl.pooledCache;
  }
  function ku(l, t) {
    t === null ? O(Ga, Ga.current) : O(Ga, t.pool);
  }
  function Ns() {
    var l = Bi();
    return l === null ? null : { parent: jl._currentValue, pool: l };
  }
  var me = Error(r(460)), qi = Error(r(474)), Fu = Error(r(542)), Iu = { then: function() {
  } };
  function Ms(l) {
    return l = l.status, l === "fulfilled" || l === "rejected";
  }
  function Os(l, t, a) {
    switch (a = l[a], a === void 0 ? l.push(t) : a !== t && (t.then(Xt, Xt), t = a), t.status) {
      case "fulfilled":
        return t.value;
      case "rejected":
        throw l = t.reason, Ds(l), l;
      default:
        if (typeof t.status == "string") t.then(Xt, Xt);
        else {
          if (l = bl, l !== null && 100 < l.shellSuspendCounter)
            throw Error(r(482));
          l = t, l.status = "pending", l.then(
            function(e) {
              if (t.status === "pending") {
                var u = t;
                u.status = "fulfilled", u.value = e;
              }
            },
            function(e) {
              if (t.status === "pending") {
                var u = t;
                u.status = "rejected", u.reason = e;
              }
            }
          );
        }
        switch (t.status) {
          case "fulfilled":
            return t.value;
          case "rejected":
            throw l = t.reason, Ds(l), l;
        }
        throw Qa = t, me;
    }
  }
  function Xa(l) {
    try {
      var t = l._init;
      return t(l._payload);
    } catch (a) {
      throw a !== null && typeof a == "object" && typeof a.then == "function" ? (Qa = a, me) : a;
    }
  }
  var Qa = null;
  function Us() {
    if (Qa === null) throw Error(r(459));
    var l = Qa;
    return Qa = null, l;
  }
  function Ds(l) {
    if (l === me || l === Fu)
      throw Error(r(483));
  }
  var ye = null, ke = 0;
  function Pu(l) {
    var t = ke;
    return ke += 1, ye === null && (ye = []), Os(ye, l, t);
  }
  function Fe(l, t) {
    t = t.props.ref, l.ref = t !== void 0 ? t : null;
  }
  function ln(l, t) {
    throw t.$$typeof === P ? Error(r(525)) : (l = Object.prototype.toString.call(t), Error(
      r(
        31,
        l === "[object Object]" ? "object with keys {" + Object.keys(t).join(", ") + "}" : l
      )
    ));
  }
  function Cs(l) {
    function t(d, s) {
      if (l) {
        var m = d.deletions;
        m === null ? (d.deletions = [s], d.flags |= 16) : m.push(s);
      }
    }
    function a(d, s) {
      if (!l) return null;
      for (; s !== null; )
        t(d, s), s = s.sibling;
      return null;
    }
    function e(d) {
      for (var s = /* @__PURE__ */ new Map(); d !== null; )
        d.key !== null ? s.set(d.key, d) : s.set(d.index, d), d = d.sibling;
      return s;
    }
    function u(d, s) {
      return d = Lt(d, s), d.index = 0, d.sibling = null, d;
    }
    function n(d, s, m) {
      return d.index = m, l ? (m = d.alternate, m !== null ? (m = m.index, m < s ? (d.flags |= 67108866, s) : m) : (d.flags |= 67108866, s)) : (d.flags |= 1048576, s);
    }
    function i(d) {
      return l && d.alternate === null && (d.flags |= 67108866), d;
    }
    function c(d, s, m, p) {
      return s === null || s.tag !== 6 ? (s = xi(m, d.mode, p), s.return = d, s) : (s = u(s, m), s.return = d, s);
    }
    function f(d, s, m, p) {
      var B = m.type;
      return B === Sl ? S(
        d,
        s,
        m.props.children,
        p,
        m.key
      ) : s !== null && (s.elementType === B || typeof B == "object" && B !== null && B.$$typeof === Zl && Xa(B) === s.type) ? (s = u(s, m.props), Fe(s, m), s.return = d, s) : (s = Ju(
        m.type,
        m.key,
        m.props,
        null,
        d.mode,
        p
      ), Fe(s, m), s.return = d, s);
    }
    function y(d, s, m, p) {
      return s === null || s.tag !== 4 || s.stateNode.containerInfo !== m.containerInfo || s.stateNode.implementation !== m.implementation ? (s = _i(m, d.mode, p), s.return = d, s) : (s = u(s, m.children || []), s.return = d, s);
    }
    function S(d, s, m, p, B) {
      return s === null || s.tag !== 7 ? (s = Ha(
        m,
        d.mode,
        p,
        B
      ), s.return = d, s) : (s = u(s, m), s.return = d, s);
    }
    function T(d, s, m) {
      if (typeof s == "string" && s !== "" || typeof s == "number" || typeof s == "bigint")
        return s = xi(
          "" + s,
          d.mode,
          m
        ), s.return = d, s;
      if (typeof s == "object" && s !== null) {
        switch (s.$$typeof) {
          case rl:
            return m = Ju(
              s.type,
              s.key,
              s.props,
              null,
              d.mode,
              m
            ), Fe(m, s), m.return = d, m;
          case _l:
            return s = _i(
              s,
              d.mode,
              m
            ), s.return = d, s;
          case Zl:
            return s = Xa(s), T(d, s, m);
        }
        if (ml(s) || Vl(s))
          return s = Ha(
            s,
            d.mode,
            m,
            null
          ), s.return = d, s;
        if (typeof s.then == "function")
          return T(d, Pu(s), m);
        if (s.$$typeof === Yl)
          return T(
            d,
            Wu(d, s),
            m
          );
        ln(d, s);
      }
      return null;
    }
    function v(d, s, m, p) {
      var B = s !== null ? s.key : null;
      if (typeof m == "string" && m !== "" || typeof m == "number" || typeof m == "bigint")
        return B !== null ? null : c(d, s, "" + m, p);
      if (typeof m == "object" && m !== null) {
        switch (m.$$typeof) {
          case rl:
            return m.key === B ? f(d, s, m, p) : null;
          case _l:
            return m.key === B ? y(d, s, m, p) : null;
          case Zl:
            return m = Xa(m), v(d, s, m, p);
        }
        if (ml(m) || Vl(m))
          return B !== null ? null : S(d, s, m, p, null);
        if (typeof m.then == "function")
          return v(
            d,
            s,
            Pu(m),
            p
          );
        if (m.$$typeof === Yl)
          return v(
            d,
            s,
            Wu(d, m),
            p
          );
        ln(d, m);
      }
      return null;
    }
    function h(d, s, m, p, B) {
      if (typeof p == "string" && p !== "" || typeof p == "number" || typeof p == "bigint")
        return d = d.get(m) || null, c(s, d, "" + p, B);
      if (typeof p == "object" && p !== null) {
        switch (p.$$typeof) {
          case rl:
            return d = d.get(
              p.key === null ? m : p.key
            ) || null, f(s, d, p, B);
          case _l:
            return d = d.get(
              p.key === null ? m : p.key
            ) || null, y(s, d, p, B);
          case Zl:
            return p = Xa(p), h(
              d,
              s,
              m,
              p,
              B
            );
        }
        if (ml(p) || Vl(p))
          return d = d.get(m) || null, S(s, d, p, B, null);
        if (typeof p.then == "function")
          return h(
            d,
            s,
            m,
            Pu(p),
            B
          );
        if (p.$$typeof === Yl)
          return h(
            d,
            s,
            m,
            Wu(s, p),
            B
          );
        ln(s, p);
      }
      return null;
    }
    function D(d, s, m, p) {
      for (var B = null, el = null, R = s, V = s = 0, I = null; R !== null && V < m.length; V++) {
        R.index > V ? (I = R, R = null) : I = R.sibling;
        var ul = v(
          d,
          R,
          m[V],
          p
        );
        if (ul === null) {
          R === null && (R = I);
          break;
        }
        l && R && ul.alternate === null && t(d, R), s = n(ul, s, V), el === null ? B = ul : el.sibling = ul, el = ul, R = I;
      }
      if (V === m.length)
        return a(d, R), ll && Zt(d, V), B;
      if (R === null) {
        for (; V < m.length; V++)
          R = T(d, m[V], p), R !== null && (s = n(
            R,
            s,
            V
          ), el === null ? B = R : el.sibling = R, el = R);
        return ll && Zt(d, V), B;
      }
      for (R = e(R); V < m.length; V++)
        I = h(
          R,
          d,
          V,
          m[V],
          p
        ), I !== null && (l && I.alternate !== null && R.delete(
          I.key === null ? V : I.key
        ), s = n(
          I,
          s,
          V
        ), el === null ? B = I : el.sibling = I, el = I);
      return l && R.forEach(function(Ma) {
        return t(d, Ma);
      }), ll && Zt(d, V), B;
    }
    function Y(d, s, m, p) {
      if (m == null) throw Error(r(151));
      for (var B = null, el = null, R = s, V = s = 0, I = null, ul = m.next(); R !== null && !ul.done; V++, ul = m.next()) {
        R.index > V ? (I = R, R = null) : I = R.sibling;
        var Ma = v(d, R, ul.value, p);
        if (Ma === null) {
          R === null && (R = I);
          break;
        }
        l && R && Ma.alternate === null && t(d, R), s = n(Ma, s, V), el === null ? B = Ma : el.sibling = Ma, el = Ma, R = I;
      }
      if (ul.done)
        return a(d, R), ll && Zt(d, V), B;
      if (R === null) {
        for (; !ul.done; V++, ul = m.next())
          ul = T(d, ul.value, p), ul !== null && (s = n(ul, s, V), el === null ? B = ul : el.sibling = ul, el = ul);
        return ll && Zt(d, V), B;
      }
      for (R = e(R); !ul.done; V++, ul = m.next())
        ul = h(R, d, V, ul.value, p), ul !== null && (l && ul.alternate !== null && R.delete(ul.key === null ? V : ul.key), s = n(ul, s, V), el === null ? B = ul : el.sibling = ul, el = ul);
      return l && R.forEach(function(ey) {
        return t(d, ey);
      }), ll && Zt(d, V), B;
    }
    function gl(d, s, m, p) {
      if (typeof m == "object" && m !== null && m.type === Sl && m.key === null && (m = m.props.children), typeof m == "object" && m !== null) {
        switch (m.$$typeof) {
          case rl:
            l: {
              for (var B = m.key; s !== null; ) {
                if (s.key === B) {
                  if (B = m.type, B === Sl) {
                    if (s.tag === 7) {
                      a(
                        d,
                        s.sibling
                      ), p = u(
                        s,
                        m.props.children
                      ), p.return = d, d = p;
                      break l;
                    }
                  } else if (s.elementType === B || typeof B == "object" && B !== null && B.$$typeof === Zl && Xa(B) === s.type) {
                    a(
                      d,
                      s.sibling
                    ), p = u(s, m.props), Fe(p, m), p.return = d, d = p;
                    break l;
                  }
                  a(d, s);
                  break;
                } else t(d, s);
                s = s.sibling;
              }
              m.type === Sl ? (p = Ha(
                m.props.children,
                d.mode,
                p,
                m.key
              ), p.return = d, d = p) : (p = Ju(
                m.type,
                m.key,
                m.props,
                null,
                d.mode,
                p
              ), Fe(p, m), p.return = d, d = p);
            }
            return i(d);
          case _l:
            l: {
              for (B = m.key; s !== null; ) {
                if (s.key === B)
                  if (s.tag === 4 && s.stateNode.containerInfo === m.containerInfo && s.stateNode.implementation === m.implementation) {
                    a(
                      d,
                      s.sibling
                    ), p = u(s, m.children || []), p.return = d, d = p;
                    break l;
                  } else {
                    a(d, s);
                    break;
                  }
                else t(d, s);
                s = s.sibling;
              }
              p = _i(m, d.mode, p), p.return = d, d = p;
            }
            return i(d);
          case Zl:
            return m = Xa(m), gl(
              d,
              s,
              m,
              p
            );
        }
        if (ml(m))
          return D(
            d,
            s,
            m,
            p
          );
        if (Vl(m)) {
          if (B = Vl(m), typeof B != "function") throw Error(r(150));
          return m = B.call(m), Y(
            d,
            s,
            m,
            p
          );
        }
        if (typeof m.then == "function")
          return gl(
            d,
            s,
            Pu(m),
            p
          );
        if (m.$$typeof === Yl)
          return gl(
            d,
            s,
            Wu(d, m),
            p
          );
        ln(d, m);
      }
      return typeof m == "string" && m !== "" || typeof m == "number" || typeof m == "bigint" ? (m = "" + m, s !== null && s.tag === 6 ? (a(d, s.sibling), p = u(s, m), p.return = d, d = p) : (a(d, s), p = xi(m, d.mode, p), p.return = d, d = p), i(d)) : a(d, s);
    }
    return function(d, s, m, p) {
      try {
        ke = 0;
        var B = gl(
          d,
          s,
          m,
          p
        );
        return ye = null, B;
      } catch (R) {
        if (R === me || R === Fu) throw R;
        var el = dt(29, R, null, d.mode);
        return el.lanes = p, el.return = d, el;
      }
    };
  }
  var La = Cs(!0), js = Cs(!1), da = !1;
  function Yi(l) {
    l.updateQueue = {
      baseState: l.memoizedState,
      firstBaseUpdate: null,
      lastBaseUpdate: null,
      shared: { pending: null, lanes: 0, hiddenCallbacks: null },
      callbacks: null
    };
  }
  function Gi(l, t) {
    l = l.updateQueue, t.updateQueue === l && (t.updateQueue = {
      baseState: l.baseState,
      firstBaseUpdate: l.firstBaseUpdate,
      lastBaseUpdate: l.lastBaseUpdate,
      shared: l.shared,
      callbacks: null
    });
  }
  function ra(l) {
    return { lane: l, tag: 0, payload: null, callback: null, next: null };
  }
  function ma(l, t, a) {
    var e = l.updateQueue;
    if (e === null) return null;
    if (e = e.shared, (il & 2) !== 0) {
      var u = e.pending;
      return u === null ? t.next = t : (t.next = u.next, u.next = t), e.pending = t, t = Ku(l), hs(l, null, a), t;
    }
    return Vu(l, e, t, a), Ku(l);
  }
  function Ie(l, t, a) {
    if (t = t.updateQueue, t !== null && (t = t.shared, (a & 4194048) !== 0)) {
      var e = t.lanes;
      e &= l.pendingLanes, a |= e, t.lanes = a, Af(l, a);
    }
  }
  function Xi(l, t) {
    var a = l.updateQueue, e = l.alternate;
    if (e !== null && (e = e.updateQueue, a === e)) {
      var u = null, n = null;
      if (a = a.firstBaseUpdate, a !== null) {
        do {
          var i = {
            lane: a.lane,
            tag: a.tag,
            payload: a.payload,
            callback: null,
            next: null
          };
          n === null ? u = n = i : n = n.next = i, a = a.next;
        } while (a !== null);
        n === null ? u = n = t : n = n.next = t;
      } else u = n = t;
      a = {
        baseState: e.baseState,
        firstBaseUpdate: u,
        lastBaseUpdate: n,
        shared: e.shared,
        callbacks: e.callbacks
      }, l.updateQueue = a;
      return;
    }
    l = a.lastBaseUpdate, l === null ? a.firstBaseUpdate = t : l.next = t, a.lastBaseUpdate = t;
  }
  var Qi = !1;
  function Pe() {
    if (Qi) {
      var l = re;
      if (l !== null) throw l;
    }
  }
  function lu(l, t, a, e) {
    Qi = !1;
    var u = l.updateQueue;
    da = !1;
    var n = u.firstBaseUpdate, i = u.lastBaseUpdate, c = u.shared.pending;
    if (c !== null) {
      u.shared.pending = null;
      var f = c, y = f.next;
      f.next = null, i === null ? n = y : i.next = y, i = f;
      var S = l.alternate;
      S !== null && (S = S.updateQueue, c = S.lastBaseUpdate, c !== i && (c === null ? S.firstBaseUpdate = y : c.next = y, S.lastBaseUpdate = f));
    }
    if (n !== null) {
      var T = u.baseState;
      i = 0, S = y = f = null, c = n;
      do {
        var v = c.lane & -536870913, h = v !== c.lane;
        if (h ? (F & v) === v : (e & v) === v) {
          v !== 0 && v === de && (Qi = !0), S !== null && (S = S.next = {
            lane: 0,
            tag: c.tag,
            payload: c.payload,
            callback: null,
            next: null
          });
          l: {
            var D = l, Y = c;
            v = t;
            var gl = a;
            switch (Y.tag) {
              case 1:
                if (D = Y.payload, typeof D == "function") {
                  T = D.call(gl, T, v);
                  break l;
                }
                T = D;
                break l;
              case 3:
                D.flags = D.flags & -65537 | 128;
              case 0:
                if (D = Y.payload, v = typeof D == "function" ? D.call(gl, T, v) : D, v == null) break l;
                T = j({}, T, v);
                break l;
              case 2:
                da = !0;
            }
          }
          v = c.callback, v !== null && (l.flags |= 64, h && (l.flags |= 8192), h = u.callbacks, h === null ? u.callbacks = [v] : h.push(v));
        } else
          h = {
            lane: v,
            tag: c.tag,
            payload: c.payload,
            callback: c.callback,
            next: null
          }, S === null ? (y = S = h, f = T) : S = S.next = h, i |= v;
        if (c = c.next, c === null) {
          if (c = u.shared.pending, c === null)
            break;
          h = c, c = h.next, h.next = null, u.lastBaseUpdate = h, u.shared.pending = null;
        }
      } while (!0);
      S === null && (f = T), u.baseState = f, u.firstBaseUpdate = y, u.lastBaseUpdate = S, n === null && (u.shared.lanes = 0), ba |= i, l.lanes = i, l.memoizedState = T;
    }
  }
  function Rs(l, t) {
    if (typeof l != "function")
      throw Error(r(191, l));
    l.call(t);
  }
  function Hs(l, t) {
    var a = l.callbacks;
    if (a !== null)
      for (l.callbacks = null, l = 0; l < a.length; l++)
        Rs(a[l], t);
  }
  var ve = o(null), tn = o(0);
  function Bs(l, t) {
    l = la, O(tn, l), O(ve, t), la = l | t.baseLanes;
  }
  function Li() {
    O(tn, la), O(ve, ve.current);
  }
  function Zi() {
    la = tn.current, z(ve), z(tn);
  }
  var rt = o(null), Nt = null;
  function ya(l) {
    var t = l.alternate;
    O(Ul, Ul.current & 1), O(rt, l), Nt === null && (t === null || ve.current !== null || t.memoizedState !== null) && (Nt = l);
  }
  function Vi(l) {
    O(Ul, Ul.current), O(rt, l), Nt === null && (Nt = l);
  }
  function qs(l) {
    l.tag === 22 ? (O(Ul, Ul.current), O(rt, l), Nt === null && (Nt = l)) : va();
  }
  function va() {
    O(Ul, Ul.current), O(rt, rt.current);
  }
  function mt(l) {
    z(rt), Nt === l && (Nt = null), z(Ul);
  }
  var Ul = o(0);
  function an(l) {
    for (var t = l; t !== null; ) {
      if (t.tag === 13) {
        var a = t.memoizedState;
        if (a !== null && (a = a.dehydrated, a === null || kc(a) || Fc(a)))
          return t;
      } else if (t.tag === 19 && (t.memoizedProps.revealOrder === "forwards" || t.memoizedProps.revealOrder === "backwards" || t.memoizedProps.revealOrder === "unstable_legacy-backwards" || t.memoizedProps.revealOrder === "together")) {
        if ((t.flags & 128) !== 0) return t;
      } else if (t.child !== null) {
        t.child.return = t, t = t.child;
        continue;
      }
      if (t === l) break;
      for (; t.sibling === null; ) {
        if (t.return === null || t.return === l) return null;
        t = t.return;
      }
      t.sibling.return = t.return, t = t.sibling;
    }
    return null;
  }
  var Jt = 0, Z = null, vl = null, Rl = null, en = !1, he = !1, Za = !1, un = 0, tu = 0, ge = null, wr = 0;
  function Nl() {
    throw Error(r(321));
  }
  function Ki(l, t) {
    if (t === null) return !1;
    for (var a = 0; a < t.length && a < l.length; a++)
      if (!ot(l[a], t[a])) return !1;
    return !0;
  }
  function Ji(l, t, a, e, u, n) {
    return Jt = n, Z = t, t.memoizedState = null, t.updateQueue = null, t.lanes = 0, b.H = l === null || l.memoizedState === null ? To : cc, Za = !1, n = a(e, u), Za = !1, he && (n = Gs(
      t,
      a,
      e,
      u
    )), Ys(l), n;
  }
  function Ys(l) {
    b.H = uu;
    var t = vl !== null && vl.next !== null;
    if (Jt = 0, Rl = vl = Z = null, en = !1, tu = 0, ge = null, t) throw Error(r(300));
    l === null || Hl || (l = l.dependencies, l !== null && $u(l) && (Hl = !0));
  }
  function Gs(l, t, a, e) {
    Z = l;
    var u = 0;
    do {
      if (he && (ge = null), tu = 0, he = !1, 25 <= u) throw Error(r(301));
      if (u += 1, Rl = vl = null, l.updateQueue != null) {
        var n = l.updateQueue;
        n.lastEffect = null, n.events = null, n.stores = null, n.memoCache != null && (n.memoCache.index = 0);
      }
      b.H = zo, n = t(a, e);
    } while (he);
    return n;
  }
  function $r() {
    var l = b.H, t = l.useState()[0];
    return t = typeof t.then == "function" ? au(t) : t, l = l.useState()[0], (vl !== null ? vl.memoizedState : null) !== l && (Z.flags |= 1024), t;
  }
  function wi() {
    var l = un !== 0;
    return un = 0, l;
  }
  function $i(l, t, a) {
    t.updateQueue = l.updateQueue, t.flags &= -2053, l.lanes &= ~a;
  }
  function Wi(l) {
    if (en) {
      for (l = l.memoizedState; l !== null; ) {
        var t = l.queue;
        t !== null && (t.pending = null), l = l.next;
      }
      en = !1;
    }
    Jt = 0, Rl = vl = Z = null, he = !1, tu = un = 0, ge = null;
  }
  function Pl() {
    var l = {
      memoizedState: null,
      baseState: null,
      baseQueue: null,
      queue: null,
      next: null
    };
    return Rl === null ? Z.memoizedState = Rl = l : Rl = Rl.next = l, Rl;
  }
  function Dl() {
    if (vl === null) {
      var l = Z.alternate;
      l = l !== null ? l.memoizedState : null;
    } else l = vl.next;
    var t = Rl === null ? Z.memoizedState : Rl.next;
    if (t !== null)
      Rl = t, vl = l;
    else {
      if (l === null)
        throw Z.alternate === null ? Error(r(467)) : Error(r(310));
      vl = l, l = {
        memoizedState: vl.memoizedState,
        baseState: vl.baseState,
        baseQueue: vl.baseQueue,
        queue: vl.queue,
        next: null
      }, Rl === null ? Z.memoizedState = Rl = l : Rl = Rl.next = l;
    }
    return Rl;
  }
  function nn() {
    return { lastEffect: null, events: null, stores: null, memoCache: null };
  }
  function au(l) {
    var t = tu;
    return tu += 1, ge === null && (ge = []), l = Os(ge, l, t), t = Z, (Rl === null ? t.memoizedState : Rl.next) === null && (t = t.alternate, b.H = t === null || t.memoizedState === null ? To : cc), l;
  }
  function cn(l) {
    if (l !== null && typeof l == "object") {
      if (typeof l.then == "function") return au(l);
      if (l.$$typeof === Yl) return wl(l);
    }
    throw Error(r(438, String(l)));
  }
  function ki(l) {
    var t = null, a = Z.updateQueue;
    if (a !== null && (t = a.memoCache), t == null) {
      var e = Z.alternate;
      e !== null && (e = e.updateQueue, e !== null && (e = e.memoCache, e != null && (t = {
        data: e.data.map(function(u) {
          return u.slice();
        }),
        index: 0
      })));
    }
    if (t == null && (t = { data: [], index: 0 }), a === null && (a = nn(), Z.updateQueue = a), a.memoCache = t, a = t.data[t.index], a === void 0)
      for (a = t.data[t.index] = Array(l), e = 0; e < l; e++)
        a[e] = Dt;
    return t.index++, a;
  }
  function wt(l, t) {
    return typeof t == "function" ? t(l) : t;
  }
  function fn(l) {
    var t = Dl();
    return Fi(t, vl, l);
  }
  function Fi(l, t, a) {
    var e = l.queue;
    if (e === null) throw Error(r(311));
    e.lastRenderedReducer = a;
    var u = l.baseQueue, n = e.pending;
    if (n !== null) {
      if (u !== null) {
        var i = u.next;
        u.next = n.next, n.next = i;
      }
      t.baseQueue = u = n, e.pending = null;
    }
    if (n = l.baseState, u === null) l.memoizedState = n;
    else {
      t = u.next;
      var c = i = null, f = null, y = t, S = !1;
      do {
        var T = y.lane & -536870913;
        if (T !== y.lane ? (F & T) === T : (Jt & T) === T) {
          var v = y.revertLane;
          if (v === 0)
            f !== null && (f = f.next = {
              lane: 0,
              revertLane: 0,
              gesture: null,
              action: y.action,
              hasEagerState: y.hasEagerState,
              eagerState: y.eagerState,
              next: null
            }), T === de && (S = !0);
          else if ((Jt & v) === v) {
            y = y.next, v === de && (S = !0);
            continue;
          } else
            T = {
              lane: 0,
              revertLane: y.revertLane,
              gesture: null,
              action: y.action,
              hasEagerState: y.hasEagerState,
              eagerState: y.eagerState,
              next: null
            }, f === null ? (c = f = T, i = n) : f = f.next = T, Z.lanes |= v, ba |= v;
          T = y.action, Za && a(n, T), n = y.hasEagerState ? y.eagerState : a(n, T);
        } else
          v = {
            lane: T,
            revertLane: y.revertLane,
            gesture: y.gesture,
            action: y.action,
            hasEagerState: y.hasEagerState,
            eagerState: y.eagerState,
            next: null
          }, f === null ? (c = f = v, i = n) : f = f.next = v, Z.lanes |= T, ba |= T;
        y = y.next;
      } while (y !== null && y !== t);
      if (f === null ? i = n : f.next = c, !ot(n, l.memoizedState) && (Hl = !0, S && (a = re, a !== null)))
        throw a;
      l.memoizedState = n, l.baseState = i, l.baseQueue = f, e.lastRenderedState = n;
    }
    return u === null && (e.lanes = 0), [l.memoizedState, e.dispatch];
  }
  function Ii(l) {
    var t = Dl(), a = t.queue;
    if (a === null) throw Error(r(311));
    a.lastRenderedReducer = l;
    var e = a.dispatch, u = a.pending, n = t.memoizedState;
    if (u !== null) {
      a.pending = null;
      var i = u = u.next;
      do
        n = l(n, i.action), i = i.next;
      while (i !== u);
      ot(n, t.memoizedState) || (Hl = !0), t.memoizedState = n, t.baseQueue === null && (t.baseState = n), a.lastRenderedState = n;
    }
    return [n, e];
  }
  function Xs(l, t, a) {
    var e = Z, u = Dl(), n = ll;
    if (n) {
      if (a === void 0) throw Error(r(407));
      a = a();
    } else a = t();
    var i = !ot(
      (vl || u).memoizedState,
      a
    );
    if (i && (u.memoizedState = a, Hl = !0), u = u.queue, tc(Zs.bind(null, e, u, l), [
      l
    ]), u.getSnapshot !== t || i || Rl !== null && Rl.memoizedState.tag & 1) {
      if (e.flags |= 2048, be(
        9,
        { destroy: void 0 },
        Ls.bind(
          null,
          e,
          u,
          a,
          t
        ),
        null
      ), bl === null) throw Error(r(349));
      n || (Jt & 127) !== 0 || Qs(e, t, a);
    }
    return a;
  }
  function Qs(l, t, a) {
    l.flags |= 16384, l = { getSnapshot: t, value: a }, t = Z.updateQueue, t === null ? (t = nn(), Z.updateQueue = t, t.stores = [l]) : (a = t.stores, a === null ? t.stores = [l] : a.push(l));
  }
  function Ls(l, t, a, e) {
    t.value = a, t.getSnapshot = e, Vs(t) && Ks(l);
  }
  function Zs(l, t, a) {
    return a(function() {
      Vs(t) && Ks(l);
    });
  }
  function Vs(l) {
    var t = l.getSnapshot;
    l = l.value;
    try {
      var a = t();
      return !ot(l, a);
    } catch {
      return !0;
    }
  }
  function Ks(l) {
    var t = Ra(l, 2);
    t !== null && it(t, l, 2);
  }
  function Pi(l) {
    var t = Pl();
    if (typeof l == "function") {
      var a = l;
      if (l = a(), Za) {
        ua(!0);
        try {
          a();
        } finally {
          ua(!1);
        }
      }
    }
    return t.memoizedState = t.baseState = l, t.queue = {
      pending: null,
      lanes: 0,
      dispatch: null,
      lastRenderedReducer: wt,
      lastRenderedState: l
    }, t;
  }
  function Js(l, t, a, e) {
    return l.baseState = a, Fi(
      l,
      vl,
      typeof e == "function" ? e : wt
    );
  }
  function Wr(l, t, a, e, u) {
    if (dn(l)) throw Error(r(485));
    if (l = t.action, l !== null) {
      var n = {
        payload: u,
        action: l,
        next: null,
        isTransition: !0,
        status: "pending",
        value: null,
        reason: null,
        listeners: [],
        then: function(i) {
          n.listeners.push(i);
        }
      };
      b.T !== null ? a(!0) : n.isTransition = !1, e(n), a = t.pending, a === null ? (n.next = t.pending = n, ws(t, n)) : (n.next = a.next, t.pending = a.next = n);
    }
  }
  function ws(l, t) {
    var a = t.action, e = t.payload, u = l.state;
    if (t.isTransition) {
      var n = b.T, i = {};
      b.T = i;
      try {
        var c = a(u, e), f = b.S;
        f !== null && f(i, c), $s(l, t, c);
      } catch (y) {
        lc(l, t, y);
      } finally {
        n !== null && i.types !== null && (n.types = i.types), b.T = n;
      }
    } else
      try {
        n = a(u, e), $s(l, t, n);
      } catch (y) {
        lc(l, t, y);
      }
  }
  function $s(l, t, a) {
    a !== null && typeof a == "object" && typeof a.then == "function" ? a.then(
      function(e) {
        Ws(l, t, e);
      },
      function(e) {
        return lc(l, t, e);
      }
    ) : Ws(l, t, a);
  }
  function Ws(l, t, a) {
    t.status = "fulfilled", t.value = a, ks(t), l.state = a, t = l.pending, t !== null && (a = t.next, a === t ? l.pending = null : (a = a.next, t.next = a, ws(l, a)));
  }
  function lc(l, t, a) {
    var e = l.pending;
    if (l.pending = null, e !== null) {
      e = e.next;
      do
        t.status = "rejected", t.reason = a, ks(t), t = t.next;
      while (t !== e);
    }
    l.action = null;
  }
  function ks(l) {
    l = l.listeners;
    for (var t = 0; t < l.length; t++) (0, l[t])();
  }
  function Fs(l, t) {
    return t;
  }
  function Is(l, t) {
    if (ll) {
      var a = bl.formState;
      if (a !== null) {
        l: {
          var e = Z;
          if (ll) {
            if (pl) {
              t: {
                for (var u = pl, n = _t; u.nodeType !== 8; ) {
                  if (!n) {
                    u = null;
                    break t;
                  }
                  if (u = Mt(
                    u.nextSibling
                  ), u === null) {
                    u = null;
                    break t;
                  }
                }
                n = u.data, u = n === "F!" || n === "F" ? u : null;
              }
              if (u) {
                pl = Mt(
                  u.nextSibling
                ), e = u.data === "F!";
                break l;
              }
            }
            sa(e);
          }
          e = !1;
        }
        e && (t = a[0]);
      }
    }
    return a = Pl(), a.memoizedState = a.baseState = t, e = {
      pending: null,
      lanes: 0,
      dispatch: null,
      lastRenderedReducer: Fs,
      lastRenderedState: t
    }, a.queue = e, a = bo.bind(
      null,
      Z,
      e
    ), e.dispatch = a, e = Pi(!1), n = ic.bind(
      null,
      Z,
      !1,
      e.queue
    ), e = Pl(), u = {
      state: t,
      dispatch: null,
      action: l,
      pending: null
    }, e.queue = u, a = Wr.bind(
      null,
      Z,
      u,
      n,
      a
    ), u.dispatch = a, e.memoizedState = l, [t, a, !1];
  }
  function Ps(l) {
    var t = Dl();
    return lo(t, vl, l);
  }
  function lo(l, t, a) {
    if (t = Fi(
      l,
      t,
      Fs
    )[0], l = fn(wt)[0], typeof t == "object" && t !== null && typeof t.then == "function")
      try {
        var e = au(t);
      } catch (i) {
        throw i === me ? Fu : i;
      }
    else e = t;
    t = Dl();
    var u = t.queue, n = u.dispatch;
    return a !== t.memoizedState && (Z.flags |= 2048, be(
      9,
      { destroy: void 0 },
      kr.bind(null, u, a),
      null
    )), [e, n, l];
  }
  function kr(l, t) {
    l.action = t;
  }
  function to(l) {
    var t = Dl(), a = vl;
    if (a !== null)
      return lo(t, a, l);
    Dl(), t = t.memoizedState, a = Dl();
    var e = a.queue.dispatch;
    return a.memoizedState = l, [t, e, !1];
  }
  function be(l, t, a, e) {
    return l = { tag: l, create: a, deps: e, inst: t, next: null }, t = Z.updateQueue, t === null && (t = nn(), Z.updateQueue = t), a = t.lastEffect, a === null ? t.lastEffect = l.next = l : (e = a.next, a.next = l, l.next = e, t.lastEffect = l), l;
  }
  function ao() {
    return Dl().memoizedState;
  }
  function sn(l, t, a, e) {
    var u = Pl();
    Z.flags |= l, u.memoizedState = be(
      1 | t,
      { destroy: void 0 },
      a,
      e === void 0 ? null : e
    );
  }
  function on(l, t, a, e) {
    var u = Dl();
    e = e === void 0 ? null : e;
    var n = u.memoizedState.inst;
    vl !== null && e !== null && Ki(e, vl.memoizedState.deps) ? u.memoizedState = be(t, n, a, e) : (Z.flags |= l, u.memoizedState = be(
      1 | t,
      n,
      a,
      e
    ));
  }
  function eo(l, t) {
    sn(8390656, 8, l, t);
  }
  function tc(l, t) {
    on(2048, 8, l, t);
  }
  function Fr(l) {
    Z.flags |= 4;
    var t = Z.updateQueue;
    if (t === null)
      t = nn(), Z.updateQueue = t, t.events = [l];
    else {
      var a = t.events;
      a === null ? t.events = [l] : a.push(l);
    }
  }
  function uo(l) {
    var t = Dl().memoizedState;
    return Fr({ ref: t, nextImpl: l }), function() {
      if ((il & 2) !== 0) throw Error(r(440));
      return t.impl.apply(void 0, arguments);
    };
  }
  function no(l, t) {
    return on(4, 2, l, t);
  }
  function io(l, t) {
    return on(4, 4, l, t);
  }
  function co(l, t) {
    if (typeof t == "function") {
      l = l();
      var a = t(l);
      return function() {
        typeof a == "function" ? a() : t(null);
      };
    }
    if (t != null)
      return l = l(), t.current = l, function() {
        t.current = null;
      };
  }
  function fo(l, t, a) {
    a = a != null ? a.concat([l]) : null, on(4, 4, co.bind(null, t, l), a);
  }
  function ac() {
  }
  function so(l, t) {
    var a = Dl();
    t = t === void 0 ? null : t;
    var e = a.memoizedState;
    return t !== null && Ki(t, e[1]) ? e[0] : (a.memoizedState = [l, t], l);
  }
  function oo(l, t) {
    var a = Dl();
    t = t === void 0 ? null : t;
    var e = a.memoizedState;
    if (t !== null && Ki(t, e[1]))
      return e[0];
    if (e = l(), Za) {
      ua(!0);
      try {
        l();
      } finally {
        ua(!1);
      }
    }
    return a.memoizedState = [e, t], e;
  }
  function ec(l, t, a) {
    return a === void 0 || (Jt & 1073741824) !== 0 && (F & 261930) === 0 ? l.memoizedState = t : (l.memoizedState = a, l = r0(), Z.lanes |= l, ba |= l, a);
  }
  function ro(l, t, a, e) {
    return ot(a, t) ? a : ve.current !== null ? (l = ec(l, a, e), ot(l, t) || (Hl = !0), l) : (Jt & 42) === 0 || (Jt & 1073741824) !== 0 && (F & 261930) === 0 ? (Hl = !0, l.memoizedState = a) : (l = r0(), Z.lanes |= l, ba |= l, t);
  }
  function mo(l, t, a, e, u) {
    var n = N.p;
    N.p = n !== 0 && 8 > n ? n : 8;
    var i = b.T, c = {};
    b.T = c, ic(l, !1, t, a);
    try {
      var f = u(), y = b.S;
      if (y !== null && y(c, f), f !== null && typeof f == "object" && typeof f.then == "function") {
        var S = Jr(
          f,
          e
        );
        eu(
          l,
          t,
          S,
          ht(l)
        );
      } else
        eu(
          l,
          t,
          e,
          ht(l)
        );
    } catch (T) {
      eu(
        l,
        t,
        { then: function() {
        }, status: "rejected", reason: T },
        ht()
      );
    } finally {
      N.p = n, i !== null && c.types !== null && (i.types = c.types), b.T = i;
    }
  }
  function Ir() {
  }
  function uc(l, t, a, e) {
    if (l.tag !== 5) throw Error(r(476));
    var u = yo(l).queue;
    mo(
      l,
      u,
      t,
      q,
      a === null ? Ir : function() {
        return vo(l), a(e);
      }
    );
  }
  function yo(l) {
    var t = l.memoizedState;
    if (t !== null) return t;
    t = {
      memoizedState: q,
      baseState: q,
      baseQueue: null,
      queue: {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: wt,
        lastRenderedState: q
      },
      next: null
    };
    var a = {};
    return t.next = {
      memoizedState: a,
      baseState: a,
      baseQueue: null,
      queue: {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: wt,
        lastRenderedState: a
      },
      next: null
    }, l.memoizedState = t, l = l.alternate, l !== null && (l.memoizedState = t), t;
  }
  function vo(l) {
    var t = yo(l);
    t.next === null && (t = l.alternate.memoizedState), eu(
      l,
      t.next.queue,
      {},
      ht()
    );
  }
  function nc() {
    return wl(pu);
  }
  function ho() {
    return Dl().memoizedState;
  }
  function go() {
    return Dl().memoizedState;
  }
  function Pr(l) {
    for (var t = l.return; t !== null; ) {
      switch (t.tag) {
        case 24:
        case 3:
          var a = ht();
          l = ra(a);
          var e = ma(t, l, a);
          e !== null && (it(e, t, a), Ie(e, t, a)), t = { cache: Ri() }, l.payload = t;
          return;
      }
      t = t.return;
    }
  }
  function lm(l, t, a) {
    var e = ht();
    a = {
      lane: e,
      revertLane: 0,
      gesture: null,
      action: a,
      hasEagerState: !1,
      eagerState: null,
      next: null
    }, dn(l) ? So(t, a) : (a = Ei(l, t, a, e), a !== null && (it(a, l, e), po(a, t, e)));
  }
  function bo(l, t, a) {
    var e = ht();
    eu(l, t, a, e);
  }
  function eu(l, t, a, e) {
    var u = {
      lane: e,
      revertLane: 0,
      gesture: null,
      action: a,
      hasEagerState: !1,
      eagerState: null,
      next: null
    };
    if (dn(l)) So(t, u);
    else {
      var n = l.alternate;
      if (l.lanes === 0 && (n === null || n.lanes === 0) && (n = t.lastRenderedReducer, n !== null))
        try {
          var i = t.lastRenderedState, c = n(i, a);
          if (u.hasEagerState = !0, u.eagerState = c, ot(c, i))
            return Vu(l, t, u, 0), bl === null && Zu(), !1;
        } catch {
        }
      if (a = Ei(l, t, u, e), a !== null)
        return it(a, l, e), po(a, t, e), !0;
    }
    return !1;
  }
  function ic(l, t, a, e) {
    if (e = {
      lane: 2,
      revertLane: Yc(),
      gesture: null,
      action: e,
      hasEagerState: !1,
      eagerState: null,
      next: null
    }, dn(l)) {
      if (t) throw Error(r(479));
    } else
      t = Ei(
        l,
        a,
        e,
        2
      ), t !== null && it(t, l, 2);
  }
  function dn(l) {
    var t = l.alternate;
    return l === Z || t !== null && t === Z;
  }
  function So(l, t) {
    he = en = !0;
    var a = l.pending;
    a === null ? t.next = t : (t.next = a.next, a.next = t), l.pending = t;
  }
  function po(l, t, a) {
    if ((a & 4194048) !== 0) {
      var e = t.lanes;
      e &= l.pendingLanes, a |= e, t.lanes = a, Af(l, a);
    }
  }
  var uu = {
    readContext: wl,
    use: cn,
    useCallback: Nl,
    useContext: Nl,
    useEffect: Nl,
    useImperativeHandle: Nl,
    useLayoutEffect: Nl,
    useInsertionEffect: Nl,
    useMemo: Nl,
    useReducer: Nl,
    useRef: Nl,
    useState: Nl,
    useDebugValue: Nl,
    useDeferredValue: Nl,
    useTransition: Nl,
    useSyncExternalStore: Nl,
    useId: Nl,
    useHostTransitionStatus: Nl,
    useFormState: Nl,
    useActionState: Nl,
    useOptimistic: Nl,
    useMemoCache: Nl,
    useCacheRefresh: Nl
  };
  uu.useEffectEvent = Nl;
  var To = {
    readContext: wl,
    use: cn,
    useCallback: function(l, t) {
      return Pl().memoizedState = [
        l,
        t === void 0 ? null : t
      ], l;
    },
    useContext: wl,
    useEffect: eo,
    useImperativeHandle: function(l, t, a) {
      a = a != null ? a.concat([l]) : null, sn(
        4194308,
        4,
        co.bind(null, t, l),
        a
      );
    },
    useLayoutEffect: function(l, t) {
      return sn(4194308, 4, l, t);
    },
    useInsertionEffect: function(l, t) {
      sn(4, 2, l, t);
    },
    useMemo: function(l, t) {
      var a = Pl();
      t = t === void 0 ? null : t;
      var e = l();
      if (Za) {
        ua(!0);
        try {
          l();
        } finally {
          ua(!1);
        }
      }
      return a.memoizedState = [e, t], e;
    },
    useReducer: function(l, t, a) {
      var e = Pl();
      if (a !== void 0) {
        var u = a(t);
        if (Za) {
          ua(!0);
          try {
            a(t);
          } finally {
            ua(!1);
          }
        }
      } else u = t;
      return e.memoizedState = e.baseState = u, l = {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: l,
        lastRenderedState: u
      }, e.queue = l, l = l.dispatch = lm.bind(
        null,
        Z,
        l
      ), [e.memoizedState, l];
    },
    useRef: function(l) {
      var t = Pl();
      return l = { current: l }, t.memoizedState = l;
    },
    useState: function(l) {
      l = Pi(l);
      var t = l.queue, a = bo.bind(null, Z, t);
      return t.dispatch = a, [l.memoizedState, a];
    },
    useDebugValue: ac,
    useDeferredValue: function(l, t) {
      var a = Pl();
      return ec(a, l, t);
    },
    useTransition: function() {
      var l = Pi(!1);
      return l = mo.bind(
        null,
        Z,
        l.queue,
        !0,
        !1
      ), Pl().memoizedState = l, [!1, l];
    },
    useSyncExternalStore: function(l, t, a) {
      var e = Z, u = Pl();
      if (ll) {
        if (a === void 0)
          throw Error(r(407));
        a = a();
      } else {
        if (a = t(), bl === null)
          throw Error(r(349));
        (F & 127) !== 0 || Qs(e, t, a);
      }
      u.memoizedState = a;
      var n = { value: a, getSnapshot: t };
      return u.queue = n, eo(Zs.bind(null, e, n, l), [
        l
      ]), e.flags |= 2048, be(
        9,
        { destroy: void 0 },
        Ls.bind(
          null,
          e,
          n,
          a,
          t
        ),
        null
      ), a;
    },
    useId: function() {
      var l = Pl(), t = bl.identifierPrefix;
      if (ll) {
        var a = Bt, e = Ht;
        a = (e & ~(1 << 32 - st(e) - 1)).toString(32) + a, t = "_" + t + "R_" + a, a = un++, 0 < a && (t += "H" + a.toString(32)), t += "_";
      } else
        a = wr++, t = "_" + t + "r_" + a.toString(32) + "_";
      return l.memoizedState = t;
    },
    useHostTransitionStatus: nc,
    useFormState: Is,
    useActionState: Is,
    useOptimistic: function(l) {
      var t = Pl();
      t.memoizedState = t.baseState = l;
      var a = {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: null,
        lastRenderedState: null
      };
      return t.queue = a, t = ic.bind(
        null,
        Z,
        !0,
        a
      ), a.dispatch = t, [l, t];
    },
    useMemoCache: ki,
    useCacheRefresh: function() {
      return Pl().memoizedState = Pr.bind(
        null,
        Z
      );
    },
    useEffectEvent: function(l) {
      var t = Pl(), a = { impl: l };
      return t.memoizedState = a, function() {
        if ((il & 2) !== 0)
          throw Error(r(440));
        return a.impl.apply(void 0, arguments);
      };
    }
  }, cc = {
    readContext: wl,
    use: cn,
    useCallback: so,
    useContext: wl,
    useEffect: tc,
    useImperativeHandle: fo,
    useInsertionEffect: no,
    useLayoutEffect: io,
    useMemo: oo,
    useReducer: fn,
    useRef: ao,
    useState: function() {
      return fn(wt);
    },
    useDebugValue: ac,
    useDeferredValue: function(l, t) {
      var a = Dl();
      return ro(
        a,
        vl.memoizedState,
        l,
        t
      );
    },
    useTransition: function() {
      var l = fn(wt)[0], t = Dl().memoizedState;
      return [
        typeof l == "boolean" ? l : au(l),
        t
      ];
    },
    useSyncExternalStore: Xs,
    useId: ho,
    useHostTransitionStatus: nc,
    useFormState: Ps,
    useActionState: Ps,
    useOptimistic: function(l, t) {
      var a = Dl();
      return Js(a, vl, l, t);
    },
    useMemoCache: ki,
    useCacheRefresh: go
  };
  cc.useEffectEvent = uo;
  var zo = {
    readContext: wl,
    use: cn,
    useCallback: so,
    useContext: wl,
    useEffect: tc,
    useImperativeHandle: fo,
    useInsertionEffect: no,
    useLayoutEffect: io,
    useMemo: oo,
    useReducer: Ii,
    useRef: ao,
    useState: function() {
      return Ii(wt);
    },
    useDebugValue: ac,
    useDeferredValue: function(l, t) {
      var a = Dl();
      return vl === null ? ec(a, l, t) : ro(
        a,
        vl.memoizedState,
        l,
        t
      );
    },
    useTransition: function() {
      var l = Ii(wt)[0], t = Dl().memoizedState;
      return [
        typeof l == "boolean" ? l : au(l),
        t
      ];
    },
    useSyncExternalStore: Xs,
    useId: ho,
    useHostTransitionStatus: nc,
    useFormState: to,
    useActionState: to,
    useOptimistic: function(l, t) {
      var a = Dl();
      return vl !== null ? Js(a, vl, l, t) : (a.baseState = l, [l, a.queue.dispatch]);
    },
    useMemoCache: ki,
    useCacheRefresh: go
  };
  zo.useEffectEvent = uo;
  function fc(l, t, a, e) {
    t = l.memoizedState, a = a(e, t), a = a == null ? t : j({}, t, a), l.memoizedState = a, l.lanes === 0 && (l.updateQueue.baseState = a);
  }
  var sc = {
    enqueueSetState: function(l, t, a) {
      l = l._reactInternals;
      var e = ht(), u = ra(e);
      u.payload = t, a != null && (u.callback = a), t = ma(l, u, e), t !== null && (it(t, l, e), Ie(t, l, e));
    },
    enqueueReplaceState: function(l, t, a) {
      l = l._reactInternals;
      var e = ht(), u = ra(e);
      u.tag = 1, u.payload = t, a != null && (u.callback = a), t = ma(l, u, e), t !== null && (it(t, l, e), Ie(t, l, e));
    },
    enqueueForceUpdate: function(l, t) {
      l = l._reactInternals;
      var a = ht(), e = ra(a);
      e.tag = 2, t != null && (e.callback = t), t = ma(l, e, a), t !== null && (it(t, l, a), Ie(t, l, a));
    }
  };
  function Eo(l, t, a, e, u, n, i) {
    return l = l.stateNode, typeof l.shouldComponentUpdate == "function" ? l.shouldComponentUpdate(e, n, i) : t.prototype && t.prototype.isPureReactComponent ? !Ve(a, e) || !Ve(u, n) : !0;
  }
  function Ao(l, t, a, e) {
    l = t.state, typeof t.componentWillReceiveProps == "function" && t.componentWillReceiveProps(a, e), typeof t.UNSAFE_componentWillReceiveProps == "function" && t.UNSAFE_componentWillReceiveProps(a, e), t.state !== l && sc.enqueueReplaceState(t, t.state, null);
  }
  function Va(l, t) {
    var a = t;
    if ("ref" in t) {
      a = {};
      for (var e in t)
        e !== "ref" && (a[e] = t[e]);
    }
    if (l = l.defaultProps) {
      a === t && (a = j({}, a));
      for (var u in l)
        a[u] === void 0 && (a[u] = l[u]);
    }
    return a;
  }
  function xo(l) {
    Lu(l);
  }
  function _o(l) {
    console.error(l);
  }
  function No(l) {
    Lu(l);
  }
  function rn(l, t) {
    try {
      var a = l.onUncaughtError;
      a(t.value, { componentStack: t.stack });
    } catch (e) {
      setTimeout(function() {
        throw e;
      });
    }
  }
  function Mo(l, t, a) {
    try {
      var e = l.onCaughtError;
      e(a.value, {
        componentStack: a.stack,
        errorBoundary: t.tag === 1 ? t.stateNode : null
      });
    } catch (u) {
      setTimeout(function() {
        throw u;
      });
    }
  }
  function oc(l, t, a) {
    return a = ra(a), a.tag = 3, a.payload = { element: null }, a.callback = function() {
      rn(l, t);
    }, a;
  }
  function Oo(l) {
    return l = ra(l), l.tag = 3, l;
  }
  function Uo(l, t, a, e) {
    var u = a.type.getDerivedStateFromError;
    if (typeof u == "function") {
      var n = e.value;
      l.payload = function() {
        return u(n);
      }, l.callback = function() {
        Mo(t, a, e);
      };
    }
    var i = a.stateNode;
    i !== null && typeof i.componentDidCatch == "function" && (l.callback = function() {
      Mo(t, a, e), typeof u != "function" && (Sa === null ? Sa = /* @__PURE__ */ new Set([this]) : Sa.add(this));
      var c = e.stack;
      this.componentDidCatch(e.value, {
        componentStack: c !== null ? c : ""
      });
    });
  }
  function tm(l, t, a, e, u) {
    if (a.flags |= 32768, e !== null && typeof e == "object" && typeof e.then == "function") {
      if (t = a.alternate, t !== null && oe(
        t,
        a,
        u,
        !0
      ), a = rt.current, a !== null) {
        switch (a.tag) {
          case 31:
          case 13:
            return Nt === null ? An() : a.alternate === null && Ml === 0 && (Ml = 3), a.flags &= -257, a.flags |= 65536, a.lanes = u, e === Iu ? a.flags |= 16384 : (t = a.updateQueue, t === null ? a.updateQueue = /* @__PURE__ */ new Set([e]) : t.add(e), Hc(l, e, u)), !1;
          case 22:
            return a.flags |= 65536, e === Iu ? a.flags |= 16384 : (t = a.updateQueue, t === null ? (t = {
              transitions: null,
              markerInstances: null,
              retryQueue: /* @__PURE__ */ new Set([e])
            }, a.updateQueue = t) : (a = t.retryQueue, a === null ? t.retryQueue = /* @__PURE__ */ new Set([e]) : a.add(e)), Hc(l, e, u)), !1;
        }
        throw Error(r(435, a.tag));
      }
      return Hc(l, e, u), An(), !1;
    }
    if (ll)
      return t = rt.current, t !== null ? ((t.flags & 65536) === 0 && (t.flags |= 256), t.flags |= 65536, t.lanes = u, e !== Oi && (l = Error(r(422), { cause: e }), we(Et(l, a)))) : (e !== Oi && (t = Error(r(423), {
        cause: e
      }), we(
        Et(t, a)
      )), l = l.current.alternate, l.flags |= 65536, u &= -u, l.lanes |= u, e = Et(e, a), u = oc(
        l.stateNode,
        e,
        u
      ), Xi(l, u), Ml !== 4 && (Ml = 2)), !1;
    var n = Error(r(520), { cause: e });
    if (n = Et(n, a), ru === null ? ru = [n] : ru.push(n), Ml !== 4 && (Ml = 2), t === null) return !0;
    e = Et(e, a), a = t;
    do {
      switch (a.tag) {
        case 3:
          return a.flags |= 65536, l = u & -u, a.lanes |= l, l = oc(a.stateNode, e, l), Xi(a, l), !1;
        case 1:
          if (t = a.type, n = a.stateNode, (a.flags & 128) === 0 && (typeof t.getDerivedStateFromError == "function" || n !== null && typeof n.componentDidCatch == "function" && (Sa === null || !Sa.has(n))))
            return a.flags |= 65536, u &= -u, a.lanes |= u, u = Oo(u), Uo(
              u,
              l,
              a,
              e
            ), Xi(a, u), !1;
      }
      a = a.return;
    } while (a !== null);
    return !1;
  }
  var dc = Error(r(461)), Hl = !1;
  function $l(l, t, a, e) {
    t.child = l === null ? js(t, null, a, e) : La(
      t,
      l.child,
      a,
      e
    );
  }
  function Do(l, t, a, e, u) {
    a = a.render;
    var n = t.ref;
    if ("ref" in e) {
      var i = {};
      for (var c in e)
        c !== "ref" && (i[c] = e[c]);
    } else i = e;
    return Ya(t), e = Ji(
      l,
      t,
      a,
      i,
      n,
      u
    ), c = wi(), l !== null && !Hl ? ($i(l, t, u), $t(l, t, u)) : (ll && c && Ni(t), t.flags |= 1, $l(l, t, e, u), t.child);
  }
  function Co(l, t, a, e, u) {
    if (l === null) {
      var n = a.type;
      return typeof n == "function" && !Ai(n) && n.defaultProps === void 0 && a.compare === null ? (t.tag = 15, t.type = n, jo(
        l,
        t,
        n,
        e,
        u
      )) : (l = Ju(
        a.type,
        null,
        e,
        t,
        t.mode,
        u
      ), l.ref = t.ref, l.return = t, t.child = l);
    }
    if (n = l.child, !Sc(l, u)) {
      var i = n.memoizedProps;
      if (a = a.compare, a = a !== null ? a : Ve, a(i, e) && l.ref === t.ref)
        return $t(l, t, u);
    }
    return t.flags |= 1, l = Lt(n, e), l.ref = t.ref, l.return = t, t.child = l;
  }
  function jo(l, t, a, e, u) {
    if (l !== null) {
      var n = l.memoizedProps;
      if (Ve(n, e) && l.ref === t.ref)
        if (Hl = !1, t.pendingProps = e = n, Sc(l, u))
          (l.flags & 131072) !== 0 && (Hl = !0);
        else
          return t.lanes = l.lanes, $t(l, t, u);
    }
    return rc(
      l,
      t,
      a,
      e,
      u
    );
  }
  function Ro(l, t, a, e) {
    var u = e.children, n = l !== null ? l.memoizedState : null;
    if (l === null && t.stateNode === null && (t.stateNode = {
      _visibility: 1,
      _pendingMarkers: null,
      _retryCache: null,
      _transitions: null
    }), e.mode === "hidden") {
      if ((t.flags & 128) !== 0) {
        if (n = n !== null ? n.baseLanes | a : a, l !== null) {
          for (e = t.child = l.child, u = 0; e !== null; )
            u = u | e.lanes | e.childLanes, e = e.sibling;
          e = u & ~n;
        } else e = 0, t.child = null;
        return Ho(
          l,
          t,
          n,
          a,
          e
        );
      }
      if ((a & 536870912) !== 0)
        t.memoizedState = { baseLanes: 0, cachePool: null }, l !== null && ku(
          t,
          n !== null ? n.cachePool : null
        ), n !== null ? Bs(t, n) : Li(), qs(t);
      else
        return e = t.lanes = 536870912, Ho(
          l,
          t,
          n !== null ? n.baseLanes | a : a,
          a,
          e
        );
    } else
      n !== null ? (ku(t, n.cachePool), Bs(t, n), va(), t.memoizedState = null) : (l !== null && ku(t, null), Li(), va());
    return $l(l, t, u, a), t.child;
  }
  function nu(l, t) {
    return l !== null && l.tag === 22 || t.stateNode !== null || (t.stateNode = {
      _visibility: 1,
      _pendingMarkers: null,
      _retryCache: null,
      _transitions: null
    }), t.sibling;
  }
  function Ho(l, t, a, e, u) {
    var n = Bi();
    return n = n === null ? null : { parent: jl._currentValue, pool: n }, t.memoizedState = {
      baseLanes: a,
      cachePool: n
    }, l !== null && ku(t, null), Li(), qs(t), l !== null && oe(l, t, e, !0), t.childLanes = u, null;
  }
  function mn(l, t) {
    return t = vn(
      { mode: t.mode, children: t.children },
      l.mode
    ), t.ref = l.ref, l.child = t, t.return = l, t;
  }
  function Bo(l, t, a) {
    return La(t, l.child, null, a), l = mn(t, t.pendingProps), l.flags |= 2, mt(t), t.memoizedState = null, l;
  }
  function am(l, t, a) {
    var e = t.pendingProps, u = (t.flags & 128) !== 0;
    if (t.flags &= -129, l === null) {
      if (ll) {
        if (e.mode === "hidden")
          return l = mn(t, e), t.lanes = 536870912, nu(null, l);
        if (Vi(t), (l = pl) ? (l = $0(
          l,
          _t
        ), l = l !== null && l.data === "&" ? l : null, l !== null && (t.memoizedState = {
          dehydrated: l,
          treeContext: ca !== null ? { id: Ht, overflow: Bt } : null,
          retryLane: 536870912,
          hydrationErrors: null
        }, a = bs(l), a.return = t, t.child = a, Jl = t, pl = null)) : l = null, l === null) throw sa(t);
        return t.lanes = 536870912, null;
      }
      return mn(t, e);
    }
    var n = l.memoizedState;
    if (n !== null) {
      var i = n.dehydrated;
      if (Vi(t), u)
        if (t.flags & 256)
          t.flags &= -257, t = Bo(
            l,
            t,
            a
          );
        else if (t.memoizedState !== null)
          t.child = l.child, t.flags |= 128, t = null;
        else throw Error(r(558));
      else if (Hl || oe(l, t, a, !1), u = (a & l.childLanes) !== 0, Hl || u) {
        if (e = bl, e !== null && (i = xf(e, a), i !== 0 && i !== n.retryLane))
          throw n.retryLane = i, Ra(l, i), it(e, l, i), dc;
        An(), t = Bo(
          l,
          t,
          a
        );
      } else
        l = n.treeContext, pl = Mt(i.nextSibling), Jl = t, ll = !0, fa = null, _t = !1, l !== null && Ts(t, l), t = mn(t, e), t.flags |= 4096;
      return t;
    }
    return l = Lt(l.child, {
      mode: e.mode,
      children: e.children
    }), l.ref = t.ref, t.child = l, l.return = t, l;
  }
  function yn(l, t) {
    var a = t.ref;
    if (a === null)
      l !== null && l.ref !== null && (t.flags |= 4194816);
    else {
      if (typeof a != "function" && typeof a != "object")
        throw Error(r(284));
      (l === null || l.ref !== a) && (t.flags |= 4194816);
    }
  }
  function rc(l, t, a, e, u) {
    return Ya(t), a = Ji(
      l,
      t,
      a,
      e,
      void 0,
      u
    ), e = wi(), l !== null && !Hl ? ($i(l, t, u), $t(l, t, u)) : (ll && e && Ni(t), t.flags |= 1, $l(l, t, a, u), t.child);
  }
  function qo(l, t, a, e, u, n) {
    return Ya(t), t.updateQueue = null, a = Gs(
      t,
      e,
      a,
      u
    ), Ys(l), e = wi(), l !== null && !Hl ? ($i(l, t, n), $t(l, t, n)) : (ll && e && Ni(t), t.flags |= 1, $l(l, t, a, n), t.child);
  }
  function Yo(l, t, a, e, u) {
    if (Ya(t), t.stateNode === null) {
      var n = ie, i = a.contextType;
      typeof i == "object" && i !== null && (n = wl(i)), n = new a(e, n), t.memoizedState = n.state !== null && n.state !== void 0 ? n.state : null, n.updater = sc, t.stateNode = n, n._reactInternals = t, n = t.stateNode, n.props = e, n.state = t.memoizedState, n.refs = {}, Yi(t), i = a.contextType, n.context = typeof i == "object" && i !== null ? wl(i) : ie, n.state = t.memoizedState, i = a.getDerivedStateFromProps, typeof i == "function" && (fc(
        t,
        a,
        i,
        e
      ), n.state = t.memoizedState), typeof a.getDerivedStateFromProps == "function" || typeof n.getSnapshotBeforeUpdate == "function" || typeof n.UNSAFE_componentWillMount != "function" && typeof n.componentWillMount != "function" || (i = n.state, typeof n.componentWillMount == "function" && n.componentWillMount(), typeof n.UNSAFE_componentWillMount == "function" && n.UNSAFE_componentWillMount(), i !== n.state && sc.enqueueReplaceState(n, n.state, null), lu(t, e, n, u), Pe(), n.state = t.memoizedState), typeof n.componentDidMount == "function" && (t.flags |= 4194308), e = !0;
    } else if (l === null) {
      n = t.stateNode;
      var c = t.memoizedProps, f = Va(a, c);
      n.props = f;
      var y = n.context, S = a.contextType;
      i = ie, typeof S == "object" && S !== null && (i = wl(S));
      var T = a.getDerivedStateFromProps;
      S = typeof T == "function" || typeof n.getSnapshotBeforeUpdate == "function", c = t.pendingProps !== c, S || typeof n.UNSAFE_componentWillReceiveProps != "function" && typeof n.componentWillReceiveProps != "function" || (c || y !== i) && Ao(
        t,
        n,
        e,
        i
      ), da = !1;
      var v = t.memoizedState;
      n.state = v, lu(t, e, n, u), Pe(), y = t.memoizedState, c || v !== y || da ? (typeof T == "function" && (fc(
        t,
        a,
        T,
        e
      ), y = t.memoizedState), (f = da || Eo(
        t,
        a,
        f,
        e,
        v,
        y,
        i
      )) ? (S || typeof n.UNSAFE_componentWillMount != "function" && typeof n.componentWillMount != "function" || (typeof n.componentWillMount == "function" && n.componentWillMount(), typeof n.UNSAFE_componentWillMount == "function" && n.UNSAFE_componentWillMount()), typeof n.componentDidMount == "function" && (t.flags |= 4194308)) : (typeof n.componentDidMount == "function" && (t.flags |= 4194308), t.memoizedProps = e, t.memoizedState = y), n.props = e, n.state = y, n.context = i, e = f) : (typeof n.componentDidMount == "function" && (t.flags |= 4194308), e = !1);
    } else {
      n = t.stateNode, Gi(l, t), i = t.memoizedProps, S = Va(a, i), n.props = S, T = t.pendingProps, v = n.context, y = a.contextType, f = ie, typeof y == "object" && y !== null && (f = wl(y)), c = a.getDerivedStateFromProps, (y = typeof c == "function" || typeof n.getSnapshotBeforeUpdate == "function") || typeof n.UNSAFE_componentWillReceiveProps != "function" && typeof n.componentWillReceiveProps != "function" || (i !== T || v !== f) && Ao(
        t,
        n,
        e,
        f
      ), da = !1, v = t.memoizedState, n.state = v, lu(t, e, n, u), Pe();
      var h = t.memoizedState;
      i !== T || v !== h || da || l !== null && l.dependencies !== null && $u(l.dependencies) ? (typeof c == "function" && (fc(
        t,
        a,
        c,
        e
      ), h = t.memoizedState), (S = da || Eo(
        t,
        a,
        S,
        e,
        v,
        h,
        f
      ) || l !== null && l.dependencies !== null && $u(l.dependencies)) ? (y || typeof n.UNSAFE_componentWillUpdate != "function" && typeof n.componentWillUpdate != "function" || (typeof n.componentWillUpdate == "function" && n.componentWillUpdate(e, h, f), typeof n.UNSAFE_componentWillUpdate == "function" && n.UNSAFE_componentWillUpdate(
        e,
        h,
        f
      )), typeof n.componentDidUpdate == "function" && (t.flags |= 4), typeof n.getSnapshotBeforeUpdate == "function" && (t.flags |= 1024)) : (typeof n.componentDidUpdate != "function" || i === l.memoizedProps && v === l.memoizedState || (t.flags |= 4), typeof n.getSnapshotBeforeUpdate != "function" || i === l.memoizedProps && v === l.memoizedState || (t.flags |= 1024), t.memoizedProps = e, t.memoizedState = h), n.props = e, n.state = h, n.context = f, e = S) : (typeof n.componentDidUpdate != "function" || i === l.memoizedProps && v === l.memoizedState || (t.flags |= 4), typeof n.getSnapshotBeforeUpdate != "function" || i === l.memoizedProps && v === l.memoizedState || (t.flags |= 1024), e = !1);
    }
    return n = e, yn(l, t), e = (t.flags & 128) !== 0, n || e ? (n = t.stateNode, a = e && typeof a.getDerivedStateFromError != "function" ? null : n.render(), t.flags |= 1, l !== null && e ? (t.child = La(
      t,
      l.child,
      null,
      u
    ), t.child = La(
      t,
      null,
      a,
      u
    )) : $l(l, t, a, u), t.memoizedState = n.state, l = t.child) : l = $t(
      l,
      t,
      u
    ), l;
  }
  function Go(l, t, a, e) {
    return Ba(), t.flags |= 256, $l(l, t, a, e), t.child;
  }
  var mc = {
    dehydrated: null,
    treeContext: null,
    retryLane: 0,
    hydrationErrors: null
  };
  function yc(l) {
    return { baseLanes: l, cachePool: Ns() };
  }
  function vc(l, t, a) {
    return l = l !== null ? l.childLanes & ~a : 0, t && (l |= vt), l;
  }
  function Xo(l, t, a) {
    var e = t.pendingProps, u = !1, n = (t.flags & 128) !== 0, i;
    if ((i = n) || (i = l !== null && l.memoizedState === null ? !1 : (Ul.current & 2) !== 0), i && (u = !0, t.flags &= -129), i = (t.flags & 32) !== 0, t.flags &= -33, l === null) {
      if (ll) {
        if (u ? ya(t) : va(), (l = pl) ? (l = $0(
          l,
          _t
        ), l = l !== null && l.data !== "&" ? l : null, l !== null && (t.memoizedState = {
          dehydrated: l,
          treeContext: ca !== null ? { id: Ht, overflow: Bt } : null,
          retryLane: 536870912,
          hydrationErrors: null
        }, a = bs(l), a.return = t, t.child = a, Jl = t, pl = null)) : l = null, l === null) throw sa(t);
        return Fc(l) ? t.lanes = 32 : t.lanes = 536870912, null;
      }
      var c = e.children;
      return e = e.fallback, u ? (va(), u = t.mode, c = vn(
        { mode: "hidden", children: c },
        u
      ), e = Ha(
        e,
        u,
        a,
        null
      ), c.return = t, e.return = t, c.sibling = e, t.child = c, e = t.child, e.memoizedState = yc(a), e.childLanes = vc(
        l,
        i,
        a
      ), t.memoizedState = mc, nu(null, e)) : (ya(t), hc(t, c));
    }
    var f = l.memoizedState;
    if (f !== null && (c = f.dehydrated, c !== null)) {
      if (n)
        t.flags & 256 ? (ya(t), t.flags &= -257, t = gc(
          l,
          t,
          a
        )) : t.memoizedState !== null ? (va(), t.child = l.child, t.flags |= 128, t = null) : (va(), c = e.fallback, u = t.mode, e = vn(
          { mode: "visible", children: e.children },
          u
        ), c = Ha(
          c,
          u,
          a,
          null
        ), c.flags |= 2, e.return = t, c.return = t, e.sibling = c, t.child = e, La(
          t,
          l.child,
          null,
          a
        ), e = t.child, e.memoizedState = yc(a), e.childLanes = vc(
          l,
          i,
          a
        ), t.memoizedState = mc, t = nu(null, e));
      else if (ya(t), Fc(c)) {
        if (i = c.nextSibling && c.nextSibling.dataset, i) var y = i.dgst;
        i = y, e = Error(r(419)), e.stack = "", e.digest = i, we({ value: e, source: null, stack: null }), t = gc(
          l,
          t,
          a
        );
      } else if (Hl || oe(l, t, a, !1), i = (a & l.childLanes) !== 0, Hl || i) {
        if (i = bl, i !== null && (e = xf(i, a), e !== 0 && e !== f.retryLane))
          throw f.retryLane = e, Ra(l, e), it(i, l, e), dc;
        kc(c) || An(), t = gc(
          l,
          t,
          a
        );
      } else
        kc(c) ? (t.flags |= 192, t.child = l.child, t = null) : (l = f.treeContext, pl = Mt(
          c.nextSibling
        ), Jl = t, ll = !0, fa = null, _t = !1, l !== null && Ts(t, l), t = hc(
          t,
          e.children
        ), t.flags |= 4096);
      return t;
    }
    return u ? (va(), c = e.fallback, u = t.mode, f = l.child, y = f.sibling, e = Lt(f, {
      mode: "hidden",
      children: e.children
    }), e.subtreeFlags = f.subtreeFlags & 65011712, y !== null ? c = Lt(
      y,
      c
    ) : (c = Ha(
      c,
      u,
      a,
      null
    ), c.flags |= 2), c.return = t, e.return = t, e.sibling = c, t.child = e, nu(null, e), e = t.child, c = l.child.memoizedState, c === null ? c = yc(a) : (u = c.cachePool, u !== null ? (f = jl._currentValue, u = u.parent !== f ? { parent: f, pool: f } : u) : u = Ns(), c = {
      baseLanes: c.baseLanes | a,
      cachePool: u
    }), e.memoizedState = c, e.childLanes = vc(
      l,
      i,
      a
    ), t.memoizedState = mc, nu(l.child, e)) : (ya(t), a = l.child, l = a.sibling, a = Lt(a, {
      mode: "visible",
      children: e.children
    }), a.return = t, a.sibling = null, l !== null && (i = t.deletions, i === null ? (t.deletions = [l], t.flags |= 16) : i.push(l)), t.child = a, t.memoizedState = null, a);
  }
  function hc(l, t) {
    return t = vn(
      { mode: "visible", children: t },
      l.mode
    ), t.return = l, l.child = t;
  }
  function vn(l, t) {
    return l = dt(22, l, null, t), l.lanes = 0, l;
  }
  function gc(l, t, a) {
    return La(t, l.child, null, a), l = hc(
      t,
      t.pendingProps.children
    ), l.flags |= 2, t.memoizedState = null, l;
  }
  function Qo(l, t, a) {
    l.lanes |= t;
    var e = l.alternate;
    e !== null && (e.lanes |= t), Ci(l.return, t, a);
  }
  function bc(l, t, a, e, u, n) {
    var i = l.memoizedState;
    i === null ? l.memoizedState = {
      isBackwards: t,
      rendering: null,
      renderingStartTime: 0,
      last: e,
      tail: a,
      tailMode: u,
      treeForkCount: n
    } : (i.isBackwards = t, i.rendering = null, i.renderingStartTime = 0, i.last = e, i.tail = a, i.tailMode = u, i.treeForkCount = n);
  }
  function Lo(l, t, a) {
    var e = t.pendingProps, u = e.revealOrder, n = e.tail;
    e = e.children;
    var i = Ul.current, c = (i & 2) !== 0;
    if (c ? (i = i & 1 | 2, t.flags |= 128) : i &= 1, O(Ul, i), $l(l, t, e, a), e = ll ? Je : 0, !c && l !== null && (l.flags & 128) !== 0)
      l: for (l = t.child; l !== null; ) {
        if (l.tag === 13)
          l.memoizedState !== null && Qo(l, a, t);
        else if (l.tag === 19)
          Qo(l, a, t);
        else if (l.child !== null) {
          l.child.return = l, l = l.child;
          continue;
        }
        if (l === t) break l;
        for (; l.sibling === null; ) {
          if (l.return === null || l.return === t)
            break l;
          l = l.return;
        }
        l.sibling.return = l.return, l = l.sibling;
      }
    switch (u) {
      case "forwards":
        for (a = t.child, u = null; a !== null; )
          l = a.alternate, l !== null && an(l) === null && (u = a), a = a.sibling;
        a = u, a === null ? (u = t.child, t.child = null) : (u = a.sibling, a.sibling = null), bc(
          t,
          !1,
          u,
          a,
          n,
          e
        );
        break;
      case "backwards":
      case "unstable_legacy-backwards":
        for (a = null, u = t.child, t.child = null; u !== null; ) {
          if (l = u.alternate, l !== null && an(l) === null) {
            t.child = u;
            break;
          }
          l = u.sibling, u.sibling = a, a = u, u = l;
        }
        bc(
          t,
          !0,
          a,
          null,
          n,
          e
        );
        break;
      case "together":
        bc(
          t,
          !1,
          null,
          null,
          void 0,
          e
        );
        break;
      default:
        t.memoizedState = null;
    }
    return t.child;
  }
  function $t(l, t, a) {
    if (l !== null && (t.dependencies = l.dependencies), ba |= t.lanes, (a & t.childLanes) === 0)
      if (l !== null) {
        if (oe(
          l,
          t,
          a,
          !1
        ), (a & t.childLanes) === 0)
          return null;
      } else return null;
    if (l !== null && t.child !== l.child)
      throw Error(r(153));
    if (t.child !== null) {
      for (l = t.child, a = Lt(l, l.pendingProps), t.child = a, a.return = t; l.sibling !== null; )
        l = l.sibling, a = a.sibling = Lt(l, l.pendingProps), a.return = t;
      a.sibling = null;
    }
    return t.child;
  }
  function Sc(l, t) {
    return (l.lanes & t) !== 0 ? !0 : (l = l.dependencies, !!(l !== null && $u(l)));
  }
  function em(l, t, a) {
    switch (t.tag) {
      case 3:
        Ol(t, t.stateNode.containerInfo), oa(t, jl, l.memoizedState.cache), Ba();
        break;
      case 27:
      case 5:
        M(t);
        break;
      case 4:
        Ol(t, t.stateNode.containerInfo);
        break;
      case 10:
        oa(
          t,
          t.type,
          t.memoizedProps.value
        );
        break;
      case 31:
        if (t.memoizedState !== null)
          return t.flags |= 128, Vi(t), null;
        break;
      case 13:
        var e = t.memoizedState;
        if (e !== null)
          return e.dehydrated !== null ? (ya(t), t.flags |= 128, null) : (a & t.child.childLanes) !== 0 ? Xo(l, t, a) : (ya(t), l = $t(
            l,
            t,
            a
          ), l !== null ? l.sibling : null);
        ya(t);
        break;
      case 19:
        var u = (l.flags & 128) !== 0;
        if (e = (a & t.childLanes) !== 0, e || (oe(
          l,
          t,
          a,
          !1
        ), e = (a & t.childLanes) !== 0), u) {
          if (e)
            return Lo(
              l,
              t,
              a
            );
          t.flags |= 128;
        }
        if (u = t.memoizedState, u !== null && (u.rendering = null, u.tail = null, u.lastEffect = null), O(Ul, Ul.current), e) break;
        return null;
      case 22:
        return t.lanes = 0, Ro(
          l,
          t,
          a,
          t.pendingProps
        );
      case 24:
        oa(t, jl, l.memoizedState.cache);
    }
    return $t(l, t, a);
  }
  function Zo(l, t, a) {
    if (l !== null)
      if (l.memoizedProps !== t.pendingProps)
        Hl = !0;
      else {
        if (!Sc(l, a) && (t.flags & 128) === 0)
          return Hl = !1, em(
            l,
            t,
            a
          );
        Hl = (l.flags & 131072) !== 0;
      }
    else
      Hl = !1, ll && (t.flags & 1048576) !== 0 && ps(t, Je, t.index);
    switch (t.lanes = 0, t.tag) {
      case 16:
        l: {
          var e = t.pendingProps;
          if (l = Xa(t.elementType), t.type = l, typeof l == "function")
            Ai(l) ? (e = Va(l, e), t.tag = 1, t = Yo(
              null,
              t,
              l,
              e,
              a
            )) : (t.tag = 0, t = rc(
              null,
              t,
              l,
              e,
              a
            ));
          else {
            if (l != null) {
              var u = l.$$typeof;
              if (u === Il) {
                t.tag = 11, t = Do(
                  null,
                  t,
                  l,
                  e,
                  a
                );
                break l;
              } else if (u === $) {
                t.tag = 14, t = Co(
                  null,
                  t,
                  l,
                  e,
                  a
                );
                break l;
              }
            }
            throw t = kl(l) || l, Error(r(306, t, ""));
          }
        }
        return t;
      case 0:
        return rc(
          l,
          t,
          t.type,
          t.pendingProps,
          a
        );
      case 1:
        return e = t.type, u = Va(
          e,
          t.pendingProps
        ), Yo(
          l,
          t,
          e,
          u,
          a
        );
      case 3:
        l: {
          if (Ol(
            t,
            t.stateNode.containerInfo
          ), l === null) throw Error(r(387));
          e = t.pendingProps;
          var n = t.memoizedState;
          u = n.element, Gi(l, t), lu(t, e, null, a);
          var i = t.memoizedState;
          if (e = i.cache, oa(t, jl, e), e !== n.cache && ji(
            t,
            [jl],
            a,
            !0
          ), Pe(), e = i.element, n.isDehydrated)
            if (n = {
              element: e,
              isDehydrated: !1,
              cache: i.cache
            }, t.updateQueue.baseState = n, t.memoizedState = n, t.flags & 256) {
              t = Go(
                l,
                t,
                e,
                a
              );
              break l;
            } else if (e !== u) {
              u = Et(
                Error(r(424)),
                t
              ), we(u), t = Go(
                l,
                t,
                e,
                a
              );
              break l;
            } else
              for (l = t.stateNode.containerInfo, l.nodeType === 9 ? l = l.body : l = l.nodeName === "HTML" ? l.ownerDocument.body : l, pl = Mt(l.firstChild), Jl = t, ll = !0, fa = null, _t = !0, a = js(
                t,
                null,
                e,
                a
              ), t.child = a; a; )
                a.flags = a.flags & -3 | 4096, a = a.sibling;
          else {
            if (Ba(), e === u) {
              t = $t(
                l,
                t,
                a
              );
              break l;
            }
            $l(l, t, e, a);
          }
          t = t.child;
        }
        return t;
      case 26:
        return yn(l, t), l === null ? (a = ld(
          t.type,
          null,
          t.pendingProps,
          null
        )) ? t.memoizedState = a : ll || (a = t.type, l = t.pendingProps, e = Dn(
          K.current
        ).createElement(a), e[Kl] = t, e[lt] = l, Wl(e, a, l), Xl(e), t.stateNode = e) : t.memoizedState = ld(
          t.type,
          l.memoizedProps,
          t.pendingProps,
          l.memoizedState
        ), null;
      case 27:
        return M(t), l === null && ll && (e = t.stateNode = F0(
          t.type,
          t.pendingProps,
          K.current
        ), Jl = t, _t = !0, u = pl, Ea(t.type) ? (Ic = u, pl = Mt(e.firstChild)) : pl = u), $l(
          l,
          t,
          t.pendingProps.children,
          a
        ), yn(l, t), l === null && (t.flags |= 4194304), t.child;
      case 5:
        return l === null && ll && ((u = e = pl) && (e = jm(
          e,
          t.type,
          t.pendingProps,
          _t
        ), e !== null ? (t.stateNode = e, Jl = t, pl = Mt(e.firstChild), _t = !1, u = !0) : u = !1), u || sa(t)), M(t), u = t.type, n = t.pendingProps, i = l !== null ? l.memoizedProps : null, e = n.children, wc(u, n) ? e = null : i !== null && wc(u, i) && (t.flags |= 32), t.memoizedState !== null && (u = Ji(
          l,
          t,
          $r,
          null,
          null,
          a
        ), pu._currentValue = u), yn(l, t), $l(l, t, e, a), t.child;
      case 6:
        return l === null && ll && ((l = a = pl) && (a = Rm(
          a,
          t.pendingProps,
          _t
        ), a !== null ? (t.stateNode = a, Jl = t, pl = null, l = !0) : l = !1), l || sa(t)), null;
      case 13:
        return Xo(l, t, a);
      case 4:
        return Ol(
          t,
          t.stateNode.containerInfo
        ), e = t.pendingProps, l === null ? t.child = La(
          t,
          null,
          e,
          a
        ) : $l(l, t, e, a), t.child;
      case 11:
        return Do(
          l,
          t,
          t.type,
          t.pendingProps,
          a
        );
      case 7:
        return $l(
          l,
          t,
          t.pendingProps,
          a
        ), t.child;
      case 8:
        return $l(
          l,
          t,
          t.pendingProps.children,
          a
        ), t.child;
      case 12:
        return $l(
          l,
          t,
          t.pendingProps.children,
          a
        ), t.child;
      case 10:
        return e = t.pendingProps, oa(t, t.type, e.value), $l(l, t, e.children, a), t.child;
      case 9:
        return u = t.type._context, e = t.pendingProps.children, Ya(t), u = wl(u), e = e(u), t.flags |= 1, $l(l, t, e, a), t.child;
      case 14:
        return Co(
          l,
          t,
          t.type,
          t.pendingProps,
          a
        );
      case 15:
        return jo(
          l,
          t,
          t.type,
          t.pendingProps,
          a
        );
      case 19:
        return Lo(l, t, a);
      case 31:
        return am(l, t, a);
      case 22:
        return Ro(
          l,
          t,
          a,
          t.pendingProps
        );
      case 24:
        return Ya(t), e = wl(jl), l === null ? (u = Bi(), u === null && (u = bl, n = Ri(), u.pooledCache = n, n.refCount++, n !== null && (u.pooledCacheLanes |= a), u = n), t.memoizedState = { parent: e, cache: u }, Yi(t), oa(t, jl, u)) : ((l.lanes & a) !== 0 && (Gi(l, t), lu(t, null, null, a), Pe()), u = l.memoizedState, n = t.memoizedState, u.parent !== e ? (u = { parent: e, cache: e }, t.memoizedState = u, t.lanes === 0 && (t.memoizedState = t.updateQueue.baseState = u), oa(t, jl, e)) : (e = n.cache, oa(t, jl, e), e !== u.cache && ji(
          t,
          [jl],
          a,
          !0
        ))), $l(
          l,
          t,
          t.pendingProps.children,
          a
        ), t.child;
      case 29:
        throw t.pendingProps;
    }
    throw Error(r(156, t.tag));
  }
  function Wt(l) {
    l.flags |= 4;
  }
  function pc(l, t, a, e, u) {
    if ((t = (l.mode & 32) !== 0) && (t = !1), t) {
      if (l.flags |= 16777216, (u & 335544128) === u)
        if (l.stateNode.complete) l.flags |= 8192;
        else if (h0()) l.flags |= 8192;
        else
          throw Qa = Iu, qi;
    } else l.flags &= -16777217;
  }
  function Vo(l, t) {
    if (t.type !== "stylesheet" || (t.state.loading & 4) !== 0)
      l.flags &= -16777217;
    else if (l.flags |= 16777216, !nd(t))
      if (h0()) l.flags |= 8192;
      else
        throw Qa = Iu, qi;
  }
  function hn(l, t) {
    t !== null && (l.flags |= 4), l.flags & 16384 && (t = l.tag !== 22 ? zf() : 536870912, l.lanes |= t, ze |= t);
  }
  function iu(l, t) {
    if (!ll)
      switch (l.tailMode) {
        case "hidden":
          t = l.tail;
          for (var a = null; t !== null; )
            t.alternate !== null && (a = t), t = t.sibling;
          a === null ? l.tail = null : a.sibling = null;
          break;
        case "collapsed":
          a = l.tail;
          for (var e = null; a !== null; )
            a.alternate !== null && (e = a), a = a.sibling;
          e === null ? t || l.tail === null ? l.tail = null : l.tail.sibling = null : e.sibling = null;
      }
  }
  function Tl(l) {
    var t = l.alternate !== null && l.alternate.child === l.child, a = 0, e = 0;
    if (t)
      for (var u = l.child; u !== null; )
        a |= u.lanes | u.childLanes, e |= u.subtreeFlags & 65011712, e |= u.flags & 65011712, u.return = l, u = u.sibling;
    else
      for (u = l.child; u !== null; )
        a |= u.lanes | u.childLanes, e |= u.subtreeFlags, e |= u.flags, u.return = l, u = u.sibling;
    return l.subtreeFlags |= e, l.childLanes = a, t;
  }
  function um(l, t, a) {
    var e = t.pendingProps;
    switch (Mi(t), t.tag) {
      case 16:
      case 15:
      case 0:
      case 11:
      case 7:
      case 8:
      case 12:
      case 9:
      case 14:
        return Tl(t), null;
      case 1:
        return Tl(t), null;
      case 3:
        return a = t.stateNode, e = null, l !== null && (e = l.memoizedState.cache), t.memoizedState.cache !== e && (t.flags |= 2048), Kt(jl), xl(), a.pendingContext && (a.context = a.pendingContext, a.pendingContext = null), (l === null || l.child === null) && (se(t) ? Wt(t) : l === null || l.memoizedState.isDehydrated && (t.flags & 256) === 0 || (t.flags |= 1024, Ui())), Tl(t), null;
      case 26:
        var u = t.type, n = t.memoizedState;
        return l === null ? (Wt(t), n !== null ? (Tl(t), Vo(t, n)) : (Tl(t), pc(
          t,
          u,
          null,
          e,
          a
        ))) : n ? n !== l.memoizedState ? (Wt(t), Tl(t), Vo(t, n)) : (Tl(t), t.flags &= -16777217) : (l = l.memoizedProps, l !== e && Wt(t), Tl(t), pc(
          t,
          u,
          l,
          e,
          a
        )), null;
      case 27:
        if (X(t), a = K.current, u = t.type, l !== null && t.stateNode != null)
          l.memoizedProps !== e && Wt(t);
        else {
          if (!e) {
            if (t.stateNode === null)
              throw Error(r(166));
            return Tl(t), null;
          }
          l = C.current, se(t) ? zs(t) : (l = F0(u, e, a), t.stateNode = l, Wt(t));
        }
        return Tl(t), null;
      case 5:
        if (X(t), u = t.type, l !== null && t.stateNode != null)
          l.memoizedProps !== e && Wt(t);
        else {
          if (!e) {
            if (t.stateNode === null)
              throw Error(r(166));
            return Tl(t), null;
          }
          if (n = C.current, se(t))
            zs(t);
          else {
            var i = Dn(
              K.current
            );
            switch (n) {
              case 1:
                n = i.createElementNS(
                  "http://www.w3.org/2000/svg",
                  u
                );
                break;
              case 2:
                n = i.createElementNS(
                  "http://www.w3.org/1998/Math/MathML",
                  u
                );
                break;
              default:
                switch (u) {
                  case "svg":
                    n = i.createElementNS(
                      "http://www.w3.org/2000/svg",
                      u
                    );
                    break;
                  case "math":
                    n = i.createElementNS(
                      "http://www.w3.org/1998/Math/MathML",
                      u
                    );
                    break;
                  case "script":
                    n = i.createElement("div"), n.innerHTML = "<script><\/script>", n = n.removeChild(
                      n.firstChild
                    );
                    break;
                  case "select":
                    n = typeof e.is == "string" ? i.createElement("select", {
                      is: e.is
                    }) : i.createElement("select"), e.multiple ? n.multiple = !0 : e.size && (n.size = e.size);
                    break;
                  default:
                    n = typeof e.is == "string" ? i.createElement(u, { is: e.is }) : i.createElement(u);
                }
            }
            n[Kl] = t, n[lt] = e;
            l: for (i = t.child; i !== null; ) {
              if (i.tag === 5 || i.tag === 6)
                n.appendChild(i.stateNode);
              else if (i.tag !== 4 && i.tag !== 27 && i.child !== null) {
                i.child.return = i, i = i.child;
                continue;
              }
              if (i === t) break l;
              for (; i.sibling === null; ) {
                if (i.return === null || i.return === t)
                  break l;
                i = i.return;
              }
              i.sibling.return = i.return, i = i.sibling;
            }
            t.stateNode = n;
            l: switch (Wl(n, u, e), u) {
              case "button":
              case "input":
              case "select":
              case "textarea":
                e = !!e.autoFocus;
                break l;
              case "img":
                e = !0;
                break l;
              default:
                e = !1;
            }
            e && Wt(t);
          }
        }
        return Tl(t), pc(
          t,
          t.type,
          l === null ? null : l.memoizedProps,
          t.pendingProps,
          a
        ), null;
      case 6:
        if (l && t.stateNode != null)
          l.memoizedProps !== e && Wt(t);
        else {
          if (typeof e != "string" && t.stateNode === null)
            throw Error(r(166));
          if (l = K.current, se(t)) {
            if (l = t.stateNode, a = t.memoizedProps, e = null, u = Jl, u !== null)
              switch (u.tag) {
                case 27:
                case 5:
                  e = u.memoizedProps;
              }
            l[Kl] = t, l = !!(l.nodeValue === a || e !== null && e.suppressHydrationWarning === !0 || X0(l.nodeValue, a)), l || sa(t, !0);
          } else
            l = Dn(l).createTextNode(
              e
            ), l[Kl] = t, t.stateNode = l;
        }
        return Tl(t), null;
      case 31:
        if (a = t.memoizedState, l === null || l.memoizedState !== null) {
          if (e = se(t), a !== null) {
            if (l === null) {
              if (!e) throw Error(r(318));
              if (l = t.memoizedState, l = l !== null ? l.dehydrated : null, !l) throw Error(r(557));
              l[Kl] = t;
            } else
              Ba(), (t.flags & 128) === 0 && (t.memoizedState = null), t.flags |= 4;
            Tl(t), l = !1;
          } else
            a = Ui(), l !== null && l.memoizedState !== null && (l.memoizedState.hydrationErrors = a), l = !0;
          if (!l)
            return t.flags & 256 ? (mt(t), t) : (mt(t), null);
          if ((t.flags & 128) !== 0)
            throw Error(r(558));
        }
        return Tl(t), null;
      case 13:
        if (e = t.memoizedState, l === null || l.memoizedState !== null && l.memoizedState.dehydrated !== null) {
          if (u = se(t), e !== null && e.dehydrated !== null) {
            if (l === null) {
              if (!u) throw Error(r(318));
              if (u = t.memoizedState, u = u !== null ? u.dehydrated : null, !u) throw Error(r(317));
              u[Kl] = t;
            } else
              Ba(), (t.flags & 128) === 0 && (t.memoizedState = null), t.flags |= 4;
            Tl(t), u = !1;
          } else
            u = Ui(), l !== null && l.memoizedState !== null && (l.memoizedState.hydrationErrors = u), u = !0;
          if (!u)
            return t.flags & 256 ? (mt(t), t) : (mt(t), null);
        }
        return mt(t), (t.flags & 128) !== 0 ? (t.lanes = a, t) : (a = e !== null, l = l !== null && l.memoizedState !== null, a && (e = t.child, u = null, e.alternate !== null && e.alternate.memoizedState !== null && e.alternate.memoizedState.cachePool !== null && (u = e.alternate.memoizedState.cachePool.pool), n = null, e.memoizedState !== null && e.memoizedState.cachePool !== null && (n = e.memoizedState.cachePool.pool), n !== u && (e.flags |= 2048)), a !== l && a && (t.child.flags |= 8192), hn(t, t.updateQueue), Tl(t), null);
      case 4:
        return xl(), l === null && Lc(t.stateNode.containerInfo), Tl(t), null;
      case 10:
        return Kt(t.type), Tl(t), null;
      case 19:
        if (z(Ul), e = t.memoizedState, e === null) return Tl(t), null;
        if (u = (t.flags & 128) !== 0, n = e.rendering, n === null)
          if (u) iu(e, !1);
          else {
            if (Ml !== 0 || l !== null && (l.flags & 128) !== 0)
              for (l = t.child; l !== null; ) {
                if (n = an(l), n !== null) {
                  for (t.flags |= 128, iu(e, !1), l = n.updateQueue, t.updateQueue = l, hn(t, l), t.subtreeFlags = 0, l = a, a = t.child; a !== null; )
                    gs(a, l), a = a.sibling;
                  return O(
                    Ul,
                    Ul.current & 1 | 2
                  ), ll && Zt(t, e.treeForkCount), t.child;
                }
                l = l.sibling;
              }
            e.tail !== null && ct() > Tn && (t.flags |= 128, u = !0, iu(e, !1), t.lanes = 4194304);
          }
        else {
          if (!u)
            if (l = an(n), l !== null) {
              if (t.flags |= 128, u = !0, l = l.updateQueue, t.updateQueue = l, hn(t, l), iu(e, !0), e.tail === null && e.tailMode === "hidden" && !n.alternate && !ll)
                return Tl(t), null;
            } else
              2 * ct() - e.renderingStartTime > Tn && a !== 536870912 && (t.flags |= 128, u = !0, iu(e, !1), t.lanes = 4194304);
          e.isBackwards ? (n.sibling = t.child, t.child = n) : (l = e.last, l !== null ? l.sibling = n : t.child = n, e.last = n);
        }
        return e.tail !== null ? (l = e.tail, e.rendering = l, e.tail = l.sibling, e.renderingStartTime = ct(), l.sibling = null, a = Ul.current, O(
          Ul,
          u ? a & 1 | 2 : a & 1
        ), ll && Zt(t, e.treeForkCount), l) : (Tl(t), null);
      case 22:
      case 23:
        return mt(t), Zi(), e = t.memoizedState !== null, l !== null ? l.memoizedState !== null !== e && (t.flags |= 8192) : e && (t.flags |= 8192), e ? (a & 536870912) !== 0 && (t.flags & 128) === 0 && (Tl(t), t.subtreeFlags & 6 && (t.flags |= 8192)) : Tl(t), a = t.updateQueue, a !== null && hn(t, a.retryQueue), a = null, l !== null && l.memoizedState !== null && l.memoizedState.cachePool !== null && (a = l.memoizedState.cachePool.pool), e = null, t.memoizedState !== null && t.memoizedState.cachePool !== null && (e = t.memoizedState.cachePool.pool), e !== a && (t.flags |= 2048), l !== null && z(Ga), null;
      case 24:
        return a = null, l !== null && (a = l.memoizedState.cache), t.memoizedState.cache !== a && (t.flags |= 2048), Kt(jl), Tl(t), null;
      case 25:
        return null;
      case 30:
        return null;
    }
    throw Error(r(156, t.tag));
  }
  function nm(l, t) {
    switch (Mi(t), t.tag) {
      case 1:
        return l = t.flags, l & 65536 ? (t.flags = l & -65537 | 128, t) : null;
      case 3:
        return Kt(jl), xl(), l = t.flags, (l & 65536) !== 0 && (l & 128) === 0 ? (t.flags = l & -65537 | 128, t) : null;
      case 26:
      case 27:
      case 5:
        return X(t), null;
      case 31:
        if (t.memoizedState !== null) {
          if (mt(t), t.alternate === null)
            throw Error(r(340));
          Ba();
        }
        return l = t.flags, l & 65536 ? (t.flags = l & -65537 | 128, t) : null;
      case 13:
        if (mt(t), l = t.memoizedState, l !== null && l.dehydrated !== null) {
          if (t.alternate === null)
            throw Error(r(340));
          Ba();
        }
        return l = t.flags, l & 65536 ? (t.flags = l & -65537 | 128, t) : null;
      case 19:
        return z(Ul), null;
      case 4:
        return xl(), null;
      case 10:
        return Kt(t.type), null;
      case 22:
      case 23:
        return mt(t), Zi(), l !== null && z(Ga), l = t.flags, l & 65536 ? (t.flags = l & -65537 | 128, t) : null;
      case 24:
        return Kt(jl), null;
      case 25:
        return null;
      default:
        return null;
    }
  }
  function Ko(l, t) {
    switch (Mi(t), t.tag) {
      case 3:
        Kt(jl), xl();
        break;
      case 26:
      case 27:
      case 5:
        X(t);
        break;
      case 4:
        xl();
        break;
      case 31:
        t.memoizedState !== null && mt(t);
        break;
      case 13:
        mt(t);
        break;
      case 19:
        z(Ul);
        break;
      case 10:
        Kt(t.type);
        break;
      case 22:
      case 23:
        mt(t), Zi(), l !== null && z(Ga);
        break;
      case 24:
        Kt(jl);
    }
  }
  function cu(l, t) {
    try {
      var a = t.updateQueue, e = a !== null ? a.lastEffect : null;
      if (e !== null) {
        var u = e.next;
        a = u;
        do {
          if ((a.tag & l) === l) {
            e = void 0;
            var n = a.create, i = a.inst;
            e = n(), i.destroy = e;
          }
          a = a.next;
        } while (a !== u);
      }
    } catch (c) {
      dl(t, t.return, c);
    }
  }
  function ha(l, t, a) {
    try {
      var e = t.updateQueue, u = e !== null ? e.lastEffect : null;
      if (u !== null) {
        var n = u.next;
        e = n;
        do {
          if ((e.tag & l) === l) {
            var i = e.inst, c = i.destroy;
            if (c !== void 0) {
              i.destroy = void 0, u = t;
              var f = a, y = c;
              try {
                y();
              } catch (S) {
                dl(
                  u,
                  f,
                  S
                );
              }
            }
          }
          e = e.next;
        } while (e !== n);
      }
    } catch (S) {
      dl(t, t.return, S);
    }
  }
  function Jo(l) {
    var t = l.updateQueue;
    if (t !== null) {
      var a = l.stateNode;
      try {
        Hs(t, a);
      } catch (e) {
        dl(l, l.return, e);
      }
    }
  }
  function wo(l, t, a) {
    a.props = Va(
      l.type,
      l.memoizedProps
    ), a.state = l.memoizedState;
    try {
      a.componentWillUnmount();
    } catch (e) {
      dl(l, t, e);
    }
  }
  function fu(l, t) {
    try {
      var a = l.ref;
      if (a !== null) {
        switch (l.tag) {
          case 26:
          case 27:
          case 5:
            var e = l.stateNode;
            break;
          case 30:
            e = l.stateNode;
            break;
          default:
            e = l.stateNode;
        }
        typeof a == "function" ? l.refCleanup = a(e) : a.current = e;
      }
    } catch (u) {
      dl(l, t, u);
    }
  }
  function qt(l, t) {
    var a = l.ref, e = l.refCleanup;
    if (a !== null)
      if (typeof e == "function")
        try {
          e();
        } catch (u) {
          dl(l, t, u);
        } finally {
          l.refCleanup = null, l = l.alternate, l != null && (l.refCleanup = null);
        }
      else if (typeof a == "function")
        try {
          a(null);
        } catch (u) {
          dl(l, t, u);
        }
      else a.current = null;
  }
  function $o(l) {
    var t = l.type, a = l.memoizedProps, e = l.stateNode;
    try {
      l: switch (t) {
        case "button":
        case "input":
        case "select":
        case "textarea":
          a.autoFocus && e.focus();
          break l;
        case "img":
          a.src ? e.src = a.src : a.srcSet && (e.srcset = a.srcSet);
      }
    } catch (u) {
      dl(l, l.return, u);
    }
  }
  function Tc(l, t, a) {
    try {
      var e = l.stateNode;
      Nm(e, l.type, a, t), e[lt] = t;
    } catch (u) {
      dl(l, l.return, u);
    }
  }
  function Wo(l) {
    return l.tag === 5 || l.tag === 3 || l.tag === 26 || l.tag === 27 && Ea(l.type) || l.tag === 4;
  }
  function zc(l) {
    l: for (; ; ) {
      for (; l.sibling === null; ) {
        if (l.return === null || Wo(l.return)) return null;
        l = l.return;
      }
      for (l.sibling.return = l.return, l = l.sibling; l.tag !== 5 && l.tag !== 6 && l.tag !== 18; ) {
        if (l.tag === 27 && Ea(l.type) || l.flags & 2 || l.child === null || l.tag === 4) continue l;
        l.child.return = l, l = l.child;
      }
      if (!(l.flags & 2)) return l.stateNode;
    }
  }
  function Ec(l, t, a) {
    var e = l.tag;
    if (e === 5 || e === 6)
      l = l.stateNode, t ? (a.nodeType === 9 ? a.body : a.nodeName === "HTML" ? a.ownerDocument.body : a).insertBefore(l, t) : (t = a.nodeType === 9 ? a.body : a.nodeName === "HTML" ? a.ownerDocument.body : a, t.appendChild(l), a = a._reactRootContainer, a != null || t.onclick !== null || (t.onclick = Xt));
    else if (e !== 4 && (e === 27 && Ea(l.type) && (a = l.stateNode, t = null), l = l.child, l !== null))
      for (Ec(l, t, a), l = l.sibling; l !== null; )
        Ec(l, t, a), l = l.sibling;
  }
  function gn(l, t, a) {
    var e = l.tag;
    if (e === 5 || e === 6)
      l = l.stateNode, t ? a.insertBefore(l, t) : a.appendChild(l);
    else if (e !== 4 && (e === 27 && Ea(l.type) && (a = l.stateNode), l = l.child, l !== null))
      for (gn(l, t, a), l = l.sibling; l !== null; )
        gn(l, t, a), l = l.sibling;
  }
  function ko(l) {
    var t = l.stateNode, a = l.memoizedProps;
    try {
      for (var e = l.type, u = t.attributes; u.length; )
        t.removeAttributeNode(u[0]);
      Wl(t, e, a), t[Kl] = l, t[lt] = a;
    } catch (n) {
      dl(l, l.return, n);
    }
  }
  var kt = !1, Bl = !1, Ac = !1, Fo = typeof WeakSet == "function" ? WeakSet : Set, Ql = null;
  function im(l, t) {
    if (l = l.containerInfo, Kc = Yn, l = fs(l), gi(l)) {
      if ("selectionStart" in l)
        var a = {
          start: l.selectionStart,
          end: l.selectionEnd
        };
      else
        l: {
          a = (a = l.ownerDocument) && a.defaultView || window;
          var e = a.getSelection && a.getSelection();
          if (e && e.rangeCount !== 0) {
            a = e.anchorNode;
            var u = e.anchorOffset, n = e.focusNode;
            e = e.focusOffset;
            try {
              a.nodeType, n.nodeType;
            } catch {
              a = null;
              break l;
            }
            var i = 0, c = -1, f = -1, y = 0, S = 0, T = l, v = null;
            t: for (; ; ) {
              for (var h; T !== a || u !== 0 && T.nodeType !== 3 || (c = i + u), T !== n || e !== 0 && T.nodeType !== 3 || (f = i + e), T.nodeType === 3 && (i += T.nodeValue.length), (h = T.firstChild) !== null; )
                v = T, T = h;
              for (; ; ) {
                if (T === l) break t;
                if (v === a && ++y === u && (c = i), v === n && ++S === e && (f = i), (h = T.nextSibling) !== null) break;
                T = v, v = T.parentNode;
              }
              T = h;
            }
            a = c === -1 || f === -1 ? null : { start: c, end: f };
          } else a = null;
        }
      a = a || { start: 0, end: 0 };
    } else a = null;
    for (Jc = { focusedElem: l, selectionRange: a }, Yn = !1, Ql = t; Ql !== null; )
      if (t = Ql, l = t.child, (t.subtreeFlags & 1028) !== 0 && l !== null)
        l.return = t, Ql = l;
      else
        for (; Ql !== null; ) {
          switch (t = Ql, n = t.alternate, l = t.flags, t.tag) {
            case 0:
              if ((l & 4) !== 0 && (l = t.updateQueue, l = l !== null ? l.events : null, l !== null))
                for (a = 0; a < l.length; a++)
                  u = l[a], u.ref.impl = u.nextImpl;
              break;
            case 11:
            case 15:
              break;
            case 1:
              if ((l & 1024) !== 0 && n !== null) {
                l = void 0, a = t, u = n.memoizedProps, n = n.memoizedState, e = a.stateNode;
                try {
                  var D = Va(
                    a.type,
                    u
                  );
                  l = e.getSnapshotBeforeUpdate(
                    D,
                    n
                  ), e.__reactInternalSnapshotBeforeUpdate = l;
                } catch (Y) {
                  dl(
                    a,
                    a.return,
                    Y
                  );
                }
              }
              break;
            case 3:
              if ((l & 1024) !== 0) {
                if (l = t.stateNode.containerInfo, a = l.nodeType, a === 9)
                  Wc(l);
                else if (a === 1)
                  switch (l.nodeName) {
                    case "HEAD":
                    case "HTML":
                    case "BODY":
                      Wc(l);
                      break;
                    default:
                      l.textContent = "";
                  }
              }
              break;
            case 5:
            case 26:
            case 27:
            case 6:
            case 4:
            case 17:
              break;
            default:
              if ((l & 1024) !== 0) throw Error(r(163));
          }
          if (l = t.sibling, l !== null) {
            l.return = t.return, Ql = l;
            break;
          }
          Ql = t.return;
        }
  }
  function Io(l, t, a) {
    var e = a.flags;
    switch (a.tag) {
      case 0:
      case 11:
      case 15:
        It(l, a), e & 4 && cu(5, a);
        break;
      case 1:
        if (It(l, a), e & 4)
          if (l = a.stateNode, t === null)
            try {
              l.componentDidMount();
            } catch (i) {
              dl(a, a.return, i);
            }
          else {
            var u = Va(
              a.type,
              t.memoizedProps
            );
            t = t.memoizedState;
            try {
              l.componentDidUpdate(
                u,
                t,
                l.__reactInternalSnapshotBeforeUpdate
              );
            } catch (i) {
              dl(
                a,
                a.return,
                i
              );
            }
          }
        e & 64 && Jo(a), e & 512 && fu(a, a.return);
        break;
      case 3:
        if (It(l, a), e & 64 && (l = a.updateQueue, l !== null)) {
          if (t = null, a.child !== null)
            switch (a.child.tag) {
              case 27:
              case 5:
                t = a.child.stateNode;
                break;
              case 1:
                t = a.child.stateNode;
            }
          try {
            Hs(l, t);
          } catch (i) {
            dl(a, a.return, i);
          }
        }
        break;
      case 27:
        t === null && e & 4 && ko(a);
      case 26:
      case 5:
        It(l, a), t === null && e & 4 && $o(a), e & 512 && fu(a, a.return);
        break;
      case 12:
        It(l, a);
        break;
      case 31:
        It(l, a), e & 4 && t0(l, a);
        break;
      case 13:
        It(l, a), e & 4 && a0(l, a), e & 64 && (l = a.memoizedState, l !== null && (l = l.dehydrated, l !== null && (a = vm.bind(
          null,
          a
        ), Hm(l, a))));
        break;
      case 22:
        if (e = a.memoizedState !== null || kt, !e) {
          t = t !== null && t.memoizedState !== null || Bl, u = kt;
          var n = Bl;
          kt = e, (Bl = t) && !n ? Pt(
            l,
            a,
            (a.subtreeFlags & 8772) !== 0
          ) : It(l, a), kt = u, Bl = n;
        }
        break;
      case 30:
        break;
      default:
        It(l, a);
    }
  }
  function Po(l) {
    var t = l.alternate;
    t !== null && (l.alternate = null, Po(t)), l.child = null, l.deletions = null, l.sibling = null, l.tag === 5 && (t = l.stateNode, t !== null && li(t)), l.stateNode = null, l.return = null, l.dependencies = null, l.memoizedProps = null, l.memoizedState = null, l.pendingProps = null, l.stateNode = null, l.updateQueue = null;
  }
  var El = null, at = !1;
  function Ft(l, t, a) {
    for (a = a.child; a !== null; )
      l0(l, t, a), a = a.sibling;
  }
  function l0(l, t, a) {
    if (ft && typeof ft.onCommitFiberUnmount == "function")
      try {
        ft.onCommitFiberUnmount(Ce, a);
      } catch {
      }
    switch (a.tag) {
      case 26:
        Bl || qt(a, t), Ft(
          l,
          t,
          a
        ), a.memoizedState ? a.memoizedState.count-- : a.stateNode && (a = a.stateNode, a.parentNode.removeChild(a));
        break;
      case 27:
        Bl || qt(a, t);
        var e = El, u = at;
        Ea(a.type) && (El = a.stateNode, at = !1), Ft(
          l,
          t,
          a
        ), gu(a.stateNode), El = e, at = u;
        break;
      case 5:
        Bl || qt(a, t);
      case 6:
        if (e = El, u = at, El = null, Ft(
          l,
          t,
          a
        ), El = e, at = u, El !== null)
          if (at)
            try {
              (El.nodeType === 9 ? El.body : El.nodeName === "HTML" ? El.ownerDocument.body : El).removeChild(a.stateNode);
            } catch (n) {
              dl(
                a,
                t,
                n
              );
            }
          else
            try {
              El.removeChild(a.stateNode);
            } catch (n) {
              dl(
                a,
                t,
                n
              );
            }
        break;
      case 18:
        El !== null && (at ? (l = El, J0(
          l.nodeType === 9 ? l.body : l.nodeName === "HTML" ? l.ownerDocument.body : l,
          a.stateNode
        ), Ue(l)) : J0(El, a.stateNode));
        break;
      case 4:
        e = El, u = at, El = a.stateNode.containerInfo, at = !0, Ft(
          l,
          t,
          a
        ), El = e, at = u;
        break;
      case 0:
      case 11:
      case 14:
      case 15:
        ha(2, a, t), Bl || ha(4, a, t), Ft(
          l,
          t,
          a
        );
        break;
      case 1:
        Bl || (qt(a, t), e = a.stateNode, typeof e.componentWillUnmount == "function" && wo(
          a,
          t,
          e
        )), Ft(
          l,
          t,
          a
        );
        break;
      case 21:
        Ft(
          l,
          t,
          a
        );
        break;
      case 22:
        Bl = (e = Bl) || a.memoizedState !== null, Ft(
          l,
          t,
          a
        ), Bl = e;
        break;
      default:
        Ft(
          l,
          t,
          a
        );
    }
  }
  function t0(l, t) {
    if (t.memoizedState === null && (l = t.alternate, l !== null && (l = l.memoizedState, l !== null))) {
      l = l.dehydrated;
      try {
        Ue(l);
      } catch (a) {
        dl(t, t.return, a);
      }
    }
  }
  function a0(l, t) {
    if (t.memoizedState === null && (l = t.alternate, l !== null && (l = l.memoizedState, l !== null && (l = l.dehydrated, l !== null))))
      try {
        Ue(l);
      } catch (a) {
        dl(t, t.return, a);
      }
  }
  function cm(l) {
    switch (l.tag) {
      case 31:
      case 13:
      case 19:
        var t = l.stateNode;
        return t === null && (t = l.stateNode = new Fo()), t;
      case 22:
        return l = l.stateNode, t = l._retryCache, t === null && (t = l._retryCache = new Fo()), t;
      default:
        throw Error(r(435, l.tag));
    }
  }
  function bn(l, t) {
    var a = cm(l);
    t.forEach(function(e) {
      if (!a.has(e)) {
        a.add(e);
        var u = hm.bind(null, l, e);
        e.then(u, u);
      }
    });
  }
  function et(l, t) {
    var a = t.deletions;
    if (a !== null)
      for (var e = 0; e < a.length; e++) {
        var u = a[e], n = l, i = t, c = i;
        l: for (; c !== null; ) {
          switch (c.tag) {
            case 27:
              if (Ea(c.type)) {
                El = c.stateNode, at = !1;
                break l;
              }
              break;
            case 5:
              El = c.stateNode, at = !1;
              break l;
            case 3:
            case 4:
              El = c.stateNode.containerInfo, at = !0;
              break l;
          }
          c = c.return;
        }
        if (El === null) throw Error(r(160));
        l0(n, i, u), El = null, at = !1, n = u.alternate, n !== null && (n.return = null), u.return = null;
      }
    if (t.subtreeFlags & 13886)
      for (t = t.child; t !== null; )
        e0(t, l), t = t.sibling;
  }
  var jt = null;
  function e0(l, t) {
    var a = l.alternate, e = l.flags;
    switch (l.tag) {
      case 0:
      case 11:
      case 14:
      case 15:
        et(t, l), ut(l), e & 4 && (ha(3, l, l.return), cu(3, l), ha(5, l, l.return));
        break;
      case 1:
        et(t, l), ut(l), e & 512 && (Bl || a === null || qt(a, a.return)), e & 64 && kt && (l = l.updateQueue, l !== null && (e = l.callbacks, e !== null && (a = l.shared.hiddenCallbacks, l.shared.hiddenCallbacks = a === null ? e : a.concat(e))));
        break;
      case 26:
        var u = jt;
        if (et(t, l), ut(l), e & 512 && (Bl || a === null || qt(a, a.return)), e & 4) {
          var n = a !== null ? a.memoizedState : null;
          if (e = l.memoizedState, a === null)
            if (e === null)
              if (l.stateNode === null) {
                l: {
                  e = l.type, a = l.memoizedProps, u = u.ownerDocument || u;
                  t: switch (e) {
                    case "title":
                      n = u.getElementsByTagName("title")[0], (!n || n[He] || n[Kl] || n.namespaceURI === "http://www.w3.org/2000/svg" || n.hasAttribute("itemprop")) && (n = u.createElement(e), u.head.insertBefore(
                        n,
                        u.querySelector("head > title")
                      )), Wl(n, e, a), n[Kl] = l, Xl(n), e = n;
                      break l;
                    case "link":
                      var i = ed(
                        "link",
                        "href",
                        u
                      ).get(e + (a.href || ""));
                      if (i) {
                        for (var c = 0; c < i.length; c++)
                          if (n = i[c], n.getAttribute("href") === (a.href == null || a.href === "" ? null : a.href) && n.getAttribute("rel") === (a.rel == null ? null : a.rel) && n.getAttribute("title") === (a.title == null ? null : a.title) && n.getAttribute("crossorigin") === (a.crossOrigin == null ? null : a.crossOrigin)) {
                            i.splice(c, 1);
                            break t;
                          }
                      }
                      n = u.createElement(e), Wl(n, e, a), u.head.appendChild(n);
                      break;
                    case "meta":
                      if (i = ed(
                        "meta",
                        "content",
                        u
                      ).get(e + (a.content || ""))) {
                        for (c = 0; c < i.length; c++)
                          if (n = i[c], n.getAttribute("content") === (a.content == null ? null : "" + a.content) && n.getAttribute("name") === (a.name == null ? null : a.name) && n.getAttribute("property") === (a.property == null ? null : a.property) && n.getAttribute("http-equiv") === (a.httpEquiv == null ? null : a.httpEquiv) && n.getAttribute("charset") === (a.charSet == null ? null : a.charSet)) {
                            i.splice(c, 1);
                            break t;
                          }
                      }
                      n = u.createElement(e), Wl(n, e, a), u.head.appendChild(n);
                      break;
                    default:
                      throw Error(r(468, e));
                  }
                  n[Kl] = l, Xl(n), e = n;
                }
                l.stateNode = e;
              } else
                ud(
                  u,
                  l.type,
                  l.stateNode
                );
            else
              l.stateNode = ad(
                u,
                e,
                l.memoizedProps
              );
          else
            n !== e ? (n === null ? a.stateNode !== null && (a = a.stateNode, a.parentNode.removeChild(a)) : n.count--, e === null ? ud(
              u,
              l.type,
              l.stateNode
            ) : ad(
              u,
              e,
              l.memoizedProps
            )) : e === null && l.stateNode !== null && Tc(
              l,
              l.memoizedProps,
              a.memoizedProps
            );
        }
        break;
      case 27:
        et(t, l), ut(l), e & 512 && (Bl || a === null || qt(a, a.return)), a !== null && e & 4 && Tc(
          l,
          l.memoizedProps,
          a.memoizedProps
        );
        break;
      case 5:
        if (et(t, l), ut(l), e & 512 && (Bl || a === null || qt(a, a.return)), l.flags & 32) {
          u = l.stateNode;
          try {
            Pa(u, "");
          } catch (D) {
            dl(l, l.return, D);
          }
        }
        e & 4 && l.stateNode != null && (u = l.memoizedProps, Tc(
          l,
          u,
          a !== null ? a.memoizedProps : u
        )), e & 1024 && (Ac = !0);
        break;
      case 6:
        if (et(t, l), ut(l), e & 4) {
          if (l.stateNode === null)
            throw Error(r(162));
          e = l.memoizedProps, a = l.stateNode;
          try {
            a.nodeValue = e;
          } catch (D) {
            dl(l, l.return, D);
          }
        }
        break;
      case 3:
        if (Rn = null, u = jt, jt = Cn(t.containerInfo), et(t, l), jt = u, ut(l), e & 4 && a !== null && a.memoizedState.isDehydrated)
          try {
            Ue(t.containerInfo);
          } catch (D) {
            dl(l, l.return, D);
          }
        Ac && (Ac = !1, u0(l));
        break;
      case 4:
        e = jt, jt = Cn(
          l.stateNode.containerInfo
        ), et(t, l), ut(l), jt = e;
        break;
      case 12:
        et(t, l), ut(l);
        break;
      case 31:
        et(t, l), ut(l), e & 4 && (e = l.updateQueue, e !== null && (l.updateQueue = null, bn(l, e)));
        break;
      case 13:
        et(t, l), ut(l), l.child.flags & 8192 && l.memoizedState !== null != (a !== null && a.memoizedState !== null) && (pn = ct()), e & 4 && (e = l.updateQueue, e !== null && (l.updateQueue = null, bn(l, e)));
        break;
      case 22:
        u = l.memoizedState !== null;
        var f = a !== null && a.memoizedState !== null, y = kt, S = Bl;
        if (kt = y || u, Bl = S || f, et(t, l), Bl = S, kt = y, ut(l), e & 8192)
          l: for (t = l.stateNode, t._visibility = u ? t._visibility & -2 : t._visibility | 1, u && (a === null || f || kt || Bl || Ka(l)), a = null, t = l; ; ) {
            if (t.tag === 5 || t.tag === 26) {
              if (a === null) {
                f = a = t;
                try {
                  if (n = f.stateNode, u)
                    i = n.style, typeof i.setProperty == "function" ? i.setProperty("display", "none", "important") : i.display = "none";
                  else {
                    c = f.stateNode;
                    var T = f.memoizedProps.style, v = T != null && T.hasOwnProperty("display") ? T.display : null;
                    c.style.display = v == null || typeof v == "boolean" ? "" : ("" + v).trim();
                  }
                } catch (D) {
                  dl(f, f.return, D);
                }
              }
            } else if (t.tag === 6) {
              if (a === null) {
                f = t;
                try {
                  f.stateNode.nodeValue = u ? "" : f.memoizedProps;
                } catch (D) {
                  dl(f, f.return, D);
                }
              }
            } else if (t.tag === 18) {
              if (a === null) {
                f = t;
                try {
                  var h = f.stateNode;
                  u ? w0(h, !0) : w0(f.stateNode, !1);
                } catch (D) {
                  dl(f, f.return, D);
                }
              }
            } else if ((t.tag !== 22 && t.tag !== 23 || t.memoizedState === null || t === l) && t.child !== null) {
              t.child.return = t, t = t.child;
              continue;
            }
            if (t === l) break l;
            for (; t.sibling === null; ) {
              if (t.return === null || t.return === l) break l;
              a === t && (a = null), t = t.return;
            }
            a === t && (a = null), t.sibling.return = t.return, t = t.sibling;
          }
        e & 4 && (e = l.updateQueue, e !== null && (a = e.retryQueue, a !== null && (e.retryQueue = null, bn(l, a))));
        break;
      case 19:
        et(t, l), ut(l), e & 4 && (e = l.updateQueue, e !== null && (l.updateQueue = null, bn(l, e)));
        break;
      case 30:
        break;
      case 21:
        break;
      default:
        et(t, l), ut(l);
    }
  }
  function ut(l) {
    var t = l.flags;
    if (t & 2) {
      try {
        for (var a, e = l.return; e !== null; ) {
          if (Wo(e)) {
            a = e;
            break;
          }
          e = e.return;
        }
        if (a == null) throw Error(r(160));
        switch (a.tag) {
          case 27:
            var u = a.stateNode, n = zc(l);
            gn(l, n, u);
            break;
          case 5:
            var i = a.stateNode;
            a.flags & 32 && (Pa(i, ""), a.flags &= -33);
            var c = zc(l);
            gn(l, c, i);
            break;
          case 3:
          case 4:
            var f = a.stateNode.containerInfo, y = zc(l);
            Ec(
              l,
              y,
              f
            );
            break;
          default:
            throw Error(r(161));
        }
      } catch (S) {
        dl(l, l.return, S);
      }
      l.flags &= -3;
    }
    t & 4096 && (l.flags &= -4097);
  }
  function u0(l) {
    if (l.subtreeFlags & 1024)
      for (l = l.child; l !== null; ) {
        var t = l;
        u0(t), t.tag === 5 && t.flags & 1024 && t.stateNode.reset(), l = l.sibling;
      }
  }
  function It(l, t) {
    if (t.subtreeFlags & 8772)
      for (t = t.child; t !== null; )
        Io(l, t.alternate, t), t = t.sibling;
  }
  function Ka(l) {
    for (l = l.child; l !== null; ) {
      var t = l;
      switch (t.tag) {
        case 0:
        case 11:
        case 14:
        case 15:
          ha(4, t, t.return), Ka(t);
          break;
        case 1:
          qt(t, t.return);
          var a = t.stateNode;
          typeof a.componentWillUnmount == "function" && wo(
            t,
            t.return,
            a
          ), Ka(t);
          break;
        case 27:
          gu(t.stateNode);
        case 26:
        case 5:
          qt(t, t.return), Ka(t);
          break;
        case 22:
          t.memoizedState === null && Ka(t);
          break;
        case 30:
          Ka(t);
          break;
        default:
          Ka(t);
      }
      l = l.sibling;
    }
  }
  function Pt(l, t, a) {
    for (a = a && (t.subtreeFlags & 8772) !== 0, t = t.child; t !== null; ) {
      var e = t.alternate, u = l, n = t, i = n.flags;
      switch (n.tag) {
        case 0:
        case 11:
        case 15:
          Pt(
            u,
            n,
            a
          ), cu(4, n);
          break;
        case 1:
          if (Pt(
            u,
            n,
            a
          ), e = n, u = e.stateNode, typeof u.componentDidMount == "function")
            try {
              u.componentDidMount();
            } catch (y) {
              dl(e, e.return, y);
            }
          if (e = n, u = e.updateQueue, u !== null) {
            var c = e.stateNode;
            try {
              var f = u.shared.hiddenCallbacks;
              if (f !== null)
                for (u.shared.hiddenCallbacks = null, u = 0; u < f.length; u++)
                  Rs(f[u], c);
            } catch (y) {
              dl(e, e.return, y);
            }
          }
          a && i & 64 && Jo(n), fu(n, n.return);
          break;
        case 27:
          ko(n);
        case 26:
        case 5:
          Pt(
            u,
            n,
            a
          ), a && e === null && i & 4 && $o(n), fu(n, n.return);
          break;
        case 12:
          Pt(
            u,
            n,
            a
          );
          break;
        case 31:
          Pt(
            u,
            n,
            a
          ), a && i & 4 && t0(u, n);
          break;
        case 13:
          Pt(
            u,
            n,
            a
          ), a && i & 4 && a0(u, n);
          break;
        case 22:
          n.memoizedState === null && Pt(
            u,
            n,
            a
          ), fu(n, n.return);
          break;
        case 30:
          break;
        default:
          Pt(
            u,
            n,
            a
          );
      }
      t = t.sibling;
    }
  }
  function xc(l, t) {
    var a = null;
    l !== null && l.memoizedState !== null && l.memoizedState.cachePool !== null && (a = l.memoizedState.cachePool.pool), l = null, t.memoizedState !== null && t.memoizedState.cachePool !== null && (l = t.memoizedState.cachePool.pool), l !== a && (l != null && l.refCount++, a != null && $e(a));
  }
  function _c(l, t) {
    l = null, t.alternate !== null && (l = t.alternate.memoizedState.cache), t = t.memoizedState.cache, t !== l && (t.refCount++, l != null && $e(l));
  }
  function Rt(l, t, a, e) {
    if (t.subtreeFlags & 10256)
      for (t = t.child; t !== null; )
        n0(
          l,
          t,
          a,
          e
        ), t = t.sibling;
  }
  function n0(l, t, a, e) {
    var u = t.flags;
    switch (t.tag) {
      case 0:
      case 11:
      case 15:
        Rt(
          l,
          t,
          a,
          e
        ), u & 2048 && cu(9, t);
        break;
      case 1:
        Rt(
          l,
          t,
          a,
          e
        );
        break;
      case 3:
        Rt(
          l,
          t,
          a,
          e
        ), u & 2048 && (l = null, t.alternate !== null && (l = t.alternate.memoizedState.cache), t = t.memoizedState.cache, t !== l && (t.refCount++, l != null && $e(l)));
        break;
      case 12:
        if (u & 2048) {
          Rt(
            l,
            t,
            a,
            e
          ), l = t.stateNode;
          try {
            var n = t.memoizedProps, i = n.id, c = n.onPostCommit;
            typeof c == "function" && c(
              i,
              t.alternate === null ? "mount" : "update",
              l.passiveEffectDuration,
              -0
            );
          } catch (f) {
            dl(t, t.return, f);
          }
        } else
          Rt(
            l,
            t,
            a,
            e
          );
        break;
      case 31:
        Rt(
          l,
          t,
          a,
          e
        );
        break;
      case 13:
        Rt(
          l,
          t,
          a,
          e
        );
        break;
      case 23:
        break;
      case 22:
        n = t.stateNode, i = t.alternate, t.memoizedState !== null ? n._visibility & 2 ? Rt(
          l,
          t,
          a,
          e
        ) : su(l, t) : n._visibility & 2 ? Rt(
          l,
          t,
          a,
          e
        ) : (n._visibility |= 2, Se(
          l,
          t,
          a,
          e,
          (t.subtreeFlags & 10256) !== 0 || !1
        )), u & 2048 && xc(i, t);
        break;
      case 24:
        Rt(
          l,
          t,
          a,
          e
        ), u & 2048 && _c(t.alternate, t);
        break;
      default:
        Rt(
          l,
          t,
          a,
          e
        );
    }
  }
  function Se(l, t, a, e, u) {
    for (u = u && ((t.subtreeFlags & 10256) !== 0 || !1), t = t.child; t !== null; ) {
      var n = l, i = t, c = a, f = e, y = i.flags;
      switch (i.tag) {
        case 0:
        case 11:
        case 15:
          Se(
            n,
            i,
            c,
            f,
            u
          ), cu(8, i);
          break;
        case 23:
          break;
        case 22:
          var S = i.stateNode;
          i.memoizedState !== null ? S._visibility & 2 ? Se(
            n,
            i,
            c,
            f,
            u
          ) : su(
            n,
            i
          ) : (S._visibility |= 2, Se(
            n,
            i,
            c,
            f,
            u
          )), u && y & 2048 && xc(
            i.alternate,
            i
          );
          break;
        case 24:
          Se(
            n,
            i,
            c,
            f,
            u
          ), u && y & 2048 && _c(i.alternate, i);
          break;
        default:
          Se(
            n,
            i,
            c,
            f,
            u
          );
      }
      t = t.sibling;
    }
  }
  function su(l, t) {
    if (t.subtreeFlags & 10256)
      for (t = t.child; t !== null; ) {
        var a = l, e = t, u = e.flags;
        switch (e.tag) {
          case 22:
            su(a, e), u & 2048 && xc(
              e.alternate,
              e
            );
            break;
          case 24:
            su(a, e), u & 2048 && _c(e.alternate, e);
            break;
          default:
            su(a, e);
        }
        t = t.sibling;
      }
  }
  var ou = 8192;
  function pe(l, t, a) {
    if (l.subtreeFlags & ou)
      for (l = l.child; l !== null; )
        i0(
          l,
          t,
          a
        ), l = l.sibling;
  }
  function i0(l, t, a) {
    switch (l.tag) {
      case 26:
        pe(
          l,
          t,
          a
        ), l.flags & ou && l.memoizedState !== null && wm(
          a,
          jt,
          l.memoizedState,
          l.memoizedProps
        );
        break;
      case 5:
        pe(
          l,
          t,
          a
        );
        break;
      case 3:
      case 4:
        var e = jt;
        jt = Cn(l.stateNode.containerInfo), pe(
          l,
          t,
          a
        ), jt = e;
        break;
      case 22:
        l.memoizedState === null && (e = l.alternate, e !== null && e.memoizedState !== null ? (e = ou, ou = 16777216, pe(
          l,
          t,
          a
        ), ou = e) : pe(
          l,
          t,
          a
        ));
        break;
      default:
        pe(
          l,
          t,
          a
        );
    }
  }
  function c0(l) {
    var t = l.alternate;
    if (t !== null && (l = t.child, l !== null)) {
      t.child = null;
      do
        t = l.sibling, l.sibling = null, l = t;
      while (l !== null);
    }
  }
  function du(l) {
    var t = l.deletions;
    if ((l.flags & 16) !== 0) {
      if (t !== null)
        for (var a = 0; a < t.length; a++) {
          var e = t[a];
          Ql = e, s0(
            e,
            l
          );
        }
      c0(l);
    }
    if (l.subtreeFlags & 10256)
      for (l = l.child; l !== null; )
        f0(l), l = l.sibling;
  }
  function f0(l) {
    switch (l.tag) {
      case 0:
      case 11:
      case 15:
        du(l), l.flags & 2048 && ha(9, l, l.return);
        break;
      case 3:
        du(l);
        break;
      case 12:
        du(l);
        break;
      case 22:
        var t = l.stateNode;
        l.memoizedState !== null && t._visibility & 2 && (l.return === null || l.return.tag !== 13) ? (t._visibility &= -3, Sn(l)) : du(l);
        break;
      default:
        du(l);
    }
  }
  function Sn(l) {
    var t = l.deletions;
    if ((l.flags & 16) !== 0) {
      if (t !== null)
        for (var a = 0; a < t.length; a++) {
          var e = t[a];
          Ql = e, s0(
            e,
            l
          );
        }
      c0(l);
    }
    for (l = l.child; l !== null; ) {
      switch (t = l, t.tag) {
        case 0:
        case 11:
        case 15:
          ha(8, t, t.return), Sn(t);
          break;
        case 22:
          a = t.stateNode, a._visibility & 2 && (a._visibility &= -3, Sn(t));
          break;
        default:
          Sn(t);
      }
      l = l.sibling;
    }
  }
  function s0(l, t) {
    for (; Ql !== null; ) {
      var a = Ql;
      switch (a.tag) {
        case 0:
        case 11:
        case 15:
          ha(8, a, t);
          break;
        case 23:
        case 22:
          if (a.memoizedState !== null && a.memoizedState.cachePool !== null) {
            var e = a.memoizedState.cachePool.pool;
            e != null && e.refCount++;
          }
          break;
        case 24:
          $e(a.memoizedState.cache);
      }
      if (e = a.child, e !== null) e.return = a, Ql = e;
      else
        l: for (a = l; Ql !== null; ) {
          e = Ql;
          var u = e.sibling, n = e.return;
          if (Po(e), e === a) {
            Ql = null;
            break l;
          }
          if (u !== null) {
            u.return = n, Ql = u;
            break l;
          }
          Ql = n;
        }
    }
  }
  var fm = {
    getCacheForType: function(l) {
      var t = wl(jl), a = t.data.get(l);
      return a === void 0 && (a = l(), t.data.set(l, a)), a;
    },
    cacheSignal: function() {
      return wl(jl).controller.signal;
    }
  }, sm = typeof WeakMap == "function" ? WeakMap : Map, il = 0, bl = null, W = null, F = 0, ol = 0, yt = null, ga = !1, Te = !1, Nc = !1, la = 0, Ml = 0, ba = 0, Ja = 0, Mc = 0, vt = 0, ze = 0, ru = null, nt = null, Oc = !1, pn = 0, o0 = 0, Tn = 1 / 0, zn = null, Sa = null, ql = 0, pa = null, Ee = null, ta = 0, Uc = 0, Dc = null, d0 = null, mu = 0, Cc = null;
  function ht() {
    return (il & 2) !== 0 && F !== 0 ? F & -F : b.T !== null ? Yc() : _f();
  }
  function r0() {
    if (vt === 0)
      if ((F & 536870912) === 0 || ll) {
        var l = Ou;
        Ou <<= 1, (Ou & 3932160) === 0 && (Ou = 262144), vt = l;
      } else vt = 536870912;
    return l = rt.current, l !== null && (l.flags |= 32), vt;
  }
  function it(l, t, a) {
    (l === bl && (ol === 2 || ol === 9) || l.cancelPendingCommit !== null) && (Ae(l, 0), Ta(
      l,
      F,
      vt,
      !1
    )), Re(l, a), ((il & 2) === 0 || l !== bl) && (l === bl && ((il & 2) === 0 && (Ja |= a), Ml === 4 && Ta(
      l,
      F,
      vt,
      !1
    )), Yt(l));
  }
  function m0(l, t, a) {
    if ((il & 6) !== 0) throw Error(r(327));
    var e = !a && (t & 127) === 0 && (t & l.expiredLanes) === 0 || je(l, t), u = e ? rm(l, t) : Rc(l, t, !0), n = e;
    do {
      if (u === 0) {
        Te && !e && Ta(l, t, 0, !1);
        break;
      } else {
        if (a = l.current.alternate, n && !om(a)) {
          u = Rc(l, t, !1), n = !1;
          continue;
        }
        if (u === 2) {
          if (n = t, l.errorRecoveryDisabledLanes & n)
            var i = 0;
          else
            i = l.pendingLanes & -536870913, i = i !== 0 ? i : i & 536870912 ? 536870912 : 0;
          if (i !== 0) {
            t = i;
            l: {
              var c = l;
              u = ru;
              var f = c.current.memoizedState.isDehydrated;
              if (f && (Ae(c, i).flags |= 256), i = Rc(
                c,
                i,
                !1
              ), i !== 2) {
                if (Nc && !f) {
                  c.errorRecoveryDisabledLanes |= n, Ja |= n, u = 4;
                  break l;
                }
                n = nt, nt = u, n !== null && (nt === null ? nt = n : nt.push.apply(
                  nt,
                  n
                ));
              }
              u = i;
            }
            if (n = !1, u !== 2) continue;
          }
        }
        if (u === 1) {
          Ae(l, 0), Ta(l, t, 0, !0);
          break;
        }
        l: {
          switch (e = l, n = u, n) {
            case 0:
            case 1:
              throw Error(r(345));
            case 4:
              if ((t & 4194048) !== t) break;
            case 6:
              Ta(
                e,
                t,
                vt,
                !ga
              );
              break l;
            case 2:
              nt = null;
              break;
            case 3:
            case 5:
              break;
            default:
              throw Error(r(329));
          }
          if ((t & 62914560) === t && (u = pn + 300 - ct(), 10 < u)) {
            if (Ta(
              e,
              t,
              vt,
              !ga
            ), Du(e, 0, !0) !== 0) break l;
            ta = t, e.timeoutHandle = V0(
              y0.bind(
                null,
                e,
                a,
                nt,
                zn,
                Oc,
                t,
                vt,
                Ja,
                ze,
                ga,
                n,
                "Throttled",
                -0,
                0
              ),
              u
            );
            break l;
          }
          y0(
            e,
            a,
            nt,
            zn,
            Oc,
            t,
            vt,
            Ja,
            ze,
            ga,
            n,
            null,
            -0,
            0
          );
        }
      }
      break;
    } while (!0);
    Yt(l);
  }
  function y0(l, t, a, e, u, n, i, c, f, y, S, T, v, h) {
    if (l.timeoutHandle = -1, T = t.subtreeFlags, T & 8192 || (T & 16785408) === 16785408) {
      T = {
        stylesheets: null,
        count: 0,
        imgCount: 0,
        imgBytes: 0,
        suspenseyImages: [],
        waitingForImages: !0,
        waitingForViewTransition: !1,
        unsuspend: Xt
      }, i0(
        t,
        n,
        T
      );
      var D = (n & 62914560) === n ? pn - ct() : (n & 4194048) === n ? o0 - ct() : 0;
      if (D = $m(
        T,
        D
      ), D !== null) {
        ta = n, l.cancelPendingCommit = D(
          z0.bind(
            null,
            l,
            t,
            n,
            a,
            e,
            u,
            i,
            c,
            f,
            S,
            T,
            null,
            v,
            h
          )
        ), Ta(l, n, i, !y);
        return;
      }
    }
    z0(
      l,
      t,
      n,
      a,
      e,
      u,
      i,
      c,
      f
    );
  }
  function om(l) {
    for (var t = l; ; ) {
      var a = t.tag;
      if ((a === 0 || a === 11 || a === 15) && t.flags & 16384 && (a = t.updateQueue, a !== null && (a = a.stores, a !== null)))
        for (var e = 0; e < a.length; e++) {
          var u = a[e], n = u.getSnapshot;
          u = u.value;
          try {
            if (!ot(n(), u)) return !1;
          } catch {
            return !1;
          }
        }
      if (a = t.child, t.subtreeFlags & 16384 && a !== null)
        a.return = t, t = a;
      else {
        if (t === l) break;
        for (; t.sibling === null; ) {
          if (t.return === null || t.return === l) return !0;
          t = t.return;
        }
        t.sibling.return = t.return, t = t.sibling;
      }
    }
    return !0;
  }
  function Ta(l, t, a, e) {
    t &= ~Mc, t &= ~Ja, l.suspendedLanes |= t, l.pingedLanes &= ~t, e && (l.warmLanes |= t), e = l.expirationTimes;
    for (var u = t; 0 < u; ) {
      var n = 31 - st(u), i = 1 << n;
      e[n] = -1, u &= ~i;
    }
    a !== 0 && Ef(l, a, t);
  }
  function En() {
    return (il & 6) === 0 ? (yu(0), !1) : !0;
  }
  function jc() {
    if (W !== null) {
      if (ol === 0)
        var l = W.return;
      else
        l = W, Vt = qa = null, Wi(l), ye = null, ke = 0, l = W;
      for (; l !== null; )
        Ko(l.alternate, l), l = l.return;
      W = null;
    }
  }
  function Ae(l, t) {
    var a = l.timeoutHandle;
    a !== -1 && (l.timeoutHandle = -1, Um(a)), a = l.cancelPendingCommit, a !== null && (l.cancelPendingCommit = null, a()), ta = 0, jc(), bl = l, W = a = Lt(l.current, null), F = t, ol = 0, yt = null, ga = !1, Te = je(l, t), Nc = !1, ze = vt = Mc = Ja = ba = Ml = 0, nt = ru = null, Oc = !1, (t & 8) !== 0 && (t |= t & 32);
    var e = l.entangledLanes;
    if (e !== 0)
      for (l = l.entanglements, e &= t; 0 < e; ) {
        var u = 31 - st(e), n = 1 << u;
        t |= l[u], e &= ~n;
      }
    return la = t, Zu(), a;
  }
  function v0(l, t) {
    Z = null, b.H = uu, t === me || t === Fu ? (t = Us(), ol = 3) : t === qi ? (t = Us(), ol = 4) : ol = t === dc ? 8 : t !== null && typeof t == "object" && typeof t.then == "function" ? 6 : 1, yt = t, W === null && (Ml = 1, rn(
      l,
      Et(t, l.current)
    ));
  }
  function h0() {
    var l = rt.current;
    return l === null ? !0 : (F & 4194048) === F ? Nt === null : (F & 62914560) === F || (F & 536870912) !== 0 ? l === Nt : !1;
  }
  function g0() {
    var l = b.H;
    return b.H = uu, l === null ? uu : l;
  }
  function b0() {
    var l = b.A;
    return b.A = fm, l;
  }
  function An() {
    Ml = 4, ga || (F & 4194048) !== F && rt.current !== null || (Te = !0), (ba & 134217727) === 0 && (Ja & 134217727) === 0 || bl === null || Ta(
      bl,
      F,
      vt,
      !1
    );
  }
  function Rc(l, t, a) {
    var e = il;
    il |= 2;
    var u = g0(), n = b0();
    (bl !== l || F !== t) && (zn = null, Ae(l, t)), t = !1;
    var i = Ml;
    l: do
      try {
        if (ol !== 0 && W !== null) {
          var c = W, f = yt;
          switch (ol) {
            case 8:
              jc(), i = 6;
              break l;
            case 3:
            case 2:
            case 9:
            case 6:
              rt.current === null && (t = !0);
              var y = ol;
              if (ol = 0, yt = null, xe(l, c, f, y), a && Te) {
                i = 0;
                break l;
              }
              break;
            default:
              y = ol, ol = 0, yt = null, xe(l, c, f, y);
          }
        }
        dm(), i = Ml;
        break;
      } catch (S) {
        v0(l, S);
      }
    while (!0);
    return t && l.shellSuspendCounter++, Vt = qa = null, il = e, b.H = u, b.A = n, W === null && (bl = null, F = 0, Zu()), i;
  }
  function dm() {
    for (; W !== null; ) S0(W);
  }
  function rm(l, t) {
    var a = il;
    il |= 2;
    var e = g0(), u = b0();
    bl !== l || F !== t ? (zn = null, Tn = ct() + 500, Ae(l, t)) : Te = je(
      l,
      t
    );
    l: do
      try {
        if (ol !== 0 && W !== null) {
          t = W;
          var n = yt;
          t: switch (ol) {
            case 1:
              ol = 0, yt = null, xe(l, t, n, 1);
              break;
            case 2:
            case 9:
              if (Ms(n)) {
                ol = 0, yt = null, p0(t);
                break;
              }
              t = function() {
                ol !== 2 && ol !== 9 || bl !== l || (ol = 7), Yt(l);
              }, n.then(t, t);
              break l;
            case 3:
              ol = 7;
              break l;
            case 4:
              ol = 5;
              break l;
            case 7:
              Ms(n) ? (ol = 0, yt = null, p0(t)) : (ol = 0, yt = null, xe(l, t, n, 7));
              break;
            case 5:
              var i = null;
              switch (W.tag) {
                case 26:
                  i = W.memoizedState;
                case 5:
                case 27:
                  var c = W;
                  if (i ? nd(i) : c.stateNode.complete) {
                    ol = 0, yt = null;
                    var f = c.sibling;
                    if (f !== null) W = f;
                    else {
                      var y = c.return;
                      y !== null ? (W = y, xn(y)) : W = null;
                    }
                    break t;
                  }
              }
              ol = 0, yt = null, xe(l, t, n, 5);
              break;
            case 6:
              ol = 0, yt = null, xe(l, t, n, 6);
              break;
            case 8:
              jc(), Ml = 6;
              break l;
            default:
              throw Error(r(462));
          }
        }
        mm();
        break;
      } catch (S) {
        v0(l, S);
      }
    while (!0);
    return Vt = qa = null, b.H = e, b.A = u, il = a, W !== null ? 0 : (bl = null, F = 0, Zu(), Ml);
  }
  function mm() {
    for (; W !== null && !Bd(); )
      S0(W);
  }
  function S0(l) {
    var t = Zo(l.alternate, l, la);
    l.memoizedProps = l.pendingProps, t === null ? xn(l) : W = t;
  }
  function p0(l) {
    var t = l, a = t.alternate;
    switch (t.tag) {
      case 15:
      case 0:
        t = qo(
          a,
          t,
          t.pendingProps,
          t.type,
          void 0,
          F
        );
        break;
      case 11:
        t = qo(
          a,
          t,
          t.pendingProps,
          t.type.render,
          t.ref,
          F
        );
        break;
      case 5:
        Wi(t);
      default:
        Ko(a, t), t = W = gs(t, la), t = Zo(a, t, la);
    }
    l.memoizedProps = l.pendingProps, t === null ? xn(l) : W = t;
  }
  function xe(l, t, a, e) {
    Vt = qa = null, Wi(t), ye = null, ke = 0;
    var u = t.return;
    try {
      if (tm(
        l,
        u,
        t,
        a,
        F
      )) {
        Ml = 1, rn(
          l,
          Et(a, l.current)
        ), W = null;
        return;
      }
    } catch (n) {
      if (u !== null) throw W = u, n;
      Ml = 1, rn(
        l,
        Et(a, l.current)
      ), W = null;
      return;
    }
    t.flags & 32768 ? (ll || e === 1 ? l = !0 : Te || (F & 536870912) !== 0 ? l = !1 : (ga = l = !0, (e === 2 || e === 9 || e === 3 || e === 6) && (e = rt.current, e !== null && e.tag === 13 && (e.flags |= 16384))), T0(t, l)) : xn(t);
  }
  function xn(l) {
    var t = l;
    do {
      if ((t.flags & 32768) !== 0) {
        T0(
          t,
          ga
        );
        return;
      }
      l = t.return;
      var a = um(
        t.alternate,
        t,
        la
      );
      if (a !== null) {
        W = a;
        return;
      }
      if (t = t.sibling, t !== null) {
        W = t;
        return;
      }
      W = t = l;
    } while (t !== null);
    Ml === 0 && (Ml = 5);
  }
  function T0(l, t) {
    do {
      var a = nm(l.alternate, l);
      if (a !== null) {
        a.flags &= 32767, W = a;
        return;
      }
      if (a = l.return, a !== null && (a.flags |= 32768, a.subtreeFlags = 0, a.deletions = null), !t && (l = l.sibling, l !== null)) {
        W = l;
        return;
      }
      W = l = a;
    } while (l !== null);
    Ml = 6, W = null;
  }
  function z0(l, t, a, e, u, n, i, c, f) {
    l.cancelPendingCommit = null;
    do
      _n();
    while (ql !== 0);
    if ((il & 6) !== 0) throw Error(r(327));
    if (t !== null) {
      if (t === l.current) throw Error(r(177));
      if (n = t.lanes | t.childLanes, n |= zi, Jd(
        l,
        a,
        n,
        i,
        c,
        f
      ), l === bl && (W = bl = null, F = 0), Ee = t, pa = l, ta = a, Uc = n, Dc = u, d0 = e, (t.subtreeFlags & 10256) !== 0 || (t.flags & 10256) !== 0 ? (l.callbackNode = null, l.callbackPriority = 0, gm(Nu, function() {
        return N0(), null;
      })) : (l.callbackNode = null, l.callbackPriority = 0), e = (t.flags & 13878) !== 0, (t.subtreeFlags & 13878) !== 0 || e) {
        e = b.T, b.T = null, u = N.p, N.p = 2, i = il, il |= 4;
        try {
          im(l, t, a);
        } finally {
          il = i, N.p = u, b.T = e;
        }
      }
      ql = 1, E0(), A0(), x0();
    }
  }
  function E0() {
    if (ql === 1) {
      ql = 0;
      var l = pa, t = Ee, a = (t.flags & 13878) !== 0;
      if ((t.subtreeFlags & 13878) !== 0 || a) {
        a = b.T, b.T = null;
        var e = N.p;
        N.p = 2;
        var u = il;
        il |= 4;
        try {
          e0(t, l);
          var n = Jc, i = fs(l.containerInfo), c = n.focusedElem, f = n.selectionRange;
          if (i !== c && c && c.ownerDocument && cs(
            c.ownerDocument.documentElement,
            c
          )) {
            if (f !== null && gi(c)) {
              var y = f.start, S = f.end;
              if (S === void 0 && (S = y), "selectionStart" in c)
                c.selectionStart = y, c.selectionEnd = Math.min(
                  S,
                  c.value.length
                );
              else {
                var T = c.ownerDocument || document, v = T && T.defaultView || window;
                if (v.getSelection) {
                  var h = v.getSelection(), D = c.textContent.length, Y = Math.min(f.start, D), gl = f.end === void 0 ? Y : Math.min(f.end, D);
                  !h.extend && Y > gl && (i = gl, gl = Y, Y = i);
                  var d = is(
                    c,
                    Y
                  ), s = is(
                    c,
                    gl
                  );
                  if (d && s && (h.rangeCount !== 1 || h.anchorNode !== d.node || h.anchorOffset !== d.offset || h.focusNode !== s.node || h.focusOffset !== s.offset)) {
                    var m = T.createRange();
                    m.setStart(d.node, d.offset), h.removeAllRanges(), Y > gl ? (h.addRange(m), h.extend(s.node, s.offset)) : (m.setEnd(s.node, s.offset), h.addRange(m));
                  }
                }
              }
            }
            for (T = [], h = c; h = h.parentNode; )
              h.nodeType === 1 && T.push({
                element: h,
                left: h.scrollLeft,
                top: h.scrollTop
              });
            for (typeof c.focus == "function" && c.focus(), c = 0; c < T.length; c++) {
              var p = T[c];
              p.element.scrollLeft = p.left, p.element.scrollTop = p.top;
            }
          }
          Yn = !!Kc, Jc = Kc = null;
        } finally {
          il = u, N.p = e, b.T = a;
        }
      }
      l.current = t, ql = 2;
    }
  }
  function A0() {
    if (ql === 2) {
      ql = 0;
      var l = pa, t = Ee, a = (t.flags & 8772) !== 0;
      if ((t.subtreeFlags & 8772) !== 0 || a) {
        a = b.T, b.T = null;
        var e = N.p;
        N.p = 2;
        var u = il;
        il |= 4;
        try {
          Io(l, t.alternate, t);
        } finally {
          il = u, N.p = e, b.T = a;
        }
      }
      ql = 3;
    }
  }
  function x0() {
    if (ql === 4 || ql === 3) {
      ql = 0, qd();
      var l = pa, t = Ee, a = ta, e = d0;
      (t.subtreeFlags & 10256) !== 0 || (t.flags & 10256) !== 0 ? ql = 5 : (ql = 0, Ee = pa = null, _0(l, l.pendingLanes));
      var u = l.pendingLanes;
      if (u === 0 && (Sa = null), In(a), t = t.stateNode, ft && typeof ft.onCommitFiberRoot == "function")
        try {
          ft.onCommitFiberRoot(
            Ce,
            t,
            void 0,
            (t.current.flags & 128) === 128
          );
        } catch {
        }
      if (e !== null) {
        t = b.T, u = N.p, N.p = 2, b.T = null;
        try {
          for (var n = l.onRecoverableError, i = 0; i < e.length; i++) {
            var c = e[i];
            n(c.value, {
              componentStack: c.stack
            });
          }
        } finally {
          b.T = t, N.p = u;
        }
      }
      (ta & 3) !== 0 && _n(), Yt(l), u = l.pendingLanes, (a & 261930) !== 0 && (u & 42) !== 0 ? l === Cc ? mu++ : (mu = 0, Cc = l) : mu = 0, yu(0);
    }
  }
  function _0(l, t) {
    (l.pooledCacheLanes &= t) === 0 && (t = l.pooledCache, t != null && (l.pooledCache = null, $e(t)));
  }
  function _n() {
    return E0(), A0(), x0(), N0();
  }
  function N0() {
    if (ql !== 5) return !1;
    var l = pa, t = Uc;
    Uc = 0;
    var a = In(ta), e = b.T, u = N.p;
    try {
      N.p = 32 > a ? 32 : a, b.T = null, a = Dc, Dc = null;
      var n = pa, i = ta;
      if (ql = 0, Ee = pa = null, ta = 0, (il & 6) !== 0) throw Error(r(331));
      var c = il;
      if (il |= 4, f0(n.current), n0(
        n,
        n.current,
        i,
        a
      ), il = c, yu(0, !1), ft && typeof ft.onPostCommitFiberRoot == "function")
        try {
          ft.onPostCommitFiberRoot(Ce, n);
        } catch {
        }
      return !0;
    } finally {
      N.p = u, b.T = e, _0(l, t);
    }
  }
  function M0(l, t, a) {
    t = Et(a, t), t = oc(l.stateNode, t, 2), l = ma(l, t, 2), l !== null && (Re(l, 2), Yt(l));
  }
  function dl(l, t, a) {
    if (l.tag === 3)
      M0(l, l, a);
    else
      for (; t !== null; ) {
        if (t.tag === 3) {
          M0(
            t,
            l,
            a
          );
          break;
        } else if (t.tag === 1) {
          var e = t.stateNode;
          if (typeof t.type.getDerivedStateFromError == "function" || typeof e.componentDidCatch == "function" && (Sa === null || !Sa.has(e))) {
            l = Et(a, l), a = Oo(2), e = ma(t, a, 2), e !== null && (Uo(
              a,
              e,
              t,
              l
            ), Re(e, 2), Yt(e));
            break;
          }
        }
        t = t.return;
      }
  }
  function Hc(l, t, a) {
    var e = l.pingCache;
    if (e === null) {
      e = l.pingCache = new sm();
      var u = /* @__PURE__ */ new Set();
      e.set(t, u);
    } else
      u = e.get(t), u === void 0 && (u = /* @__PURE__ */ new Set(), e.set(t, u));
    u.has(a) || (Nc = !0, u.add(a), l = ym.bind(null, l, t, a), t.then(l, l));
  }
  function ym(l, t, a) {
    var e = l.pingCache;
    e !== null && e.delete(t), l.pingedLanes |= l.suspendedLanes & a, l.warmLanes &= ~a, bl === l && (F & a) === a && (Ml === 4 || Ml === 3 && (F & 62914560) === F && 300 > ct() - pn ? (il & 2) === 0 && Ae(l, 0) : Mc |= a, ze === F && (ze = 0)), Yt(l);
  }
  function O0(l, t) {
    t === 0 && (t = zf()), l = Ra(l, t), l !== null && (Re(l, t), Yt(l));
  }
  function vm(l) {
    var t = l.memoizedState, a = 0;
    t !== null && (a = t.retryLane), O0(l, a);
  }
  function hm(l, t) {
    var a = 0;
    switch (l.tag) {
      case 31:
      case 13:
        var e = l.stateNode, u = l.memoizedState;
        u !== null && (a = u.retryLane);
        break;
      case 19:
        e = l.stateNode;
        break;
      case 22:
        e = l.stateNode._retryCache;
        break;
      default:
        throw Error(r(314));
    }
    e !== null && e.delete(t), O0(l, a);
  }
  function gm(l, t) {
    return $n(l, t);
  }
  var Nn = null, _e = null, Bc = !1, Mn = !1, qc = !1, za = 0;
  function Yt(l) {
    l !== _e && l.next === null && (_e === null ? Nn = _e = l : _e = _e.next = l), Mn = !0, Bc || (Bc = !0, Sm());
  }
  function yu(l, t) {
    if (!qc && Mn) {
      qc = !0;
      do
        for (var a = !1, e = Nn; e !== null; ) {
          if (l !== 0) {
            var u = e.pendingLanes;
            if (u === 0) var n = 0;
            else {
              var i = e.suspendedLanes, c = e.pingedLanes;
              n = (1 << 31 - st(42 | l) + 1) - 1, n &= u & ~(i & ~c), n = n & 201326741 ? n & 201326741 | 1 : n ? n | 2 : 0;
            }
            n !== 0 && (a = !0, j0(e, n));
          } else
            n = F, n = Du(
              e,
              e === bl ? n : 0,
              e.cancelPendingCommit !== null || e.timeoutHandle !== -1
            ), (n & 3) === 0 || je(e, n) || (a = !0, j0(e, n));
          e = e.next;
        }
      while (a);
      qc = !1;
    }
  }
  function bm() {
    U0();
  }
  function U0() {
    Mn = Bc = !1;
    var l = 0;
    za !== 0 && Om() && (l = za);
    for (var t = ct(), a = null, e = Nn; e !== null; ) {
      var u = e.next, n = D0(e, t);
      n === 0 ? (e.next = null, a === null ? Nn = u : a.next = u, u === null && (_e = a)) : (a = e, (l !== 0 || (n & 3) !== 0) && (Mn = !0)), e = u;
    }
    ql !== 0 && ql !== 5 || yu(l), za !== 0 && (za = 0);
  }
  function D0(l, t) {
    for (var a = l.suspendedLanes, e = l.pingedLanes, u = l.expirationTimes, n = l.pendingLanes & -62914561; 0 < n; ) {
      var i = 31 - st(n), c = 1 << i, f = u[i];
      f === -1 ? ((c & a) === 0 || (c & e) !== 0) && (u[i] = Kd(c, t)) : f <= t && (l.expiredLanes |= c), n &= ~c;
    }
    if (t = bl, a = F, a = Du(
      l,
      l === t ? a : 0,
      l.cancelPendingCommit !== null || l.timeoutHandle !== -1
    ), e = l.callbackNode, a === 0 || l === t && (ol === 2 || ol === 9) || l.cancelPendingCommit !== null)
      return e !== null && e !== null && Wn(e), l.callbackNode = null, l.callbackPriority = 0;
    if ((a & 3) === 0 || je(l, a)) {
      if (t = a & -a, t === l.callbackPriority) return t;
      switch (e !== null && Wn(e), In(a)) {
        case 2:
        case 8:
          a = pf;
          break;
        case 32:
          a = Nu;
          break;
        case 268435456:
          a = Tf;
          break;
        default:
          a = Nu;
      }
      return e = C0.bind(null, l), a = $n(a, e), l.callbackPriority = t, l.callbackNode = a, t;
    }
    return e !== null && e !== null && Wn(e), l.callbackPriority = 2, l.callbackNode = null, 2;
  }
  function C0(l, t) {
    if (ql !== 0 && ql !== 5)
      return l.callbackNode = null, l.callbackPriority = 0, null;
    var a = l.callbackNode;
    if (_n() && l.callbackNode !== a)
      return null;
    var e = F;
    return e = Du(
      l,
      l === bl ? e : 0,
      l.cancelPendingCommit !== null || l.timeoutHandle !== -1
    ), e === 0 ? null : (m0(l, e, t), D0(l, ct()), l.callbackNode != null && l.callbackNode === a ? C0.bind(null, l) : null);
  }
  function j0(l, t) {
    if (_n()) return null;
    m0(l, t, !0);
  }
  function Sm() {
    Dm(function() {
      (il & 6) !== 0 ? $n(
        Sf,
        bm
      ) : U0();
    });
  }
  function Yc() {
    if (za === 0) {
      var l = de;
      l === 0 && (l = Mu, Mu <<= 1, (Mu & 261888) === 0 && (Mu = 256)), za = l;
    }
    return za;
  }
  function R0(l) {
    return l == null || typeof l == "symbol" || typeof l == "boolean" ? null : typeof l == "function" ? l : Hu("" + l);
  }
  function H0(l, t) {
    var a = t.ownerDocument.createElement("input");
    return a.name = t.name, a.value = t.value, l.id && a.setAttribute("form", l.id), t.parentNode.insertBefore(a, t), l = new FormData(l), a.parentNode.removeChild(a), l;
  }
  function pm(l, t, a, e, u) {
    if (t === "submit" && a && a.stateNode === u) {
      var n = R0(
        (u[lt] || null).action
      ), i = e.submitter;
      i && (t = (t = i[lt] || null) ? R0(t.formAction) : i.getAttribute("formAction"), t !== null && (n = t, i = null));
      var c = new Gu(
        "action",
        "action",
        null,
        e,
        u
      );
      l.push({
        event: c,
        listeners: [
          {
            instance: null,
            listener: function() {
              if (e.defaultPrevented) {
                if (za !== 0) {
                  var f = i ? H0(u, i) : new FormData(u);
                  uc(
                    a,
                    {
                      pending: !0,
                      data: f,
                      method: u.method,
                      action: n
                    },
                    null,
                    f
                  );
                }
              } else
                typeof n == "function" && (c.preventDefault(), f = i ? H0(u, i) : new FormData(u), uc(
                  a,
                  {
                    pending: !0,
                    data: f,
                    method: u.method,
                    action: n
                  },
                  n,
                  f
                ));
            },
            currentTarget: u
          }
        ]
      });
    }
  }
  for (var Gc = 0; Gc < Ti.length; Gc++) {
    var Xc = Ti[Gc], Tm = Xc.toLowerCase(), zm = Xc[0].toUpperCase() + Xc.slice(1);
    Ct(
      Tm,
      "on" + zm
    );
  }
  Ct(ds, "onAnimationEnd"), Ct(rs, "onAnimationIteration"), Ct(ms, "onAnimationStart"), Ct("dblclick", "onDoubleClick"), Ct("focusin", "onFocus"), Ct("focusout", "onBlur"), Ct(Yr, "onTransitionRun"), Ct(Gr, "onTransitionStart"), Ct(Xr, "onTransitionCancel"), Ct(ys, "onTransitionEnd"), Fa("onMouseEnter", ["mouseout", "mouseover"]), Fa("onMouseLeave", ["mouseout", "mouseover"]), Fa("onPointerEnter", ["pointerout", "pointerover"]), Fa("onPointerLeave", ["pointerout", "pointerover"]), Ua(
    "onChange",
    "change click focusin focusout input keydown keyup selectionchange".split(" ")
  ), Ua(
    "onSelect",
    "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(
      " "
    )
  ), Ua("onBeforeInput", [
    "compositionend",
    "keypress",
    "textInput",
    "paste"
  ]), Ua(
    "onCompositionEnd",
    "compositionend focusout keydown keypress keyup mousedown".split(" ")
  ), Ua(
    "onCompositionStart",
    "compositionstart focusout keydown keypress keyup mousedown".split(" ")
  ), Ua(
    "onCompositionUpdate",
    "compositionupdate focusout keydown keypress keyup mousedown".split(" ")
  );
  var vu = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(
    " "
  ), Em = new Set(
    "beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(vu)
  );
  function B0(l, t) {
    t = (t & 4) !== 0;
    for (var a = 0; a < l.length; a++) {
      var e = l[a], u = e.event;
      e = e.listeners;
      l: {
        var n = void 0;
        if (t)
          for (var i = e.length - 1; 0 <= i; i--) {
            var c = e[i], f = c.instance, y = c.currentTarget;
            if (c = c.listener, f !== n && u.isPropagationStopped())
              break l;
            n = c, u.currentTarget = y;
            try {
              n(u);
            } catch (S) {
              Lu(S);
            }
            u.currentTarget = null, n = f;
          }
        else
          for (i = 0; i < e.length; i++) {
            if (c = e[i], f = c.instance, y = c.currentTarget, c = c.listener, f !== n && u.isPropagationStopped())
              break l;
            n = c, u.currentTarget = y;
            try {
              n(u);
            } catch (S) {
              Lu(S);
            }
            u.currentTarget = null, n = f;
          }
      }
    }
  }
  function k(l, t) {
    var a = t[Pn];
    a === void 0 && (a = t[Pn] = /* @__PURE__ */ new Set());
    var e = l + "__bubble";
    a.has(e) || (q0(t, l, 2, !1), a.add(e));
  }
  function Qc(l, t, a) {
    var e = 0;
    t && (e |= 4), q0(
      a,
      l,
      e,
      t
    );
  }
  var On = "_reactListening" + Math.random().toString(36).slice(2);
  function Lc(l) {
    if (!l[On]) {
      l[On] = !0, Of.forEach(function(a) {
        a !== "selectionchange" && (Em.has(a) || Qc(a, !1, l), Qc(a, !0, l));
      });
      var t = l.nodeType === 9 ? l : l.ownerDocument;
      t === null || t[On] || (t[On] = !0, Qc("selectionchange", !1, t));
    }
  }
  function q0(l, t, a, e) {
    switch (rd(t)) {
      case 2:
        var u = Fm;
        break;
      case 8:
        u = Im;
        break;
      default:
        u = ef;
    }
    a = u.bind(
      null,
      t,
      a,
      l
    ), u = void 0, !fi || t !== "touchstart" && t !== "touchmove" && t !== "wheel" || (u = !0), e ? u !== void 0 ? l.addEventListener(t, a, {
      capture: !0,
      passive: u
    }) : l.addEventListener(t, a, !0) : u !== void 0 ? l.addEventListener(t, a, {
      passive: u
    }) : l.addEventListener(t, a, !1);
  }
  function Zc(l, t, a, e, u) {
    var n = e;
    if ((t & 1) === 0 && (t & 2) === 0 && e !== null)
      l: for (; ; ) {
        if (e === null) return;
        var i = e.tag;
        if (i === 3 || i === 4) {
          var c = e.stateNode.containerInfo;
          if (c === u) break;
          if (i === 4)
            for (i = e.return; i !== null; ) {
              var f = i.tag;
              if ((f === 3 || f === 4) && i.stateNode.containerInfo === u)
                return;
              i = i.return;
            }
          for (; c !== null; ) {
            if (i = $a(c), i === null) return;
            if (f = i.tag, f === 5 || f === 6 || f === 26 || f === 27) {
              e = n = i;
              continue l;
            }
            c = c.parentNode;
          }
        }
        e = e.return;
      }
    Qf(function() {
      var y = n, S = ii(a), T = [];
      l: {
        var v = vs.get(l);
        if (v !== void 0) {
          var h = Gu, D = l;
          switch (l) {
            case "keypress":
              if (qu(a) === 0) break l;
            case "keydown":
            case "keyup":
              h = hr;
              break;
            case "focusin":
              D = "focus", h = ri;
              break;
            case "focusout":
              D = "blur", h = ri;
              break;
            case "beforeblur":
            case "afterblur":
              h = ri;
              break;
            case "click":
              if (a.button === 2) break l;
            case "auxclick":
            case "dblclick":
            case "mousedown":
            case "mousemove":
            case "mouseup":
            case "mouseout":
            case "mouseover":
            case "contextmenu":
              h = Vf;
              break;
            case "drag":
            case "dragend":
            case "dragenter":
            case "dragexit":
            case "dragleave":
            case "dragover":
            case "dragstart":
            case "drop":
              h = ur;
              break;
            case "touchcancel":
            case "touchend":
            case "touchmove":
            case "touchstart":
              h = Sr;
              break;
            case ds:
            case rs:
            case ms:
              h = cr;
              break;
            case ys:
              h = Tr;
              break;
            case "scroll":
            case "scrollend":
              h = ar;
              break;
            case "wheel":
              h = Er;
              break;
            case "copy":
            case "cut":
            case "paste":
              h = sr;
              break;
            case "gotpointercapture":
            case "lostpointercapture":
            case "pointercancel":
            case "pointerdown":
            case "pointermove":
            case "pointerout":
            case "pointerover":
            case "pointerup":
              h = Jf;
              break;
            case "toggle":
            case "beforetoggle":
              h = xr;
          }
          var Y = (t & 4) !== 0, gl = !Y && (l === "scroll" || l === "scrollend"), d = Y ? v !== null ? v + "Capture" : null : v;
          Y = [];
          for (var s = y, m; s !== null; ) {
            var p = s;
            if (m = p.stateNode, p = p.tag, p !== 5 && p !== 26 && p !== 27 || m === null || d === null || (p = qe(s, d), p != null && Y.push(
              hu(s, p, m)
            )), gl) break;
            s = s.return;
          }
          0 < Y.length && (v = new h(
            v,
            D,
            null,
            a,
            S
          ), T.push({ event: v, listeners: Y }));
        }
      }
      if ((t & 7) === 0) {
        l: {
          if (v = l === "mouseover" || l === "pointerover", h = l === "mouseout" || l === "pointerout", v && a !== ni && (D = a.relatedTarget || a.fromElement) && ($a(D) || D[wa]))
            break l;
          if ((h || v) && (v = S.window === S ? S : (v = S.ownerDocument) ? v.defaultView || v.parentWindow : window, h ? (D = a.relatedTarget || a.toElement, h = y, D = D ? $a(D) : null, D !== null && (gl = G(D), Y = D.tag, D !== gl || Y !== 5 && Y !== 27 && Y !== 6) && (D = null)) : (h = null, D = y), h !== D)) {
            if (Y = Vf, p = "onMouseLeave", d = "onMouseEnter", s = "mouse", (l === "pointerout" || l === "pointerover") && (Y = Jf, p = "onPointerLeave", d = "onPointerEnter", s = "pointer"), gl = h == null ? v : Be(h), m = D == null ? v : Be(D), v = new Y(
              p,
              s + "leave",
              h,
              a,
              S
            ), v.target = gl, v.relatedTarget = m, p = null, $a(S) === y && (Y = new Y(
              d,
              s + "enter",
              D,
              a,
              S
            ), Y.target = m, Y.relatedTarget = gl, p = Y), gl = p, h && D)
              t: {
                for (Y = Am, d = h, s = D, m = 0, p = d; p; p = Y(p))
                  m++;
                p = 0;
                for (var B = s; B; B = Y(B))
                  p++;
                for (; 0 < m - p; )
                  d = Y(d), m--;
                for (; 0 < p - m; )
                  s = Y(s), p--;
                for (; m--; ) {
                  if (d === s || s !== null && d === s.alternate) {
                    Y = d;
                    break t;
                  }
                  d = Y(d), s = Y(s);
                }
                Y = null;
              }
            else Y = null;
            h !== null && Y0(
              T,
              v,
              h,
              Y,
              !1
            ), D !== null && gl !== null && Y0(
              T,
              gl,
              D,
              Y,
              !0
            );
          }
        }
        l: {
          if (v = y ? Be(y) : window, h = v.nodeName && v.nodeName.toLowerCase(), h === "select" || h === "input" && v.type === "file")
            var el = ls;
          else if (If(v))
            if (ts)
              el = Hr;
            else {
              el = jr;
              var R = Cr;
            }
          else
            h = v.nodeName, !h || h.toLowerCase() !== "input" || v.type !== "checkbox" && v.type !== "radio" ? y && ui(y.elementType) && (el = ls) : el = Rr;
          if (el && (el = el(l, y))) {
            Pf(
              T,
              el,
              a,
              S
            );
            break l;
          }
          R && R(l, v, y), l === "focusout" && y && v.type === "number" && y.memoizedProps.value != null && ei(v, "number", v.value);
        }
        switch (R = y ? Be(y) : window, l) {
          case "focusin":
            (If(R) || R.contentEditable === "true") && (ee = R, bi = y, Ke = null);
            break;
          case "focusout":
            Ke = bi = ee = null;
            break;
          case "mousedown":
            Si = !0;
            break;
          case "contextmenu":
          case "mouseup":
          case "dragend":
            Si = !1, ss(T, a, S);
            break;
          case "selectionchange":
            if (qr) break;
          case "keydown":
          case "keyup":
            ss(T, a, S);
        }
        var V;
        if (yi)
          l: {
            switch (l) {
              case "compositionstart":
                var I = "onCompositionStart";
                break l;
              case "compositionend":
                I = "onCompositionEnd";
                break l;
              case "compositionupdate":
                I = "onCompositionUpdate";
                break l;
            }
            I = void 0;
          }
        else
          ae ? kf(l, a) && (I = "onCompositionEnd") : l === "keydown" && a.keyCode === 229 && (I = "onCompositionStart");
        I && (wf && a.locale !== "ko" && (ae || I !== "onCompositionStart" ? I === "onCompositionEnd" && ae && (V = Lf()) : (ia = S, si = "value" in ia ? ia.value : ia.textContent, ae = !0)), R = Un(y, I), 0 < R.length && (I = new Kf(
          I,
          l,
          null,
          a,
          S
        ), T.push({ event: I, listeners: R }), V ? I.data = V : (V = Ff(a), V !== null && (I.data = V)))), (V = Nr ? Mr(l, a) : Or(l, a)) && (I = Un(y, "onBeforeInput"), 0 < I.length && (R = new Kf(
          "onBeforeInput",
          "beforeinput",
          null,
          a,
          S
        ), T.push({
          event: R,
          listeners: I
        }), R.data = V)), pm(
          T,
          l,
          y,
          a,
          S
        );
      }
      B0(T, t);
    });
  }
  function hu(l, t, a) {
    return {
      instance: l,
      listener: t,
      currentTarget: a
    };
  }
  function Un(l, t) {
    for (var a = t + "Capture", e = []; l !== null; ) {
      var u = l, n = u.stateNode;
      if (u = u.tag, u !== 5 && u !== 26 && u !== 27 || n === null || (u = qe(l, a), u != null && e.unshift(
        hu(l, u, n)
      ), u = qe(l, t), u != null && e.push(
        hu(l, u, n)
      )), l.tag === 3) return e;
      l = l.return;
    }
    return [];
  }
  function Am(l) {
    if (l === null) return null;
    do
      l = l.return;
    while (l && l.tag !== 5 && l.tag !== 27);
    return l || null;
  }
  function Y0(l, t, a, e, u) {
    for (var n = t._reactName, i = []; a !== null && a !== e; ) {
      var c = a, f = c.alternate, y = c.stateNode;
      if (c = c.tag, f !== null && f === e) break;
      c !== 5 && c !== 26 && c !== 27 || y === null || (f = y, u ? (y = qe(a, n), y != null && i.unshift(
        hu(a, y, f)
      )) : u || (y = qe(a, n), y != null && i.push(
        hu(a, y, f)
      ))), a = a.return;
    }
    i.length !== 0 && l.push({ event: t, listeners: i });
  }
  var xm = /\r\n?/g, _m = /\u0000|\uFFFD/g;
  function G0(l) {
    return (typeof l == "string" ? l : "" + l).replace(xm, `
`).replace(_m, "");
  }
  function X0(l, t) {
    return t = G0(t), G0(l) === t;
  }
  function hl(l, t, a, e, u, n) {
    switch (a) {
      case "children":
        typeof e == "string" ? t === "body" || t === "textarea" && e === "" || Pa(l, e) : (typeof e == "number" || typeof e == "bigint") && t !== "body" && Pa(l, "" + e);
        break;
      case "className":
        ju(l, "class", e);
        break;
      case "tabIndex":
        ju(l, "tabindex", e);
        break;
      case "dir":
      case "role":
      case "viewBox":
      case "width":
      case "height":
        ju(l, a, e);
        break;
      case "style":
        Gf(l, e, n);
        break;
      case "data":
        if (t !== "object") {
          ju(l, "data", e);
          break;
        }
      case "src":
      case "href":
        if (e === "" && (t !== "a" || a !== "href")) {
          l.removeAttribute(a);
          break;
        }
        if (e == null || typeof e == "function" || typeof e == "symbol" || typeof e == "boolean") {
          l.removeAttribute(a);
          break;
        }
        e = Hu("" + e), l.setAttribute(a, e);
        break;
      case "action":
      case "formAction":
        if (typeof e == "function") {
          l.setAttribute(
            a,
            "javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')"
          );
          break;
        } else
          typeof n == "function" && (a === "formAction" ? (t !== "input" && hl(l, t, "name", u.name, u, null), hl(
            l,
            t,
            "formEncType",
            u.formEncType,
            u,
            null
          ), hl(
            l,
            t,
            "formMethod",
            u.formMethod,
            u,
            null
          ), hl(
            l,
            t,
            "formTarget",
            u.formTarget,
            u,
            null
          )) : (hl(l, t, "encType", u.encType, u, null), hl(l, t, "method", u.method, u, null), hl(l, t, "target", u.target, u, null)));
        if (e == null || typeof e == "symbol" || typeof e == "boolean") {
          l.removeAttribute(a);
          break;
        }
        e = Hu("" + e), l.setAttribute(a, e);
        break;
      case "onClick":
        e != null && (l.onclick = Xt);
        break;
      case "onScroll":
        e != null && k("scroll", l);
        break;
      case "onScrollEnd":
        e != null && k("scrollend", l);
        break;
      case "dangerouslySetInnerHTML":
        if (e != null) {
          if (typeof e != "object" || !("__html" in e))
            throw Error(r(61));
          if (a = e.__html, a != null) {
            if (u.children != null) throw Error(r(60));
            l.innerHTML = a;
          }
        }
        break;
      case "multiple":
        l.multiple = e && typeof e != "function" && typeof e != "symbol";
        break;
      case "muted":
        l.muted = e && typeof e != "function" && typeof e != "symbol";
        break;
      case "suppressContentEditableWarning":
      case "suppressHydrationWarning":
      case "defaultValue":
      case "defaultChecked":
      case "innerHTML":
      case "ref":
        break;
      case "autoFocus":
        break;
      case "xlinkHref":
        if (e == null || typeof e == "function" || typeof e == "boolean" || typeof e == "symbol") {
          l.removeAttribute("xlink:href");
          break;
        }
        a = Hu("" + e), l.setAttributeNS(
          "http://www.w3.org/1999/xlink",
          "xlink:href",
          a
        );
        break;
      case "contentEditable":
      case "spellCheck":
      case "draggable":
      case "value":
      case "autoReverse":
      case "externalResourcesRequired":
      case "focusable":
      case "preserveAlpha":
        e != null && typeof e != "function" && typeof e != "symbol" ? l.setAttribute(a, "" + e) : l.removeAttribute(a);
        break;
      case "inert":
      case "allowFullScreen":
      case "async":
      case "autoPlay":
      case "controls":
      case "default":
      case "defer":
      case "disabled":
      case "disablePictureInPicture":
      case "disableRemotePlayback":
      case "formNoValidate":
      case "hidden":
      case "loop":
      case "noModule":
      case "noValidate":
      case "open":
      case "playsInline":
      case "readOnly":
      case "required":
      case "reversed":
      case "scoped":
      case "seamless":
      case "itemScope":
        e && typeof e != "function" && typeof e != "symbol" ? l.setAttribute(a, "") : l.removeAttribute(a);
        break;
      case "capture":
      case "download":
        e === !0 ? l.setAttribute(a, "") : e !== !1 && e != null && typeof e != "function" && typeof e != "symbol" ? l.setAttribute(a, e) : l.removeAttribute(a);
        break;
      case "cols":
      case "rows":
      case "size":
      case "span":
        e != null && typeof e != "function" && typeof e != "symbol" && !isNaN(e) && 1 <= e ? l.setAttribute(a, e) : l.removeAttribute(a);
        break;
      case "rowSpan":
      case "start":
        e == null || typeof e == "function" || typeof e == "symbol" || isNaN(e) ? l.removeAttribute(a) : l.setAttribute(a, e);
        break;
      case "popover":
        k("beforetoggle", l), k("toggle", l), Cu(l, "popover", e);
        break;
      case "xlinkActuate":
        Gt(
          l,
          "http://www.w3.org/1999/xlink",
          "xlink:actuate",
          e
        );
        break;
      case "xlinkArcrole":
        Gt(
          l,
          "http://www.w3.org/1999/xlink",
          "xlink:arcrole",
          e
        );
        break;
      case "xlinkRole":
        Gt(
          l,
          "http://www.w3.org/1999/xlink",
          "xlink:role",
          e
        );
        break;
      case "xlinkShow":
        Gt(
          l,
          "http://www.w3.org/1999/xlink",
          "xlink:show",
          e
        );
        break;
      case "xlinkTitle":
        Gt(
          l,
          "http://www.w3.org/1999/xlink",
          "xlink:title",
          e
        );
        break;
      case "xlinkType":
        Gt(
          l,
          "http://www.w3.org/1999/xlink",
          "xlink:type",
          e
        );
        break;
      case "xmlBase":
        Gt(
          l,
          "http://www.w3.org/XML/1998/namespace",
          "xml:base",
          e
        );
        break;
      case "xmlLang":
        Gt(
          l,
          "http://www.w3.org/XML/1998/namespace",
          "xml:lang",
          e
        );
        break;
      case "xmlSpace":
        Gt(
          l,
          "http://www.w3.org/XML/1998/namespace",
          "xml:space",
          e
        );
        break;
      case "is":
        Cu(l, "is", e);
        break;
      case "innerText":
      case "textContent":
        break;
      default:
        (!(2 < a.length) || a[0] !== "o" && a[0] !== "O" || a[1] !== "n" && a[1] !== "N") && (a = lr.get(a) || a, Cu(l, a, e));
    }
  }
  function Vc(l, t, a, e, u, n) {
    switch (a) {
      case "style":
        Gf(l, e, n);
        break;
      case "dangerouslySetInnerHTML":
        if (e != null) {
          if (typeof e != "object" || !("__html" in e))
            throw Error(r(61));
          if (a = e.__html, a != null) {
            if (u.children != null) throw Error(r(60));
            l.innerHTML = a;
          }
        }
        break;
      case "children":
        typeof e == "string" ? Pa(l, e) : (typeof e == "number" || typeof e == "bigint") && Pa(l, "" + e);
        break;
      case "onScroll":
        e != null && k("scroll", l);
        break;
      case "onScrollEnd":
        e != null && k("scrollend", l);
        break;
      case "onClick":
        e != null && (l.onclick = Xt);
        break;
      case "suppressContentEditableWarning":
      case "suppressHydrationWarning":
      case "innerHTML":
      case "ref":
        break;
      case "innerText":
      case "textContent":
        break;
      default:
        if (!Uf.hasOwnProperty(a))
          l: {
            if (a[0] === "o" && a[1] === "n" && (u = a.endsWith("Capture"), t = a.slice(2, u ? a.length - 7 : void 0), n = l[lt] || null, n = n != null ? n[a] : null, typeof n == "function" && l.removeEventListener(t, n, u), typeof e == "function")) {
              typeof n != "function" && n !== null && (a in l ? l[a] = null : l.hasAttribute(a) && l.removeAttribute(a)), l.addEventListener(t, e, u);
              break l;
            }
            a in l ? l[a] = e : e === !0 ? l.setAttribute(a, "") : Cu(l, a, e);
          }
    }
  }
  function Wl(l, t, a) {
    switch (t) {
      case "div":
      case "span":
      case "svg":
      case "path":
      case "a":
      case "g":
      case "p":
      case "li":
        break;
      case "img":
        k("error", l), k("load", l);
        var e = !1, u = !1, n;
        for (n in a)
          if (a.hasOwnProperty(n)) {
            var i = a[n];
            if (i != null)
              switch (n) {
                case "src":
                  e = !0;
                  break;
                case "srcSet":
                  u = !0;
                  break;
                case "children":
                case "dangerouslySetInnerHTML":
                  throw Error(r(137, t));
                default:
                  hl(l, t, n, i, a, null);
              }
          }
        u && hl(l, t, "srcSet", a.srcSet, a, null), e && hl(l, t, "src", a.src, a, null);
        return;
      case "input":
        k("invalid", l);
        var c = n = i = u = null, f = null, y = null;
        for (e in a)
          if (a.hasOwnProperty(e)) {
            var S = a[e];
            if (S != null)
              switch (e) {
                case "name":
                  u = S;
                  break;
                case "type":
                  i = S;
                  break;
                case "checked":
                  f = S;
                  break;
                case "defaultChecked":
                  y = S;
                  break;
                case "value":
                  n = S;
                  break;
                case "defaultValue":
                  c = S;
                  break;
                case "children":
                case "dangerouslySetInnerHTML":
                  if (S != null)
                    throw Error(r(137, t));
                  break;
                default:
                  hl(l, t, e, S, a, null);
              }
          }
        Hf(
          l,
          n,
          c,
          f,
          y,
          i,
          u,
          !1
        );
        return;
      case "select":
        k("invalid", l), e = i = n = null;
        for (u in a)
          if (a.hasOwnProperty(u) && (c = a[u], c != null))
            switch (u) {
              case "value":
                n = c;
                break;
              case "defaultValue":
                i = c;
                break;
              case "multiple":
                e = c;
              default:
                hl(l, t, u, c, a, null);
            }
        t = n, a = i, l.multiple = !!e, t != null ? Ia(l, !!e, t, !1) : a != null && Ia(l, !!e, a, !0);
        return;
      case "textarea":
        k("invalid", l), n = u = e = null;
        for (i in a)
          if (a.hasOwnProperty(i) && (c = a[i], c != null))
            switch (i) {
              case "value":
                e = c;
                break;
              case "defaultValue":
                u = c;
                break;
              case "children":
                n = c;
                break;
              case "dangerouslySetInnerHTML":
                if (c != null) throw Error(r(91));
                break;
              default:
                hl(l, t, i, c, a, null);
            }
        qf(l, e, u, n);
        return;
      case "option":
        for (f in a)
          a.hasOwnProperty(f) && (e = a[f], e != null) && (f === "selected" ? l.selected = e && typeof e != "function" && typeof e != "symbol" : hl(l, t, f, e, a, null));
        return;
      case "dialog":
        k("beforetoggle", l), k("toggle", l), k("cancel", l), k("close", l);
        break;
      case "iframe":
      case "object":
        k("load", l);
        break;
      case "video":
      case "audio":
        for (e = 0; e < vu.length; e++)
          k(vu[e], l);
        break;
      case "image":
        k("error", l), k("load", l);
        break;
      case "details":
        k("toggle", l);
        break;
      case "embed":
      case "source":
      case "link":
        k("error", l), k("load", l);
      case "area":
      case "base":
      case "br":
      case "col":
      case "hr":
      case "keygen":
      case "meta":
      case "param":
      case "track":
      case "wbr":
      case "menuitem":
        for (y in a)
          if (a.hasOwnProperty(y) && (e = a[y], e != null))
            switch (y) {
              case "children":
              case "dangerouslySetInnerHTML":
                throw Error(r(137, t));
              default:
                hl(l, t, y, e, a, null);
            }
        return;
      default:
        if (ui(t)) {
          for (S in a)
            a.hasOwnProperty(S) && (e = a[S], e !== void 0 && Vc(
              l,
              t,
              S,
              e,
              a,
              void 0
            ));
          return;
        }
    }
    for (c in a)
      a.hasOwnProperty(c) && (e = a[c], e != null && hl(l, t, c, e, a, null));
  }
  function Nm(l, t, a, e) {
    switch (t) {
      case "div":
      case "span":
      case "svg":
      case "path":
      case "a":
      case "g":
      case "p":
      case "li":
        break;
      case "input":
        var u = null, n = null, i = null, c = null, f = null, y = null, S = null;
        for (h in a) {
          var T = a[h];
          if (a.hasOwnProperty(h) && T != null)
            switch (h) {
              case "checked":
                break;
              case "value":
                break;
              case "defaultValue":
                f = T;
              default:
                e.hasOwnProperty(h) || hl(l, t, h, null, e, T);
            }
        }
        for (var v in e) {
          var h = e[v];
          if (T = a[v], e.hasOwnProperty(v) && (h != null || T != null))
            switch (v) {
              case "type":
                n = h;
                break;
              case "name":
                u = h;
                break;
              case "checked":
                y = h;
                break;
              case "defaultChecked":
                S = h;
                break;
              case "value":
                i = h;
                break;
              case "defaultValue":
                c = h;
                break;
              case "children":
              case "dangerouslySetInnerHTML":
                if (h != null)
                  throw Error(r(137, t));
                break;
              default:
                h !== T && hl(
                  l,
                  t,
                  v,
                  h,
                  e,
                  T
                );
            }
        }
        ai(
          l,
          i,
          c,
          f,
          y,
          S,
          n,
          u
        );
        return;
      case "select":
        h = i = c = v = null;
        for (n in a)
          if (f = a[n], a.hasOwnProperty(n) && f != null)
            switch (n) {
              case "value":
                break;
              case "multiple":
                h = f;
              default:
                e.hasOwnProperty(n) || hl(
                  l,
                  t,
                  n,
                  null,
                  e,
                  f
                );
            }
        for (u in e)
          if (n = e[u], f = a[u], e.hasOwnProperty(u) && (n != null || f != null))
            switch (u) {
              case "value":
                v = n;
                break;
              case "defaultValue":
                c = n;
                break;
              case "multiple":
                i = n;
              default:
                n !== f && hl(
                  l,
                  t,
                  u,
                  n,
                  e,
                  f
                );
            }
        t = c, a = i, e = h, v != null ? Ia(l, !!a, v, !1) : !!e != !!a && (t != null ? Ia(l, !!a, t, !0) : Ia(l, !!a, a ? [] : "", !1));
        return;
      case "textarea":
        h = v = null;
        for (c in a)
          if (u = a[c], a.hasOwnProperty(c) && u != null && !e.hasOwnProperty(c))
            switch (c) {
              case "value":
                break;
              case "children":
                break;
              default:
                hl(l, t, c, null, e, u);
            }
        for (i in e)
          if (u = e[i], n = a[i], e.hasOwnProperty(i) && (u != null || n != null))
            switch (i) {
              case "value":
                v = u;
                break;
              case "defaultValue":
                h = u;
                break;
              case "children":
                break;
              case "dangerouslySetInnerHTML":
                if (u != null) throw Error(r(91));
                break;
              default:
                u !== n && hl(l, t, i, u, e, n);
            }
        Bf(l, v, h);
        return;
      case "option":
        for (var D in a)
          v = a[D], a.hasOwnProperty(D) && v != null && !e.hasOwnProperty(D) && (D === "selected" ? l.selected = !1 : hl(
            l,
            t,
            D,
            null,
            e,
            v
          ));
        for (f in e)
          v = e[f], h = a[f], e.hasOwnProperty(f) && v !== h && (v != null || h != null) && (f === "selected" ? l.selected = v && typeof v != "function" && typeof v != "symbol" : hl(
            l,
            t,
            f,
            v,
            e,
            h
          ));
        return;
      case "img":
      case "link":
      case "area":
      case "base":
      case "br":
      case "col":
      case "embed":
      case "hr":
      case "keygen":
      case "meta":
      case "param":
      case "source":
      case "track":
      case "wbr":
      case "menuitem":
        for (var Y in a)
          v = a[Y], a.hasOwnProperty(Y) && v != null && !e.hasOwnProperty(Y) && hl(l, t, Y, null, e, v);
        for (y in e)
          if (v = e[y], h = a[y], e.hasOwnProperty(y) && v !== h && (v != null || h != null))
            switch (y) {
              case "children":
              case "dangerouslySetInnerHTML":
                if (v != null)
                  throw Error(r(137, t));
                break;
              default:
                hl(
                  l,
                  t,
                  y,
                  v,
                  e,
                  h
                );
            }
        return;
      default:
        if (ui(t)) {
          for (var gl in a)
            v = a[gl], a.hasOwnProperty(gl) && v !== void 0 && !e.hasOwnProperty(gl) && Vc(
              l,
              t,
              gl,
              void 0,
              e,
              v
            );
          for (S in e)
            v = e[S], h = a[S], !e.hasOwnProperty(S) || v === h || v === void 0 && h === void 0 || Vc(
              l,
              t,
              S,
              v,
              e,
              h
            );
          return;
        }
    }
    for (var d in a)
      v = a[d], a.hasOwnProperty(d) && v != null && !e.hasOwnProperty(d) && hl(l, t, d, null, e, v);
    for (T in e)
      v = e[T], h = a[T], !e.hasOwnProperty(T) || v === h || v == null && h == null || hl(l, t, T, v, e, h);
  }
  function Q0(l) {
    switch (l) {
      case "css":
      case "script":
      case "font":
      case "img":
      case "image":
      case "input":
      case "link":
        return !0;
      default:
        return !1;
    }
  }
  function Mm() {
    if (typeof performance.getEntriesByType == "function") {
      for (var l = 0, t = 0, a = performance.getEntriesByType("resource"), e = 0; e < a.length; e++) {
        var u = a[e], n = u.transferSize, i = u.initiatorType, c = u.duration;
        if (n && c && Q0(i)) {
          for (i = 0, c = u.responseEnd, e += 1; e < a.length; e++) {
            var f = a[e], y = f.startTime;
            if (y > c) break;
            var S = f.transferSize, T = f.initiatorType;
            S && Q0(T) && (f = f.responseEnd, i += S * (f < c ? 1 : (c - y) / (f - y)));
          }
          if (--e, t += 8 * (n + i) / (u.duration / 1e3), l++, 10 < l) break;
        }
      }
      if (0 < l) return t / l / 1e6;
    }
    return navigator.connection && (l = navigator.connection.downlink, typeof l == "number") ? l : 5;
  }
  var Kc = null, Jc = null;
  function Dn(l) {
    return l.nodeType === 9 ? l : l.ownerDocument;
  }
  function L0(l) {
    switch (l) {
      case "http://www.w3.org/2000/svg":
        return 1;
      case "http://www.w3.org/1998/Math/MathML":
        return 2;
      default:
        return 0;
    }
  }
  function Z0(l, t) {
    if (l === 0)
      switch (t) {
        case "svg":
          return 1;
        case "math":
          return 2;
        default:
          return 0;
      }
    return l === 1 && t === "foreignObject" ? 0 : l;
  }
  function wc(l, t) {
    return l === "textarea" || l === "noscript" || typeof t.children == "string" || typeof t.children == "number" || typeof t.children == "bigint" || typeof t.dangerouslySetInnerHTML == "object" && t.dangerouslySetInnerHTML !== null && t.dangerouslySetInnerHTML.__html != null;
  }
  var $c = null;
  function Om() {
    var l = window.event;
    return l && l.type === "popstate" ? l === $c ? !1 : ($c = l, !0) : ($c = null, !1);
  }
  var V0 = typeof setTimeout == "function" ? setTimeout : void 0, Um = typeof clearTimeout == "function" ? clearTimeout : void 0, K0 = typeof Promise == "function" ? Promise : void 0, Dm = typeof queueMicrotask == "function" ? queueMicrotask : typeof K0 < "u" ? function(l) {
    return K0.resolve(null).then(l).catch(Cm);
  } : V0;
  function Cm(l) {
    setTimeout(function() {
      throw l;
    });
  }
  function Ea(l) {
    return l === "head";
  }
  function J0(l, t) {
    var a = t, e = 0;
    do {
      var u = a.nextSibling;
      if (l.removeChild(a), u && u.nodeType === 8)
        if (a = u.data, a === "/$" || a === "/&") {
          if (e === 0) {
            l.removeChild(u), Ue(t);
            return;
          }
          e--;
        } else if (a === "$" || a === "$?" || a === "$~" || a === "$!" || a === "&")
          e++;
        else if (a === "html")
          gu(l.ownerDocument.documentElement);
        else if (a === "head") {
          a = l.ownerDocument.head, gu(a);
          for (var n = a.firstChild; n; ) {
            var i = n.nextSibling, c = n.nodeName;
            n[He] || c === "SCRIPT" || c === "STYLE" || c === "LINK" && n.rel.toLowerCase() === "stylesheet" || a.removeChild(n), n = i;
          }
        } else
          a === "body" && gu(l.ownerDocument.body);
      a = u;
    } while (a);
    Ue(t);
  }
  function w0(l, t) {
    var a = l;
    l = 0;
    do {
      var e = a.nextSibling;
      if (a.nodeType === 1 ? t ? (a._stashedDisplay = a.style.display, a.style.display = "none") : (a.style.display = a._stashedDisplay || "", a.getAttribute("style") === "" && a.removeAttribute("style")) : a.nodeType === 3 && (t ? (a._stashedText = a.nodeValue, a.nodeValue = "") : a.nodeValue = a._stashedText || ""), e && e.nodeType === 8)
        if (a = e.data, a === "/$") {
          if (l === 0) break;
          l--;
        } else
          a !== "$" && a !== "$?" && a !== "$~" && a !== "$!" || l++;
      a = e;
    } while (a);
  }
  function Wc(l) {
    var t = l.firstChild;
    for (t && t.nodeType === 10 && (t = t.nextSibling); t; ) {
      var a = t;
      switch (t = t.nextSibling, a.nodeName) {
        case "HTML":
        case "HEAD":
        case "BODY":
          Wc(a), li(a);
          continue;
        case "SCRIPT":
        case "STYLE":
          continue;
        case "LINK":
          if (a.rel.toLowerCase() === "stylesheet") continue;
      }
      l.removeChild(a);
    }
  }
  function jm(l, t, a, e) {
    for (; l.nodeType === 1; ) {
      var u = a;
      if (l.nodeName.toLowerCase() !== t.toLowerCase()) {
        if (!e && (l.nodeName !== "INPUT" || l.type !== "hidden"))
          break;
      } else if (e) {
        if (!l[He])
          switch (t) {
            case "meta":
              if (!l.hasAttribute("itemprop")) break;
              return l;
            case "link":
              if (n = l.getAttribute("rel"), n === "stylesheet" && l.hasAttribute("data-precedence"))
                break;
              if (n !== u.rel || l.getAttribute("href") !== (u.href == null || u.href === "" ? null : u.href) || l.getAttribute("crossorigin") !== (u.crossOrigin == null ? null : u.crossOrigin) || l.getAttribute("title") !== (u.title == null ? null : u.title))
                break;
              return l;
            case "style":
              if (l.hasAttribute("data-precedence")) break;
              return l;
            case "script":
              if (n = l.getAttribute("src"), (n !== (u.src == null ? null : u.src) || l.getAttribute("type") !== (u.type == null ? null : u.type) || l.getAttribute("crossorigin") !== (u.crossOrigin == null ? null : u.crossOrigin)) && n && l.hasAttribute("async") && !l.hasAttribute("itemprop"))
                break;
              return l;
            default:
              return l;
          }
      } else if (t === "input" && l.type === "hidden") {
        var n = u.name == null ? null : "" + u.name;
        if (u.type === "hidden" && l.getAttribute("name") === n)
          return l;
      } else return l;
      if (l = Mt(l.nextSibling), l === null) break;
    }
    return null;
  }
  function Rm(l, t, a) {
    if (t === "") return null;
    for (; l.nodeType !== 3; )
      if ((l.nodeType !== 1 || l.nodeName !== "INPUT" || l.type !== "hidden") && !a || (l = Mt(l.nextSibling), l === null)) return null;
    return l;
  }
  function $0(l, t) {
    for (; l.nodeType !== 8; )
      if ((l.nodeType !== 1 || l.nodeName !== "INPUT" || l.type !== "hidden") && !t || (l = Mt(l.nextSibling), l === null)) return null;
    return l;
  }
  function kc(l) {
    return l.data === "$?" || l.data === "$~";
  }
  function Fc(l) {
    return l.data === "$!" || l.data === "$?" && l.ownerDocument.readyState !== "loading";
  }
  function Hm(l, t) {
    var a = l.ownerDocument;
    if (l.data === "$~") l._reactRetry = t;
    else if (l.data !== "$?" || a.readyState !== "loading")
      t();
    else {
      var e = function() {
        t(), a.removeEventListener("DOMContentLoaded", e);
      };
      a.addEventListener("DOMContentLoaded", e), l._reactRetry = e;
    }
  }
  function Mt(l) {
    for (; l != null; l = l.nextSibling) {
      var t = l.nodeType;
      if (t === 1 || t === 3) break;
      if (t === 8) {
        if (t = l.data, t === "$" || t === "$!" || t === "$?" || t === "$~" || t === "&" || t === "F!" || t === "F")
          break;
        if (t === "/$" || t === "/&") return null;
      }
    }
    return l;
  }
  var Ic = null;
  function W0(l) {
    l = l.nextSibling;
    for (var t = 0; l; ) {
      if (l.nodeType === 8) {
        var a = l.data;
        if (a === "/$" || a === "/&") {
          if (t === 0)
            return Mt(l.nextSibling);
          t--;
        } else
          a !== "$" && a !== "$!" && a !== "$?" && a !== "$~" && a !== "&" || t++;
      }
      l = l.nextSibling;
    }
    return null;
  }
  function k0(l) {
    l = l.previousSibling;
    for (var t = 0; l; ) {
      if (l.nodeType === 8) {
        var a = l.data;
        if (a === "$" || a === "$!" || a === "$?" || a === "$~" || a === "&") {
          if (t === 0) return l;
          t--;
        } else a !== "/$" && a !== "/&" || t++;
      }
      l = l.previousSibling;
    }
    return null;
  }
  function F0(l, t, a) {
    switch (t = Dn(a), l) {
      case "html":
        if (l = t.documentElement, !l) throw Error(r(452));
        return l;
      case "head":
        if (l = t.head, !l) throw Error(r(453));
        return l;
      case "body":
        if (l = t.body, !l) throw Error(r(454));
        return l;
      default:
        throw Error(r(451));
    }
  }
  function gu(l) {
    for (var t = l.attributes; t.length; )
      l.removeAttributeNode(t[0]);
    li(l);
  }
  var Ot = /* @__PURE__ */ new Map(), I0 = /* @__PURE__ */ new Set();
  function Cn(l) {
    return typeof l.getRootNode == "function" ? l.getRootNode() : l.nodeType === 9 ? l : l.ownerDocument;
  }
  var aa = N.d;
  N.d = {
    f: Bm,
    r: qm,
    D: Ym,
    C: Gm,
    L: Xm,
    m: Qm,
    X: Zm,
    S: Lm,
    M: Vm
  };
  function Bm() {
    var l = aa.f(), t = En();
    return l || t;
  }
  function qm(l) {
    var t = Wa(l);
    t !== null && t.tag === 5 && t.type === "form" ? vo(t) : aa.r(l);
  }
  var Ne = typeof document > "u" ? null : document;
  function P0(l, t, a) {
    var e = Ne;
    if (e && typeof t == "string" && t) {
      var u = Tt(t);
      u = 'link[rel="' + l + '"][href="' + u + '"]', typeof a == "string" && (u += '[crossorigin="' + a + '"]'), I0.has(u) || (I0.add(u), l = { rel: l, crossOrigin: a, href: t }, e.querySelector(u) === null && (t = e.createElement("link"), Wl(t, "link", l), Xl(t), e.head.appendChild(t)));
    }
  }
  function Ym(l) {
    aa.D(l), P0("dns-prefetch", l, null);
  }
  function Gm(l, t) {
    aa.C(l, t), P0("preconnect", l, t);
  }
  function Xm(l, t, a) {
    aa.L(l, t, a);
    var e = Ne;
    if (e && l && t) {
      var u = 'link[rel="preload"][as="' + Tt(t) + '"]';
      t === "image" && a && a.imageSrcSet ? (u += '[imagesrcset="' + Tt(
        a.imageSrcSet
      ) + '"]', typeof a.imageSizes == "string" && (u += '[imagesizes="' + Tt(
        a.imageSizes
      ) + '"]')) : u += '[href="' + Tt(l) + '"]';
      var n = u;
      switch (t) {
        case "style":
          n = Me(l);
          break;
        case "script":
          n = Oe(l);
      }
      Ot.has(n) || (l = j(
        {
          rel: "preload",
          href: t === "image" && a && a.imageSrcSet ? void 0 : l,
          as: t
        },
        a
      ), Ot.set(n, l), e.querySelector(u) !== null || t === "style" && e.querySelector(bu(n)) || t === "script" && e.querySelector(Su(n)) || (t = e.createElement("link"), Wl(t, "link", l), Xl(t), e.head.appendChild(t)));
    }
  }
  function Qm(l, t) {
    aa.m(l, t);
    var a = Ne;
    if (a && l) {
      var e = t && typeof t.as == "string" ? t.as : "script", u = 'link[rel="modulepreload"][as="' + Tt(e) + '"][href="' + Tt(l) + '"]', n = u;
      switch (e) {
        case "audioworklet":
        case "paintworklet":
        case "serviceworker":
        case "sharedworker":
        case "worker":
        case "script":
          n = Oe(l);
      }
      if (!Ot.has(n) && (l = j({ rel: "modulepreload", href: l }, t), Ot.set(n, l), a.querySelector(u) === null)) {
        switch (e) {
          case "audioworklet":
          case "paintworklet":
          case "serviceworker":
          case "sharedworker":
          case "worker":
          case "script":
            if (a.querySelector(Su(n)))
              return;
        }
        e = a.createElement("link"), Wl(e, "link", l), Xl(e), a.head.appendChild(e);
      }
    }
  }
  function Lm(l, t, a) {
    aa.S(l, t, a);
    var e = Ne;
    if (e && l) {
      var u = ka(e).hoistableStyles, n = Me(l);
      t = t || "default";
      var i = u.get(n);
      if (!i) {
        var c = { loading: 0, preload: null };
        if (i = e.querySelector(
          bu(n)
        ))
          c.loading = 5;
        else {
          l = j(
            { rel: "stylesheet", href: l, "data-precedence": t },
            a
          ), (a = Ot.get(n)) && Pc(l, a);
          var f = i = e.createElement("link");
          Xl(f), Wl(f, "link", l), f._p = new Promise(function(y, S) {
            f.onload = y, f.onerror = S;
          }), f.addEventListener("load", function() {
            c.loading |= 1;
          }), f.addEventListener("error", function() {
            c.loading |= 2;
          }), c.loading |= 4, jn(i, t, e);
        }
        i = {
          type: "stylesheet",
          instance: i,
          count: 1,
          state: c
        }, u.set(n, i);
      }
    }
  }
  function Zm(l, t) {
    aa.X(l, t);
    var a = Ne;
    if (a && l) {
      var e = ka(a).hoistableScripts, u = Oe(l), n = e.get(u);
      n || (n = a.querySelector(Su(u)), n || (l = j({ src: l, async: !0 }, t), (t = Ot.get(u)) && lf(l, t), n = a.createElement("script"), Xl(n), Wl(n, "link", l), a.head.appendChild(n)), n = {
        type: "script",
        instance: n,
        count: 1,
        state: null
      }, e.set(u, n));
    }
  }
  function Vm(l, t) {
    aa.M(l, t);
    var a = Ne;
    if (a && l) {
      var e = ka(a).hoistableScripts, u = Oe(l), n = e.get(u);
      n || (n = a.querySelector(Su(u)), n || (l = j({ src: l, async: !0, type: "module" }, t), (t = Ot.get(u)) && lf(l, t), n = a.createElement("script"), Xl(n), Wl(n, "link", l), a.head.appendChild(n)), n = {
        type: "script",
        instance: n,
        count: 1,
        state: null
      }, e.set(u, n));
    }
  }
  function ld(l, t, a, e) {
    var u = (u = K.current) ? Cn(u) : null;
    if (!u) throw Error(r(446));
    switch (l) {
      case "meta":
      case "title":
        return null;
      case "style":
        return typeof a.precedence == "string" && typeof a.href == "string" ? (t = Me(a.href), a = ka(
          u
        ).hoistableStyles, e = a.get(t), e || (e = {
          type: "style",
          instance: null,
          count: 0,
          state: null
        }, a.set(t, e)), e) : { type: "void", instance: null, count: 0, state: null };
      case "link":
        if (a.rel === "stylesheet" && typeof a.href == "string" && typeof a.precedence == "string") {
          l = Me(a.href);
          var n = ka(
            u
          ).hoistableStyles, i = n.get(l);
          if (i || (u = u.ownerDocument || u, i = {
            type: "stylesheet",
            instance: null,
            count: 0,
            state: { loading: 0, preload: null }
          }, n.set(l, i), (n = u.querySelector(
            bu(l)
          )) && !n._p && (i.instance = n, i.state.loading = 5), Ot.has(l) || (a = {
            rel: "preload",
            as: "style",
            href: a.href,
            crossOrigin: a.crossOrigin,
            integrity: a.integrity,
            media: a.media,
            hrefLang: a.hrefLang,
            referrerPolicy: a.referrerPolicy
          }, Ot.set(l, a), n || Km(
            u,
            l,
            a,
            i.state
          ))), t && e === null)
            throw Error(r(528, ""));
          return i;
        }
        if (t && e !== null)
          throw Error(r(529, ""));
        return null;
      case "script":
        return t = a.async, a = a.src, typeof a == "string" && t && typeof t != "function" && typeof t != "symbol" ? (t = Oe(a), a = ka(
          u
        ).hoistableScripts, e = a.get(t), e || (e = {
          type: "script",
          instance: null,
          count: 0,
          state: null
        }, a.set(t, e)), e) : { type: "void", instance: null, count: 0, state: null };
      default:
        throw Error(r(444, l));
    }
  }
  function Me(l) {
    return 'href="' + Tt(l) + '"';
  }
  function bu(l) {
    return 'link[rel="stylesheet"][' + l + "]";
  }
  function td(l) {
    return j({}, l, {
      "data-precedence": l.precedence,
      precedence: null
    });
  }
  function Km(l, t, a, e) {
    l.querySelector('link[rel="preload"][as="style"][' + t + "]") ? e.loading = 1 : (t = l.createElement("link"), e.preload = t, t.addEventListener("load", function() {
      return e.loading |= 1;
    }), t.addEventListener("error", function() {
      return e.loading |= 2;
    }), Wl(t, "link", a), Xl(t), l.head.appendChild(t));
  }
  function Oe(l) {
    return '[src="' + Tt(l) + '"]';
  }
  function Su(l) {
    return "script[async]" + l;
  }
  function ad(l, t, a) {
    if (t.count++, t.instance === null)
      switch (t.type) {
        case "style":
          var e = l.querySelector(
            'style[data-href~="' + Tt(a.href) + '"]'
          );
          if (e)
            return t.instance = e, Xl(e), e;
          var u = j({}, a, {
            "data-href": a.href,
            "data-precedence": a.precedence,
            href: null,
            precedence: null
          });
          return e = (l.ownerDocument || l).createElement(
            "style"
          ), Xl(e), Wl(e, "style", u), jn(e, a.precedence, l), t.instance = e;
        case "stylesheet":
          u = Me(a.href);
          var n = l.querySelector(
            bu(u)
          );
          if (n)
            return t.state.loading |= 4, t.instance = n, Xl(n), n;
          e = td(a), (u = Ot.get(u)) && Pc(e, u), n = (l.ownerDocument || l).createElement("link"), Xl(n);
          var i = n;
          return i._p = new Promise(function(c, f) {
            i.onload = c, i.onerror = f;
          }), Wl(n, "link", e), t.state.loading |= 4, jn(n, a.precedence, l), t.instance = n;
        case "script":
          return n = Oe(a.src), (u = l.querySelector(
            Su(n)
          )) ? (t.instance = u, Xl(u), u) : (e = a, (u = Ot.get(n)) && (e = j({}, a), lf(e, u)), l = l.ownerDocument || l, u = l.createElement("script"), Xl(u), Wl(u, "link", e), l.head.appendChild(u), t.instance = u);
        case "void":
          return null;
        default:
          throw Error(r(443, t.type));
      }
    else
      t.type === "stylesheet" && (t.state.loading & 4) === 0 && (e = t.instance, t.state.loading |= 4, jn(e, a.precedence, l));
    return t.instance;
  }
  function jn(l, t, a) {
    for (var e = a.querySelectorAll(
      'link[rel="stylesheet"][data-precedence],style[data-precedence]'
    ), u = e.length ? e[e.length - 1] : null, n = u, i = 0; i < e.length; i++) {
      var c = e[i];
      if (c.dataset.precedence === t) n = c;
      else if (n !== u) break;
    }
    n ? n.parentNode.insertBefore(l, n.nextSibling) : (t = a.nodeType === 9 ? a.head : a, t.insertBefore(l, t.firstChild));
  }
  function Pc(l, t) {
    l.crossOrigin == null && (l.crossOrigin = t.crossOrigin), l.referrerPolicy == null && (l.referrerPolicy = t.referrerPolicy), l.title == null && (l.title = t.title);
  }
  function lf(l, t) {
    l.crossOrigin == null && (l.crossOrigin = t.crossOrigin), l.referrerPolicy == null && (l.referrerPolicy = t.referrerPolicy), l.integrity == null && (l.integrity = t.integrity);
  }
  var Rn = null;
  function ed(l, t, a) {
    if (Rn === null) {
      var e = /* @__PURE__ */ new Map(), u = Rn = /* @__PURE__ */ new Map();
      u.set(a, e);
    } else
      u = Rn, e = u.get(a), e || (e = /* @__PURE__ */ new Map(), u.set(a, e));
    if (e.has(l)) return e;
    for (e.set(l, null), a = a.getElementsByTagName(l), u = 0; u < a.length; u++) {
      var n = a[u];
      if (!(n[He] || n[Kl] || l === "link" && n.getAttribute("rel") === "stylesheet") && n.namespaceURI !== "http://www.w3.org/2000/svg") {
        var i = n.getAttribute(t) || "";
        i = l + i;
        var c = e.get(i);
        c ? c.push(n) : e.set(i, [n]);
      }
    }
    return e;
  }
  function ud(l, t, a) {
    l = l.ownerDocument || l, l.head.insertBefore(
      a,
      t === "title" ? l.querySelector("head > title") : null
    );
  }
  function Jm(l, t, a) {
    if (a === 1 || t.itemProp != null) return !1;
    switch (l) {
      case "meta":
      case "title":
        return !0;
      case "style":
        if (typeof t.precedence != "string" || typeof t.href != "string" || t.href === "")
          break;
        return !0;
      case "link":
        if (typeof t.rel != "string" || typeof t.href != "string" || t.href === "" || t.onLoad || t.onError)
          break;
        return t.rel === "stylesheet" ? (l = t.disabled, typeof t.precedence == "string" && l == null) : !0;
      case "script":
        if (t.async && typeof t.async != "function" && typeof t.async != "symbol" && !t.onLoad && !t.onError && t.src && typeof t.src == "string")
          return !0;
    }
    return !1;
  }
  function nd(l) {
    return !(l.type === "stylesheet" && (l.state.loading & 3) === 0);
  }
  function wm(l, t, a, e) {
    if (a.type === "stylesheet" && (typeof e.media != "string" || matchMedia(e.media).matches !== !1) && (a.state.loading & 4) === 0) {
      if (a.instance === null) {
        var u = Me(e.href), n = t.querySelector(
          bu(u)
        );
        if (n) {
          t = n._p, t !== null && typeof t == "object" && typeof t.then == "function" && (l.count++, l = Hn.bind(l), t.then(l, l)), a.state.loading |= 4, a.instance = n, Xl(n);
          return;
        }
        n = t.ownerDocument || t, e = td(e), (u = Ot.get(u)) && Pc(e, u), n = n.createElement("link"), Xl(n);
        var i = n;
        i._p = new Promise(function(c, f) {
          i.onload = c, i.onerror = f;
        }), Wl(n, "link", e), a.instance = n;
      }
      l.stylesheets === null && (l.stylesheets = /* @__PURE__ */ new Map()), l.stylesheets.set(a, t), (t = a.state.preload) && (a.state.loading & 3) === 0 && (l.count++, a = Hn.bind(l), t.addEventListener("load", a), t.addEventListener("error", a));
    }
  }
  var tf = 0;
  function $m(l, t) {
    return l.stylesheets && l.count === 0 && qn(l, l.stylesheets), 0 < l.count || 0 < l.imgCount ? function(a) {
      var e = setTimeout(function() {
        if (l.stylesheets && qn(l, l.stylesheets), l.unsuspend) {
          var n = l.unsuspend;
          l.unsuspend = null, n();
        }
      }, 6e4 + t);
      0 < l.imgBytes && tf === 0 && (tf = 62500 * Mm());
      var u = setTimeout(
        function() {
          if (l.waitingForImages = !1, l.count === 0 && (l.stylesheets && qn(l, l.stylesheets), l.unsuspend)) {
            var n = l.unsuspend;
            l.unsuspend = null, n();
          }
        },
        (l.imgBytes > tf ? 50 : 800) + t
      );
      return l.unsuspend = a, function() {
        l.unsuspend = null, clearTimeout(e), clearTimeout(u);
      };
    } : null;
  }
  function Hn() {
    if (this.count--, this.count === 0 && (this.imgCount === 0 || !this.waitingForImages)) {
      if (this.stylesheets) qn(this, this.stylesheets);
      else if (this.unsuspend) {
        var l = this.unsuspend;
        this.unsuspend = null, l();
      }
    }
  }
  var Bn = null;
  function qn(l, t) {
    l.stylesheets = null, l.unsuspend !== null && (l.count++, Bn = /* @__PURE__ */ new Map(), t.forEach(Wm, l), Bn = null, Hn.call(l));
  }
  function Wm(l, t) {
    if (!(t.state.loading & 4)) {
      var a = Bn.get(l);
      if (a) var e = a.get(null);
      else {
        a = /* @__PURE__ */ new Map(), Bn.set(l, a);
        for (var u = l.querySelectorAll(
          "link[data-precedence],style[data-precedence]"
        ), n = 0; n < u.length; n++) {
          var i = u[n];
          (i.nodeName === "LINK" || i.getAttribute("media") !== "not all") && (a.set(i.dataset.precedence, i), e = i);
        }
        e && a.set(null, e);
      }
      u = t.instance, i = u.getAttribute("data-precedence"), n = a.get(i) || e, n === e && a.set(null, u), a.set(i, u), this.count++, e = Hn.bind(this), u.addEventListener("load", e), u.addEventListener("error", e), n ? n.parentNode.insertBefore(u, n.nextSibling) : (l = l.nodeType === 9 ? l.head : l, l.insertBefore(u, l.firstChild)), t.state.loading |= 4;
    }
  }
  var pu = {
    $$typeof: Yl,
    Provider: null,
    Consumer: null,
    _currentValue: q,
    _currentValue2: q,
    _threadCount: 0
  };
  function km(l, t, a, e, u, n, i, c, f) {
    this.tag = 1, this.containerInfo = l, this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = -1, this.callbackNode = this.next = this.pendingContext = this.context = this.cancelPendingCommit = null, this.callbackPriority = 0, this.expirationTimes = kn(-1), this.entangledLanes = this.shellSuspendCounter = this.errorRecoveryDisabledLanes = this.expiredLanes = this.warmLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = kn(0), this.hiddenUpdates = kn(null), this.identifierPrefix = e, this.onUncaughtError = u, this.onCaughtError = n, this.onRecoverableError = i, this.pooledCache = null, this.pooledCacheLanes = 0, this.formState = f, this.incompleteTransitions = /* @__PURE__ */ new Map();
  }
  function id(l, t, a, e, u, n, i, c, f, y, S, T) {
    return l = new km(
      l,
      t,
      a,
      i,
      f,
      y,
      S,
      T,
      c
    ), t = 1, n === !0 && (t |= 24), n = dt(3, null, null, t), l.current = n, n.stateNode = l, t = Ri(), t.refCount++, l.pooledCache = t, t.refCount++, n.memoizedState = {
      element: e,
      isDehydrated: a,
      cache: t
    }, Yi(n), l;
  }
  function cd(l) {
    return l ? (l = ie, l) : ie;
  }
  function fd(l, t, a, e, u, n) {
    u = cd(u), e.context === null ? e.context = u : e.pendingContext = u, e = ra(t), e.payload = { element: a }, n = n === void 0 ? null : n, n !== null && (e.callback = n), a = ma(l, e, t), a !== null && (it(a, l, t), Ie(a, l, t));
  }
  function sd(l, t) {
    if (l = l.memoizedState, l !== null && l.dehydrated !== null) {
      var a = l.retryLane;
      l.retryLane = a !== 0 && a < t ? a : t;
    }
  }
  function af(l, t) {
    sd(l, t), (l = l.alternate) && sd(l, t);
  }
  function od(l) {
    if (l.tag === 13 || l.tag === 31) {
      var t = Ra(l, 67108864);
      t !== null && it(t, l, 67108864), af(l, 67108864);
    }
  }
  function dd(l) {
    if (l.tag === 13 || l.tag === 31) {
      var t = ht();
      t = Fn(t);
      var a = Ra(l, t);
      a !== null && it(a, l, t), af(l, t);
    }
  }
  var Yn = !0;
  function Fm(l, t, a, e) {
    var u = b.T;
    b.T = null;
    var n = N.p;
    try {
      N.p = 2, ef(l, t, a, e);
    } finally {
      N.p = n, b.T = u;
    }
  }
  function Im(l, t, a, e) {
    var u = b.T;
    b.T = null;
    var n = N.p;
    try {
      N.p = 8, ef(l, t, a, e);
    } finally {
      N.p = n, b.T = u;
    }
  }
  function ef(l, t, a, e) {
    if (Yn) {
      var u = uf(e);
      if (u === null)
        Zc(
          l,
          t,
          e,
          Gn,
          a
        ), md(l, e);
      else if (ly(
        u,
        l,
        t,
        a,
        e
      ))
        e.stopPropagation();
      else if (md(l, e), t & 4 && -1 < Pm.indexOf(l)) {
        for (; u !== null; ) {
          var n = Wa(u);
          if (n !== null)
            switch (n.tag) {
              case 3:
                if (n = n.stateNode, n.current.memoizedState.isDehydrated) {
                  var i = Oa(n.pendingLanes);
                  if (i !== 0) {
                    var c = n;
                    for (c.pendingLanes |= 2, c.entangledLanes |= 2; i; ) {
                      var f = 1 << 31 - st(i);
                      c.entanglements[1] |= f, i &= ~f;
                    }
                    Yt(n), (il & 6) === 0 && (Tn = ct() + 500, yu(0));
                  }
                }
                break;
              case 31:
              case 13:
                c = Ra(n, 2), c !== null && it(c, n, 2), En(), af(n, 2);
            }
          if (n = uf(e), n === null && Zc(
            l,
            t,
            e,
            Gn,
            a
          ), n === u) break;
          u = n;
        }
        u !== null && e.stopPropagation();
      } else
        Zc(
          l,
          t,
          e,
          null,
          a
        );
    }
  }
  function uf(l) {
    return l = ii(l), nf(l);
  }
  var Gn = null;
  function nf(l) {
    if (Gn = null, l = $a(l), l !== null) {
      var t = G(l);
      if (t === null) l = null;
      else {
        var a = t.tag;
        if (a === 13) {
          if (l = nl(t), l !== null) return l;
          l = null;
        } else if (a === 31) {
          if (l = cl(t), l !== null) return l;
          l = null;
        } else if (a === 3) {
          if (t.stateNode.current.memoizedState.isDehydrated)
            return t.tag === 3 ? t.stateNode.containerInfo : null;
          l = null;
        } else t !== l && (l = null);
      }
    }
    return Gn = l, null;
  }
  function rd(l) {
    switch (l) {
      case "beforetoggle":
      case "cancel":
      case "click":
      case "close":
      case "contextmenu":
      case "copy":
      case "cut":
      case "auxclick":
      case "dblclick":
      case "dragend":
      case "dragstart":
      case "drop":
      case "focusin":
      case "focusout":
      case "input":
      case "invalid":
      case "keydown":
      case "keypress":
      case "keyup":
      case "mousedown":
      case "mouseup":
      case "paste":
      case "pause":
      case "play":
      case "pointercancel":
      case "pointerdown":
      case "pointerup":
      case "ratechange":
      case "reset":
      case "resize":
      case "seeked":
      case "submit":
      case "toggle":
      case "touchcancel":
      case "touchend":
      case "touchstart":
      case "volumechange":
      case "change":
      case "selectionchange":
      case "textInput":
      case "compositionstart":
      case "compositionend":
      case "compositionupdate":
      case "beforeblur":
      case "afterblur":
      case "beforeinput":
      case "blur":
      case "fullscreenchange":
      case "focus":
      case "hashchange":
      case "popstate":
      case "select":
      case "selectstart":
        return 2;
      case "drag":
      case "dragenter":
      case "dragexit":
      case "dragleave":
      case "dragover":
      case "mousemove":
      case "mouseout":
      case "mouseover":
      case "pointermove":
      case "pointerout":
      case "pointerover":
      case "scroll":
      case "touchmove":
      case "wheel":
      case "mouseenter":
      case "mouseleave":
      case "pointerenter":
      case "pointerleave":
        return 8;
      case "message":
        switch (Yd()) {
          case Sf:
            return 2;
          case pf:
            return 8;
          case Nu:
          case Gd:
            return 32;
          case Tf:
            return 268435456;
          default:
            return 32;
        }
      default:
        return 32;
    }
  }
  var cf = !1, Aa = null, xa = null, _a = null, Tu = /* @__PURE__ */ new Map(), zu = /* @__PURE__ */ new Map(), Na = [], Pm = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(
    " "
  );
  function md(l, t) {
    switch (l) {
      case "focusin":
      case "focusout":
        Aa = null;
        break;
      case "dragenter":
      case "dragleave":
        xa = null;
        break;
      case "mouseover":
      case "mouseout":
        _a = null;
        break;
      case "pointerover":
      case "pointerout":
        Tu.delete(t.pointerId);
        break;
      case "gotpointercapture":
      case "lostpointercapture":
        zu.delete(t.pointerId);
    }
  }
  function Eu(l, t, a, e, u, n) {
    return l === null || l.nativeEvent !== n ? (l = {
      blockedOn: t,
      domEventName: a,
      eventSystemFlags: e,
      nativeEvent: n,
      targetContainers: [u]
    }, t !== null && (t = Wa(t), t !== null && od(t)), l) : (l.eventSystemFlags |= e, t = l.targetContainers, u !== null && t.indexOf(u) === -1 && t.push(u), l);
  }
  function ly(l, t, a, e, u) {
    switch (t) {
      case "focusin":
        return Aa = Eu(
          Aa,
          l,
          t,
          a,
          e,
          u
        ), !0;
      case "dragenter":
        return xa = Eu(
          xa,
          l,
          t,
          a,
          e,
          u
        ), !0;
      case "mouseover":
        return _a = Eu(
          _a,
          l,
          t,
          a,
          e,
          u
        ), !0;
      case "pointerover":
        var n = u.pointerId;
        return Tu.set(
          n,
          Eu(
            Tu.get(n) || null,
            l,
            t,
            a,
            e,
            u
          )
        ), !0;
      case "gotpointercapture":
        return n = u.pointerId, zu.set(
          n,
          Eu(
            zu.get(n) || null,
            l,
            t,
            a,
            e,
            u
          )
        ), !0;
    }
    return !1;
  }
  function yd(l) {
    var t = $a(l.target);
    if (t !== null) {
      var a = G(t);
      if (a !== null) {
        if (t = a.tag, t === 13) {
          if (t = nl(a), t !== null) {
            l.blockedOn = t, Nf(l.priority, function() {
              dd(a);
            });
            return;
          }
        } else if (t === 31) {
          if (t = cl(a), t !== null) {
            l.blockedOn = t, Nf(l.priority, function() {
              dd(a);
            });
            return;
          }
        } else if (t === 3 && a.stateNode.current.memoizedState.isDehydrated) {
          l.blockedOn = a.tag === 3 ? a.stateNode.containerInfo : null;
          return;
        }
      }
    }
    l.blockedOn = null;
  }
  function Xn(l) {
    if (l.blockedOn !== null) return !1;
    for (var t = l.targetContainers; 0 < t.length; ) {
      var a = uf(l.nativeEvent);
      if (a === null) {
        a = l.nativeEvent;
        var e = new a.constructor(
          a.type,
          a
        );
        ni = e, a.target.dispatchEvent(e), ni = null;
      } else
        return t = Wa(a), t !== null && od(t), l.blockedOn = a, !1;
      t.shift();
    }
    return !0;
  }
  function vd(l, t, a) {
    Xn(l) && a.delete(t);
  }
  function ty() {
    cf = !1, Aa !== null && Xn(Aa) && (Aa = null), xa !== null && Xn(xa) && (xa = null), _a !== null && Xn(_a) && (_a = null), Tu.forEach(vd), zu.forEach(vd);
  }
  function Qn(l, t) {
    l.blockedOn === t && (l.blockedOn = null, cf || (cf = !0, g.unstable_scheduleCallback(
      g.unstable_NormalPriority,
      ty
    )));
  }
  var Ln = null;
  function hd(l) {
    Ln !== l && (Ln = l, g.unstable_scheduleCallback(
      g.unstable_NormalPriority,
      function() {
        Ln === l && (Ln = null);
        for (var t = 0; t < l.length; t += 3) {
          var a = l[t], e = l[t + 1], u = l[t + 2];
          if (typeof e != "function") {
            if (nf(e || a) === null)
              continue;
            break;
          }
          var n = Wa(a);
          n !== null && (l.splice(t, 3), t -= 3, uc(
            n,
            {
              pending: !0,
              data: u,
              method: a.method,
              action: e
            },
            e,
            u
          ));
        }
      }
    ));
  }
  function Ue(l) {
    function t(f) {
      return Qn(f, l);
    }
    Aa !== null && Qn(Aa, l), xa !== null && Qn(xa, l), _a !== null && Qn(_a, l), Tu.forEach(t), zu.forEach(t);
    for (var a = 0; a < Na.length; a++) {
      var e = Na[a];
      e.blockedOn === l && (e.blockedOn = null);
    }
    for (; 0 < Na.length && (a = Na[0], a.blockedOn === null); )
      yd(a), a.blockedOn === null && Na.shift();
    if (a = (l.ownerDocument || l).$$reactFormReplay, a != null)
      for (e = 0; e < a.length; e += 3) {
        var u = a[e], n = a[e + 1], i = u[lt] || null;
        if (typeof n == "function")
          i || hd(a);
        else if (i) {
          var c = null;
          if (n && n.hasAttribute("formAction")) {
            if (u = n, i = n[lt] || null)
              c = i.formAction;
            else if (nf(u) !== null) continue;
          } else c = i.action;
          typeof c == "function" ? a[e + 1] = c : (a.splice(e, 3), e -= 3), hd(a);
        }
      }
  }
  function gd() {
    function l(n) {
      n.canIntercept && n.info === "react-transition" && n.intercept({
        handler: function() {
          return new Promise(function(i) {
            return u = i;
          });
        },
        focusReset: "manual",
        scroll: "manual"
      });
    }
    function t() {
      u !== null && (u(), u = null), e || setTimeout(a, 20);
    }
    function a() {
      if (!e && !navigation.transition) {
        var n = navigation.currentEntry;
        n && n.url != null && navigation.navigate(n.url, {
          state: n.getState(),
          info: "react-transition",
          history: "replace"
        });
      }
    }
    if (typeof navigation == "object") {
      var e = !1, u = null;
      return navigation.addEventListener("navigate", l), navigation.addEventListener("navigatesuccess", t), navigation.addEventListener("navigateerror", t), setTimeout(a, 100), function() {
        e = !0, navigation.removeEventListener("navigate", l), navigation.removeEventListener("navigatesuccess", t), navigation.removeEventListener("navigateerror", t), u !== null && (u(), u = null);
      };
    }
  }
  function ff(l) {
    this._internalRoot = l;
  }
  Zn.prototype.render = ff.prototype.render = function(l) {
    var t = this._internalRoot;
    if (t === null) throw Error(r(409));
    var a = t.current, e = ht();
    fd(a, e, l, t, null, null);
  }, Zn.prototype.unmount = ff.prototype.unmount = function() {
    var l = this._internalRoot;
    if (l !== null) {
      this._internalRoot = null;
      var t = l.containerInfo;
      fd(l.current, 2, null, l, null, null), En(), t[wa] = null;
    }
  };
  function Zn(l) {
    this._internalRoot = l;
  }
  Zn.prototype.unstable_scheduleHydration = function(l) {
    if (l) {
      var t = _f();
      l = { blockedOn: null, target: l, priority: t };
      for (var a = 0; a < Na.length && t !== 0 && t < Na[a].priority; a++) ;
      Na.splice(a, 0, l), a === 0 && yd(l);
    }
  };
  var bd = x.version;
  if (bd !== "19.2.4")
    throw Error(
      r(
        527,
        bd,
        "19.2.4"
      )
    );
  N.findDOMNode = function(l) {
    var t = l._reactInternals;
    if (t === void 0)
      throw typeof l.render == "function" ? Error(r(188)) : (l = Object.keys(l).join(","), Error(r(268, l)));
    return l = E(t), l = l !== null ? w(l) : null, l = l === null ? null : l.stateNode, l;
  };
  var ay = {
    bundleType: 0,
    version: "19.2.4",
    rendererPackageName: "react-dom",
    currentDispatcherRef: b,
    reconcilerVersion: "19.2.4"
  };
  if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u") {
    var Vn = __REACT_DEVTOOLS_GLOBAL_HOOK__;
    if (!Vn.isDisabled && Vn.supportsFiber)
      try {
        Ce = Vn.inject(
          ay
        ), ft = Vn;
      } catch {
      }
  }
  return xu.createRoot = function(l, t) {
    if (!H(l)) throw Error(r(299));
    var a = !1, e = "", u = xo, n = _o, i = No;
    return t != null && (t.unstable_strictMode === !0 && (a = !0), t.identifierPrefix !== void 0 && (e = t.identifierPrefix), t.onUncaughtError !== void 0 && (u = t.onUncaughtError), t.onCaughtError !== void 0 && (n = t.onCaughtError), t.onRecoverableError !== void 0 && (i = t.onRecoverableError)), t = id(
      l,
      1,
      !1,
      null,
      null,
      a,
      e,
      null,
      u,
      n,
      i,
      gd
    ), l[wa] = t.current, Lc(l), new ff(t);
  }, xu.hydrateRoot = function(l, t, a) {
    if (!H(l)) throw Error(r(299));
    var e = !1, u = "", n = xo, i = _o, c = No, f = null;
    return a != null && (a.unstable_strictMode === !0 && (e = !0), a.identifierPrefix !== void 0 && (u = a.identifierPrefix), a.onUncaughtError !== void 0 && (n = a.onUncaughtError), a.onCaughtError !== void 0 && (i = a.onCaughtError), a.onRecoverableError !== void 0 && (c = a.onRecoverableError), a.formState !== void 0 && (f = a.formState)), t = id(
      l,
      1,
      !0,
      t,
      a ?? null,
      e,
      u,
      f,
      n,
      i,
      c,
      gd
    ), t.context = cd(null), a = t.current, e = ht(), e = Fn(e), u = ra(e), u.callback = null, ma(a, u, e), a = e, t.current.lanes = a, Re(t, a), Yt(t), l[wa] = t.current, Lc(l), new Zn(t);
  }, xu.version = "19.2.4", xu;
}
var Md;
function ry() {
  if (Md) return df.exports;
  Md = 1;
  function g() {
    if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function"))
      try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(g);
      } catch (x) {
        console.error(x);
      }
  }
  return g(), df.exports = dy(), df.exports;
}
var my = ry();
const yy = (g) => g.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase(), vy = (g) => g.replace(
  /^([A-Z])|[\s-_]+(\w)/g,
  (x, _, r) => r ? r.toUpperCase() : _.toLowerCase()
), Od = (g) => {
  const x = vy(g);
  return x.charAt(0).toUpperCase() + x.slice(1);
}, Rd = (...g) => g.filter((x, _, r) => !!x && x.trim() !== "" && r.indexOf(x) === _).join(" ").trim(), hy = (g) => {
  for (const x in g)
    if (x.startsWith("aria-") || x === "role" || x === "title")
      return !0;
};
var gy = {
  xmlns: "http://www.w3.org/2000/svg",
  width: 24,
  height: 24,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2,
  strokeLinecap: "round",
  strokeLinejoin: "round"
};
const by = J.forwardRef(
  ({
    color: g = "currentColor",
    size: x = 24,
    strokeWidth: _ = 2,
    absoluteStrokeWidth: r,
    className: H = "",
    children: G,
    iconNode: nl,
    ...cl
  }, U) => J.createElement(
    "svg",
    {
      ref: U,
      ...gy,
      width: x,
      height: x,
      stroke: g,
      strokeWidth: r ? Number(_) * 24 / Number(x) : _,
      className: Rd("lucide", H),
      ...!G && !hy(cl) && { "aria-hidden": "true" },
      ...cl
    },
    [
      ...nl.map(([E, w]) => J.createElement(E, w)),
      ...Array.isArray(G) ? G : [G]
    ]
  )
);
const ea = (g, x) => {
  const _ = J.forwardRef(
    ({ className: r, ...H }, G) => J.createElement(by, {
      ref: G,
      iconNode: x,
      className: Rd(
        `lucide-${yy(Od(g))}`,
        `lucide-${g}`,
        r
      ),
      ...H
    })
  );
  return _.displayName = Od(g), _;
};
const Sy = [["path", { d: "m6 9 6 6 6-6", key: "qrunsl" }]], py = ea("chevron-down", Sy);
const Ty = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["line", { x1: "12", x2: "12", y1: "8", y2: "12", key: "1pkeuh" }],
  ["line", { x1: "12", x2: "12.01", y1: "16", y2: "16", key: "4dfq90" }]
], Ud = ea("circle-alert", Ty);
const zy = [
  ["polyline", { points: "22 12 16 12 14 15 10 15 8 12 2 12", key: "o97t9d" }],
  [
    "path",
    {
      d: "M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z",
      key: "oot6mr"
    }
  ]
], Ey = ea("inbox", zy);
const Ay = [
  [
    "path",
    {
      d: "M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z",
      key: "zw3jo"
    }
  ],
  [
    "path",
    {
      d: "M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12",
      key: "1wduqc"
    }
  ],
  [
    "path",
    {
      d: "M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17",
      key: "kqbvx6"
    }
  ]
], xy = ea("layers", Ay);
const _y = [
  ["path", { d: "M5 12h14", key: "1ays0h" }],
  ["path", { d: "M12 5v14", key: "s699le" }]
], Ny = ea("plus", _y);
const My = [
  [
    "path",
    {
      d: "M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z",
      key: "1c8476"
    }
  ],
  ["path", { d: "M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7", key: "1ydtos" }],
  ["path", { d: "M7 3v4a1 1 0 0 0 1 1h7", key: "t51u73" }]
], Oy = ea("save", My);
const Uy = [
  ["path", { d: "M10 11v6", key: "nco0om" }],
  ["path", { d: "M14 11v6", key: "outv1u" }],
  ["path", { d: "M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6", key: "miytrc" }],
  ["path", { d: "M3 6h18", key: "d0wm0j" }],
  ["path", { d: "M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2", key: "e791ji" }]
], Dy = ea("trash-2", Uy);
const Cy = [
  [
    "path",
    {
      d: "M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1",
      key: "18etb6"
    }
  ],
  ["path", { d: "M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4", key: "xoc0q4" }]
], jy = ea("wallet", Cy);
const Ry = [
  ["path", { d: "M18 6 6 18", key: "1bl5f8" }],
  ["path", { d: "m6 6 12 12", key: "d8bk6v" }]
], Hy = ea("x", Ry);
function By(g) {
  return typeof g == "string" && g.startsWith("/api/");
}
async function _u(g, x = {}) {
  const _ = await fetch(g, {
    credentials: "same-origin",
    ...x
  });
  if (_.status === 401)
    throw window.location.href = "/login", new Error("Sessão expirada. Faça login novamente.");
  if (!_.ok) {
    let H = "Erro inesperado.";
    try {
      H = (await _.json()).error || H;
    } catch {
      H = _.statusText || H;
    }
    const G = new Error(H);
    throw G.status = _.status, G;
  }
  if (_.status === 204) return null;
  const r = _.headers.get("content-type") || "";
  if (By(g) && !r.includes("application/json"))
    throw new Error("API indisponivel ou desatualizada. Reinicie o servidor.");
  return _.json();
}
function qy() {
  return _u("/api/auth/status");
}
function Yy() {
  return _u("/api/topicos");
}
function Gy(g) {
  return _u("/api/topicos", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(g)
  });
}
function Xy(g, x) {
  return _u(`/api/topicos/${encodeURIComponent(g)}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(x)
  });
}
function Qy(g) {
  return _u(`/api/topicos/${encodeURIComponent(g)}`, {
    method: "DELETE"
  });
}
function Ly(g) {
  if (typeof g != "function") return () => {
  };
  const x = () => document.body.classList.contains("theme-dark"), _ = () => g(x());
  _();
  const r = new MutationObserver(() => {
    _();
  });
  return r.observe(document.body, {
    attributes: !0,
    attributeFilter: ["class"]
  }), () => r.disconnect();
}
function Zy({
  canManageConfig: g,
  isEditMode: x,
  onToggleEditMode: _,
  onOpenCreateModal: r,
  isDark: H
}) {
  const G = H ? "text-slate-300" : "text-slate-600", nl = H ? "text-slate-100" : "text-slate-900", cl = H ? "border-slate-700/60 bg-slate-900/80 text-slate-200" : "border-slate-300/80 bg-white/90 text-slate-700", U = x ? "bg-indigo-500" : H ? "bg-slate-700" : "bg-slate-300";
  return /* @__PURE__ */ A.jsxs("div", { className: "space-y-5", children: [
    /* @__PURE__ */ A.jsxs("div", { className: "space-y-2", children: [
      /* @__PURE__ */ A.jsx("h3", { className: `text-4xl font-extrabold tracking-tight md:text-5xl ${nl}`, children: "Configurações" }),
      /* @__PURE__ */ A.jsx("p", { className: `max-w-4xl text-sm leading-relaxed md:text-[1.02rem] ${G}`, children: "Faça a gestão dos tópicos, orçamentos e permissões de lançamento. O total é recalculado em tempo real conforme o filtro e os campos editados." })
    ] }),
    /* @__PURE__ */ A.jsx("div", { className: "flex justify-start md:justify-end", children: /* @__PURE__ */ A.jsxs("div", { className: "grid w-full max-w-[470px] grid-cols-1 gap-3 sm:grid-cols-2", children: [
      g && x ? /* @__PURE__ */ A.jsxs(
        "button",
        {
          type: "button",
          onClick: r,
          className: "group inline-flex h-14 items-center justify-center gap-2 rounded-2xl border border-indigo-300/25 bg-gradient-to-r from-indigo-600 to-blue-600 px-5 text-[1.02rem] font-semibold text-white shadow-[0_0_24px_rgba(99,102,241,0.35)] transition-all hover:from-indigo-500 hover:to-blue-500 hover:shadow-[0_0_30px_rgba(99,102,241,0.5)]",
          children: [
            /* @__PURE__ */ A.jsx(Ny, { size: 20, className: "transition-transform duration-300 group-hover:rotate-90" }),
            "Acrescentar Tópico"
          ]
        }
      ) : /* @__PURE__ */ A.jsx("div", { className: "hidden sm:block", "aria-hidden": "true" }),
      /* @__PURE__ */ A.jsxs(
        "div",
        {
          className: `inline-flex h-14 items-center justify-between rounded-2xl border px-5 shadow-lg backdrop-blur ${cl}`,
          children: [
            /* @__PURE__ */ A.jsx("span", { className: `text-[1.02rem] font-semibold ${x ? "text-indigo-400" : G}`, children: "Modo Edição" }),
            /* @__PURE__ */ A.jsx(
              "button",
              {
                type: "button",
                role: "switch",
                "aria-checked": x,
                onClick: _,
                className: `relative inline-flex h-8 w-14 flex-shrink-0 rounded-full border-2 border-transparent transition-colors duration-300 ${U}`,
                children: /* @__PURE__ */ A.jsx(
                  "span",
                  {
                    className: `pointer-events-none inline-block h-7 w-7 transform rounded-full bg-white shadow transition duration-300 ${x ? "translate-x-6" : "translate-x-0"}`
                  }
                )
              }
            )
          ]
        }
      )
    ] }) })
  ] });
}
function Vy({ filterGroup: g, groups: x, onChangeFilter: _, isDark: r }) {
  return /* @__PURE__ */ A.jsxs(
    "div",
    {
      className: `col-span-1 flex min-h-[142px] flex-col justify-center rounded-2xl border p-5 shadow-xl backdrop-blur-xl md:col-span-2 md:p-6 ${r ? "border-slate-800/65 bg-slate-900/45" : "border-slate-200/90 bg-white/90"}`,
      children: [
        /* @__PURE__ */ A.jsxs(
          "div",
          {
            className: `mb-3 inline-flex w-fit items-center justify-start gap-2 text-xs font-bold uppercase tracking-[0.08em] ${r ? "text-slate-400" : "text-slate-500"}`,
            children: [
              /* @__PURE__ */ A.jsx(xy, { size: 14 }),
              "Filtrar por Macro-Topico"
            ]
          }
        ),
        /* @__PURE__ */ A.jsxs("div", { className: "relative w-full max-w-[360px]", children: [
          /* @__PURE__ */ A.jsx(
            "select",
            {
              value: g,
              onChange: (H) => _(H.target.value),
              className: `h-12 w-full appearance-none rounded-xl border px-4 py-3 text-[1.04rem] font-semibold leading-none outline-none transition-all ${r ? "border-slate-700/60 bg-slate-950/50 text-slate-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/40" : "border-slate-300 bg-white text-slate-900 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/25"}`,
              children: x.map((H) => /* @__PURE__ */ A.jsx("option", { value: H.value, children: H.label }, H.value))
            }
          ),
          /* @__PURE__ */ A.jsx(
            py,
            {
              size: 16,
              className: `pointer-events-none absolute right-4 top-1/2 -translate-y-1/2 ${r ? "text-slate-500" : "text-slate-400"}`
            }
          )
        ] })
      ]
    }
  );
}
function Ky({ totalBudget: g, formatCurrency: x, filterLabel: _, isDark: r }) {
  return /* @__PURE__ */ A.jsxs(
    "div",
    {
      className: `group relative col-span-1 flex min-h-[142px] flex-col justify-center overflow-hidden rounded-2xl border p-6 shadow-xl backdrop-blur-xl ${r ? "border-slate-800/60 bg-gradient-to-br from-slate-900/85 to-slate-900/45" : "border-slate-200 bg-gradient-to-br from-white to-slate-100"}`,
      children: [
        /* @__PURE__ */ A.jsx("div", { className: "absolute -right-10 -top-10 h-32 w-32 rounded-full bg-indigo-500/10 blur-3xl transition-all group-hover:bg-indigo-500/20" }),
        /* @__PURE__ */ A.jsxs(
          "div",
          {
            className: `relative z-10 mb-2 inline-flex w-fit items-center justify-start gap-2 text-xs font-bold uppercase tracking-[0.08em] ${r ? "text-slate-400" : "text-slate-500"}`,
            children: [
              /* @__PURE__ */ A.jsx(jy, { size: 14, className: "text-indigo-400" }),
              "Orcamento Total (",
              _,
              ")"
            ]
          }
        ),
        /* @__PURE__ */ A.jsx(
          "div",
          {
            className: `relative z-10 text-left text-[2.45rem] font-extrabold leading-none ${r ? "text-indigo-200" : "text-indigo-900"}`,
            children: x(g)
          }
        )
      ]
    }
  );
}
function Jy({ filterLabel: g, isDark: x }) {
  return /* @__PURE__ */ A.jsx("tr", { children: /* @__PURE__ */ A.jsx("td", { colSpan: 6, className: "px-6 py-16 text-center", children: /* @__PURE__ */ A.jsxs("div", { className: `flex flex-col items-center justify-center ${x ? "text-slate-500" : "text-slate-400"}`, children: [
    /* @__PURE__ */ A.jsx(Ey, { size: 48, className: "mb-4 opacity-50" }),
    /* @__PURE__ */ A.jsx("p", { className: `text-lg font-semibold ${x ? "text-slate-200" : "text-slate-700"}`, children: "Nenhum tópico encontrado" }),
    /* @__PURE__ */ A.jsxs("p", { className: "mt-1 text-sm", children: [
      'Não existem tópicos para o filtro "',
      g,
      '".'
    ] })
  ] }) }) });
}
function Dd({ checked: g, disabled: x, onClick: _, tone: r = "indigo", isDark: H }) {
  const G = r === "emerald" ? "bg-emerald-500" : "bg-indigo-500", nl = H ? "bg-slate-700" : "bg-slate-300";
  return /* @__PURE__ */ A.jsx(
    "button",
    {
      type: "button",
      disabled: x,
      onClick: _,
      className: `relative inline-flex h-6 w-11 flex-shrink-0 rounded-full border-2 border-transparent transition-colors ${g ? G : nl} ${x ? "cursor-default opacity-60" : "cursor-pointer"}`,
      children: /* @__PURE__ */ A.jsx(
        "span",
        {
          className: `pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow transition duration-200 ${g ? "translate-x-5" : "translate-x-0"}`
        }
      )
    }
  );
}
function wy({
  topic: g,
  draft: x,
  isEditMode: _,
  canManageConfig: r,
  isDark: H,
  isSaving: G,
  isDeleting: nl,
  onFieldChange: cl,
  onToggleField: U,
  onSave: E,
  onDelete: w,
  getGroupLabel: j
}) {
  const P = r && _, rl = P ? H ? "text-slate-200 border border-slate-700/40 hover:border-slate-600 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500/60 bg-slate-950/40" : "text-slate-900 border border-slate-300 hover:border-slate-400 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500/40 bg-white" : H ? "text-slate-300 border border-transparent bg-transparent cursor-default" : "text-slate-700 border border-transparent bg-transparent cursor-default";
  return /* @__PURE__ */ A.jsxs("tr", { className: `group/row transition-colors ${H ? "hover:bg-slate-800/30" : "hover:bg-slate-100/70"}`, children: [
    /* @__PURE__ */ A.jsx("td", { className: "px-6 py-4", children: /* @__PURE__ */ A.jsx(
      "input",
      {
        type: "text",
        value: x.nome,
        readOnly: !P,
        onChange: (_l) => cl(g.id, "nome", _l.target.value),
        className: `w-full rounded-md px-3 py-1.5 text-sm font-semibold outline-none transition-all ${rl}`
      }
    ) }),
    /* @__PURE__ */ A.jsx("td", { className: "px-6 py-4", children: /* @__PURE__ */ A.jsx(
      "span",
      {
        className: `whitespace-nowrap rounded-full border px-3 py-1.5 text-xs font-semibold ${H ? "border-slate-700/50 bg-slate-800/60 text-slate-300" : "border-slate-300 bg-slate-100 text-slate-700"}`,
        children: j(g.grupo)
      }
    ) }),
    /* @__PURE__ */ A.jsx("td", { className: "px-6 py-4 text-right", children: /* @__PURE__ */ A.jsxs("div", { className: "flex items-center justify-end gap-2", children: [
      /* @__PURE__ */ A.jsx("span", { className: `text-xs font-semibold ${H ? "text-slate-500" : "text-slate-400"}`, children: "R$" }),
      /* @__PURE__ */ A.jsx(
        "input",
        {
          type: "number",
          min: "0",
          step: "0.01",
          value: x.orcamentoProgramaBRL,
          readOnly: !P,
          onChange: (_l) => cl(g.id, "orcamentoProgramaBRL", _l.target.value),
          className: `w-32 rounded-md px-3 py-1.5 text-right font-mono text-sm outline-none transition-all ${rl}`
        }
      )
    ] }) }),
    /* @__PURE__ */ A.jsx("td", { className: "px-6 py-4 text-center", children: /* @__PURE__ */ A.jsx("div", { className: "flex justify-center", children: /* @__PURE__ */ A.jsx(
      Dd,
      {
        checked: !!x.incluirNoResumo,
        disabled: !P,
        tone: "indigo",
        isDark: H,
        onClick: () => U(g.id, "incluirNoResumo")
      }
    ) }) }),
    /* @__PURE__ */ A.jsx("td", { className: "px-6 py-4 text-center", children: /* @__PURE__ */ A.jsx("div", { className: "flex justify-center", children: /* @__PURE__ */ A.jsx(
      Dd,
      {
        checked: !!x.permitirLancamento,
        disabled: !P,
        tone: "emerald",
        isDark: H,
        onClick: () => U(g.id, "permitirLancamento")
      }
    ) }) }),
    /* @__PURE__ */ A.jsx("td", { className: "px-6 py-4 text-right", children: P ? /* @__PURE__ */ A.jsxs("div", { className: "flex items-center justify-end gap-2", children: [
      /* @__PURE__ */ A.jsxs(
        "button",
        {
          type: "button",
          disabled: G,
          onClick: () => E(g.id),
          className: "inline-flex items-center gap-1.5 rounded-lg bg-indigo-600 px-3 py-1.5 text-sm font-semibold text-white transition-colors hover:bg-indigo-500 disabled:cursor-not-allowed disabled:opacity-60",
          title: "Salvar alterações",
          children: [
            /* @__PURE__ */ A.jsx(Oy, { size: 16 }),
            /* @__PURE__ */ A.jsx("span", { children: G ? "Salvando..." : "Salvar" })
          ]
        }
      ),
      /* @__PURE__ */ A.jsx(
        "button",
        {
          type: "button",
          disabled: nl,
          onClick: () => w(g.id),
          className: `inline-flex h-8 w-8 items-center justify-center rounded-lg transition-colors ${H ? "text-slate-400 hover:bg-rose-500/15 hover:text-rose-400" : "text-slate-500 hover:bg-rose-100 hover:text-rose-600"} disabled:cursor-not-allowed disabled:opacity-50`,
          title: "Remover tópico",
          children: /* @__PURE__ */ A.jsx(Dy, { size: 18 })
        }
      )
    ] }) : /* @__PURE__ */ A.jsx("span", { className: `text-xs font-semibold ${H ? "text-slate-500" : "text-slate-400"}`, children: r ? "Ative o modo edição" : "Somente leitura" }) })
  ] });
}
function $y({
  filteredTopics: g,
  drafts: x,
  filterLabel: _,
  isEditMode: r,
  canManageConfig: H,
  isDark: G,
  savingIds: nl,
  deletingIds: cl,
  getGroupLabel: U,
  onFieldChange: E,
  onToggleField: w,
  onSaveTopic: j,
  onDeleteTopic: P
}) {
  return /* @__PURE__ */ A.jsx(
    "div",
    {
      className: `overflow-hidden rounded-2xl border shadow-2xl ${G ? "border-slate-800/60 bg-slate-900/45" : "border-slate-200 bg-white/95"}`,
      children: /* @__PURE__ */ A.jsx("div", { className: "overflow-x-auto", children: /* @__PURE__ */ A.jsxs("table", { className: "w-full border-collapse", children: [
        /* @__PURE__ */ A.jsx("thead", { children: /* @__PURE__ */ A.jsxs(
          "tr",
          {
            className: `border-b text-left text-xs font-bold uppercase tracking-[0.14em] ${G ? "border-slate-800/60 bg-slate-950/55 text-slate-400" : "border-slate-200 bg-slate-100 text-slate-500"}`,
            children: [
              /* @__PURE__ */ A.jsx("th", { className: "whitespace-nowrap px-6 py-5", children: "Tópico" }),
              /* @__PURE__ */ A.jsx("th", { className: "whitespace-nowrap px-6 py-5", children: "Grupo" }),
              /* @__PURE__ */ A.jsx("th", { className: "whitespace-nowrap px-6 py-5 text-right", children: "Orçamento" }),
              /* @__PURE__ */ A.jsx("th", { className: "whitespace-nowrap px-6 py-5 text-center", children: "No Resumo" }),
              /* @__PURE__ */ A.jsx("th", { className: "whitespace-nowrap px-6 py-5 text-center", children: "Lançamento" }),
              /* @__PURE__ */ A.jsx("th", { className: "whitespace-nowrap px-6 py-5 text-right", children: "Ações" })
            ]
          }
        ) }),
        /* @__PURE__ */ A.jsx("tbody", { className: G ? "divide-y divide-slate-800/55" : "divide-y divide-slate-200", children: g.length === 0 ? /* @__PURE__ */ A.jsx(Jy, { filterLabel: _, isDark: G }) : g.map((rl) => /* @__PURE__ */ A.jsx(
          wy,
          {
            topic: rl,
            draft: x[rl.id],
            isEditMode: r,
            canManageConfig: H,
            isDark: G,
            isSaving: nl.has(rl.id),
            isDeleting: cl.has(rl.id),
            getGroupLabel: U,
            onFieldChange: E,
            onToggleField: w,
            onSave: j,
            onDelete: P
          },
          rl.id
        )) })
      ] }) })
    }
  );
}
const De = "Todos", Wy = ["TEAM HIRES", "COMMUNICATIONS & PUBLICATIONS", "THIRD PARTY SERVICES"], ky = {
  "TEAM HIRES": "Contratações da Equipe",
  "COMMUNICATIONS & PUBLICATIONS": "Comunicação e Publicações",
  "THIRD PARTY SERVICES": "Serviços de Terceiros"
};
function vf(g) {
  return ky[g] || g || "Sem grupo";
}
function Fy(g) {
  return {
    id: String(g?.id ?? ""),
    nome: String(g?.nome ?? ""),
    grupo: String(g?.grupo ?? ""),
    orcamentoProgramaBRL: Number(g?.orcamentoProgramaBRL ?? 0),
    incluirNoResumo: !!g?.incluirNoResumo,
    permitirLancamento: !!g?.permitirLancamento,
    permitirLancamentoEfetivo: !!g?.permitirLancamentoEfetivo
  };
}
function Iy(g) {
  const x = {};
  for (const _ of g)
    x[_.id] = {
      nome: _.nome,
      orcamentoProgramaBRL: String(Number(_.orcamentoProgramaBRL ?? 0)),
      incluirNoResumo: !!_.incluirNoResumo,
      permitirLancamento: !!_.permitirLancamento
    };
  return x;
}
function hf(g) {
  const x = Number(String(g ?? "").replace(",", "."));
  return Number.isFinite(x) ? x : NaN;
}
function Py(g) {
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL"
  }).format(Number(g ?? 0));
}
function Cd(g, x) {
  const _ = new Set(g);
  return _.add(x), _;
}
function jd(g, x) {
  const _ = new Set(g);
  return _.delete(x), _;
}
function lv({ onError: g }) {
  const [x, _] = J.useState(() => document.body.classList.contains("theme-dark")), [r, H] = J.useState(!0), [G, nl] = J.useState(""), [cl, U] = J.useState(""), [E, w] = J.useState(null), [j, P] = J.useState([]), [rl, _l] = J.useState({}), [Sl, gt] = J.useState(De), [zl, Ut] = J.useState(!1), [Yl, Il] = J.useState(/* @__PURE__ */ new Set()), [bt, Ll] = J.useState(/* @__PURE__ */ new Set()), [$, Zl] = J.useState(!1), [St, Dt] = J.useState(!1), [Al, Vl] = J.useState({
    nome: "",
    grupo: "COMMUNICATIONS & PUBLICATIONS",
    orcamentoProgramaBRL: "0",
    incluirNoResumo: !0,
    permitirLancamento: !0
  }), Cl = !!E?.permissions?.canManageConfig, kl = J.useCallback(() => {
    window.dispatchEvent(new CustomEvent("config:topics-changed"));
  }, []), ml = J.useCallback(
    (M) => {
      const X = String(M || "Falha ao processar requisição.");
      nl(X), typeof g == "function" && g(X);
    },
    [g]
  ), b = J.useCallback(async () => {
    const M = await Yy(), X = Array.isArray(M) ? M.map(Fy) : [];
    return P(X), _l(Iy(X)), X;
  }, []), N = J.useCallback(async () => {
    const M = await qy();
    return M?.authenticated ? (w(M), M) : (window.location.href = "/login", null);
  }, []);
  J.useEffect(() => {
    let M = !0;
    return (async () => {
      try {
        H(!0), await Promise.all([N(), b()]);
      } catch (X) {
        if (!M) return;
        ml(X?.message || "Falha ao carregar dados da configuracao.");
      } finally {
        M && H(!1);
      }
    })(), () => {
      M = !1;
    };
  }, [N, b, ml]), J.useEffect(() => Ly(_), []), J.useEffect(() => {
    Cl || (Ut(!1), Dt(!1));
  }, [Cl]), J.useEffect(() => {
    if (!G) return () => {
    };
    const M = setTimeout(() => nl(""), 3600);
    return () => clearTimeout(M);
  }, [G]), J.useEffect(() => {
    if (!cl) return () => {
    };
    const M = setTimeout(() => U(""), 2400);
    return () => clearTimeout(M);
  }, [cl]);
  const q = J.useMemo(() => {
    const M = new Map(Wy.map((X) => [X, vf(X)]));
    for (const X of j)
      X.grupo && M.set(X.grupo, vf(X.grupo));
    return [
      { value: De, label: "Todos os Macro-Tópicos" },
      ...[...M.entries()].sort((X, sl) => X[1].localeCompare(sl[1])).map(([X, sl]) => ({ value: X, label: sl }))
    ];
  }, [j]), tl = J.useMemo(() => Sl === De ? j : j.filter((M) => M.grupo === Sl), [j, Sl]), fl = J.useMemo(() => tl.reduce((M, X) => {
    const sl = rl[X.id], Gl = Number(X.orcamentoProgramaBRL ?? 0), yl = sl ? hf(sl.orcamentoProgramaBRL) : Gl;
    return M + (Number.isFinite(yl) ? yl : Gl);
  }, 0), [tl, rl]), o = q.find((M) => M.value === Sl)?.label || "Todos os Macro-Tópicos", z = J.useCallback((M, X, sl) => {
    _l((Gl) => ({
      ...Gl,
      [M]: {
        ...Gl[M] || {},
        [X]: sl
      }
    }));
  }, []), O = J.useCallback((M, X) => {
    _l((sl) => ({
      ...sl,
      [M]: {
        ...sl[M] || {},
        [X]: !sl?.[M]?.[X]
      }
    }));
  }, []), C = J.useCallback(
    async (M) => {
      if (!Cl || !zl) return;
      const X = rl[M];
      if (!X) return;
      const sl = String(X.nome ?? "").trim();
      if (!sl) {
        ml("Nome do tópico é obrigatório.");
        return;
      }
      const Gl = hf(X.orcamentoProgramaBRL);
      if (!Number.isFinite(Gl) || Gl < 0) {
        ml("Orçamento inválido.");
        return;
      }
      Il((yl) => Cd(yl, M));
      try {
        await Xy(M, {
          nome: sl,
          orcamentoProgramaBRL: Gl,
          incluirNoResumo: !!X.incluirNoResumo,
          permitirLancamento: !!X.permitirLancamento
        }), await b(), kl(), U("Tópico atualizado com sucesso.");
      } catch (yl) {
        ml(yl?.message || "Falha ao atualizar tópico.");
      } finally {
        Il((yl) => jd(yl, M));
      }
    },
    [Cl, rl, kl, zl, b, ml]
  ), Q = J.useCallback(
    async (M) => {
      if (!Cl || !zl) return;
      const sl = j.find((yl) => yl.id === M)?.nome || M;
      if (window.confirm(`Deseja remover o tópico "${sl}"? Esta ação não pode ser desfeita.`)) {
        Ll((yl) => Cd(yl, M));
        try {
          await Qy(M), await b(), kl(), U("Tópico removido com sucesso.");
        } catch (yl) {
          ml(yl?.message || "Falha ao remover tópico.");
        } finally {
          Ll((yl) => jd(yl, M));
        }
      }
    },
    [Cl, kl, zl, b, ml, j]
  ), K = J.useCallback(() => {
    if (!Cl || !zl) {
      ml("Ative o modo edição para acrescentar tópicos.");
      return;
    }
    const M = Sl !== De ? Sl : j[0]?.grupo || "COMMUNICATIONS & PUBLICATIONS";
    Vl({
      nome: "",
      grupo: M,
      orcamentoProgramaBRL: "0",
      incluirNoResumo: !0,
      permitirLancamento: M !== "TEAM HIRES"
    }), Dt(!0);
  }, [Cl, Sl, zl, ml, j]), al = J.useCallback(() => {
    Dt(!1);
  }, []), Ol = J.useCallback((M, X) => {
    Vl((sl) => M === "grupo" ? {
      ...sl,
      grupo: X,
      permitirLancamento: X !== "TEAM HIRES" ? sl.permitirLancamento : !1
    } : {
      ...sl,
      [M]: X
    });
  }, []), xl = J.useCallback(
    async (M) => {
      if (M.preventDefault(), !Cl || !zl) {
        ml("Ative o modo edição para salvar tópicos.");
        return;
      }
      const X = String(Al.nome ?? "").trim(), sl = String(Al.grupo ?? "").trim(), Gl = hf(Al.orcamentoProgramaBRL);
      if (!X) {
        ml("Nome do tópico é obrigatório.");
        return;
      }
      if (!sl) {
        ml("Grupo do tópico é obrigatório.");
        return;
      }
      if (!Number.isFinite(Gl) || Gl < 0) {
        ml("Orçamento inválido.");
        return;
      }
      Zl(!0);
      try {
        const yl = await Gy({
          nome: X,
          grupo: sl,
          orcamentoProgramaBRL: Gl,
          incluirNoResumo: !!Al.incluirNoResumo,
          permitirLancamento: !!Al.permitirLancamento
        });
        gt(yl?.grupo || sl), Dt(!1), await b(), kl(), U("Tópico criado com sucesso.");
      } catch (yl) {
        ml(yl?.message || "Falha ao criar tópico.");
      } finally {
        Zl(!1);
      }
    },
    [Cl, kl, zl, b, Al, ml]
  );
  return r ? /* @__PURE__ */ A.jsx("div", { className: `config-react-scope rounded-2xl border p-6 ${x ? "border-slate-800/60 bg-slate-900/45 text-slate-300" : "border-slate-200 bg-white text-slate-700"}`, children: "Carregando configurações..." }) : /* @__PURE__ */ A.jsxs("div", { className: `config-react-scope space-y-6 ${x ? "text-slate-200" : "text-slate-900"}`, children: [
    /* @__PURE__ */ A.jsx(
      Zy,
      {
        canManageConfig: Cl,
        isEditMode: zl,
        onToggleEditMode: () => Ut((M) => !M),
        onOpenCreateModal: K,
        isDark: x
      }
    ),
    G ? /* @__PURE__ */ A.jsxs(
      "div",
      {
        className: `flex items-start gap-2 rounded-xl border px-4 py-3 text-sm ${x ? "border-rose-500/40 bg-rose-500/10 text-rose-200" : "border-rose-300 bg-rose-50 text-rose-700"}`,
        children: [
          /* @__PURE__ */ A.jsx(Ud, { size: 16, className: "mt-0.5 shrink-0" }),
          /* @__PURE__ */ A.jsx("span", { children: G })
        ]
      }
    ) : null,
    cl ? /* @__PURE__ */ A.jsx(
      "div",
      {
        className: `rounded-xl border px-4 py-3 text-sm ${x ? "border-emerald-400/40 bg-emerald-500/10 text-emerald-200" : "border-emerald-300 bg-emerald-50 text-emerald-700"}`,
        children: cl
      }
    ) : null,
    St ? /* @__PURE__ */ A.jsxs(
      "div",
      {
        className: `rounded-2xl border p-5 shadow-xl ${x ? "border-slate-800/60 bg-slate-900/45" : "border-slate-200 bg-white"}`,
        children: [
          /* @__PURE__ */ A.jsxs("div", { className: "mb-4 flex items-center justify-between", children: [
            /* @__PURE__ */ A.jsx("h4", { className: "text-lg font-bold", children: "Novo tópico" }),
            /* @__PURE__ */ A.jsx(
              "button",
              {
                type: "button",
                onClick: al,
                className: `inline-flex h-8 w-8 items-center justify-center rounded-lg transition-colors ${x ? "text-slate-400 hover:bg-slate-800 hover:text-slate-200" : "text-slate-500 hover:bg-slate-100 hover:text-slate-800"}`,
                children: /* @__PURE__ */ A.jsx(Hy, { size: 16 })
              }
            )
          ] }),
          /* @__PURE__ */ A.jsxs("form", { className: "grid gap-3 md:grid-cols-2", onSubmit: xl, children: [
            /* @__PURE__ */ A.jsxs("label", { className: "flex flex-col gap-1 text-sm font-semibold", children: [
              "Nome do tópico",
              /* @__PURE__ */ A.jsx(
                "input",
                {
                  type: "text",
                  value: Al.nome,
                  onChange: (M) => Ol("nome", M.target.value),
                  className: `rounded-lg border px-3 py-2 outline-none transition-all ${x ? "border-slate-700 bg-slate-950/45 text-slate-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500/60" : "border-slate-300 bg-white text-slate-900 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500/40"}`,
                  required: !0
                }
              )
            ] }),
            /* @__PURE__ */ A.jsxs("label", { className: "flex flex-col gap-1 text-sm font-semibold", children: [
              "Grupo",
              /* @__PURE__ */ A.jsx(
                "select",
                {
                  value: Al.grupo,
                  onChange: (M) => Ol("grupo", M.target.value),
                  className: `rounded-lg border px-3 py-2 outline-none transition-all ${x ? "border-slate-700 bg-slate-950/45 text-slate-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500/60" : "border-slate-300 bg-white text-slate-900 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500/40"}`,
                  children: q.filter((M) => M.value !== De).map((M) => /* @__PURE__ */ A.jsx("option", { value: M.value, children: M.label }, M.value))
                }
              )
            ] }),
            /* @__PURE__ */ A.jsxs("label", { className: "flex flex-col gap-1 text-sm font-semibold", children: [
              "Orçamento (BRL)",
              /* @__PURE__ */ A.jsx(
                "input",
                {
                  type: "number",
                  min: "0",
                  step: "0.01",
                  value: Al.orcamentoProgramaBRL,
                  onChange: (M) => Ol("orcamentoProgramaBRL", M.target.value),
                  className: `rounded-lg border px-3 py-2 outline-none transition-all ${x ? "border-slate-700 bg-slate-950/45 text-slate-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500/60" : "border-slate-300 bg-white text-slate-900 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500/40"}`
                }
              )
            ] }),
            /* @__PURE__ */ A.jsxs("div", { className: "grid grid-cols-1 gap-2 sm:grid-cols-2", children: [
              /* @__PURE__ */ A.jsxs("label", { className: "inline-flex items-center gap-2 text-sm font-semibold", children: [
                /* @__PURE__ */ A.jsx(
                  "input",
                  {
                    type: "checkbox",
                    checked: Al.incluirNoResumo,
                    onChange: (M) => Ol("incluirNoResumo", M.target.checked)
                  }
                ),
                "Incluir no resumo"
              ] }),
              /* @__PURE__ */ A.jsxs("label", { className: "inline-flex items-center gap-2 text-sm font-semibold", children: [
                /* @__PURE__ */ A.jsx(
                  "input",
                  {
                    type: "checkbox",
                    checked: Al.permitirLancamento,
                    onChange: (M) => Ol("permitirLancamento", M.target.checked),
                    disabled: Al.grupo === "TEAM HIRES"
                  }
                ),
                "Lançamento ativo"
              ] })
            ] }),
            /* @__PURE__ */ A.jsxs("div", { className: "col-span-full flex justify-end gap-2 pt-1", children: [
              /* @__PURE__ */ A.jsx(
                "button",
                {
                  type: "button",
                  onClick: al,
                  className: `rounded-lg border px-4 py-2 text-sm font-semibold ${x ? "border-slate-700 text-slate-300 hover:bg-slate-800" : "border-slate-300 text-slate-700 hover:bg-slate-100"}`,
                  children: "Cancelar"
                }
              ),
              /* @__PURE__ */ A.jsx(
                "button",
                {
                  type: "submit",
                  disabled: $,
                  className: "rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white hover:bg-indigo-500 disabled:cursor-not-allowed disabled:opacity-60",
                  children: $ ? "Salvando..." : "Criar tópico"
                }
              )
            ] })
          ] })
        ]
      }
    ) : null,
    /* @__PURE__ */ A.jsxs("div", { className: "grid grid-cols-1 gap-4 md:grid-cols-3", children: [
      /* @__PURE__ */ A.jsx(
        Vy,
        {
          filterGroup: Sl,
          groups: q,
          onChangeFilter: gt,
          isDark: x
        }
      ),
      /* @__PURE__ */ A.jsx(
        Ky,
        {
          totalBudget: fl,
          formatCurrency: Py,
          filterLabel: Sl === De ? "Geral" : o,
          isDark: x
        }
      )
    ] }),
    /* @__PURE__ */ A.jsx(
      $y,
      {
        filteredTopics: tl,
        drafts: rl,
        filterLabel: o,
        isEditMode: zl,
        canManageConfig: Cl,
        isDark: x,
        savingIds: Yl,
        deletingIds: bt,
        getGroupLabel: vf,
        onFieldChange: z,
        onToggleField: O,
        onSaveTopic: C,
        onDeleteTopic: Q
      }
    ),
    /* @__PURE__ */ A.jsxs(
      "div",
      {
        className: `flex flex-col items-center justify-between gap-4 rounded-xl border px-4 py-3 text-xs font-semibold sm:flex-row ${x ? "border-slate-800/60 bg-slate-950/35 text-slate-400" : "border-slate-200 bg-slate-50 text-slate-500"}`,
        children: [
          /* @__PURE__ */ A.jsxs("div", { className: "inline-flex items-center gap-2 rounded-full border border-amber-500/30 bg-amber-500/10 px-3 py-1.5 text-amber-500/90", children: [
            /* @__PURE__ */ A.jsx(Ud, { size: 14 }),
            /* @__PURE__ */ A.jsx("span", { children: "As alterações ficam pendentes até clicar em salvar." })
          ] }),
          /* @__PURE__ */ A.jsxs("span", { children: [
            "A mostrar ",
            tl.length,
            " de ",
            j.length,
            " tópicos"
          ] })
        ]
      }
    )
  ] });
}
function tv(g = {}) {
  const x = g.root ?? document.getElementById("config-react-root");
  if (!x)
    throw new Error("Container da Config React nao encontrado.");
  const _ = my.createRoot(x);
  return _.render(/* @__PURE__ */ A.jsx(lv, { onError: g.onError })), () => {
    _.unmount();
  };
}
export {
  tv as mountConfigApp
};
