const form = document.getElementById("login-form");
const submitBtn = document.getElementById("submit-btn");
const errorMessage = document.getElementById("error-message");
const forceLogin = new URLSearchParams(window.location.search).get("force") === "1";

async function checkSession() {
  if (forceLogin) return;
  try {
    const response = await fetch("/api/auth/status", { credentials: "same-origin" });
    if (!response.ok) return;
    const payload = await response.json();
    if (payload?.authenticated) {
      window.location.replace("/");
    }
  } catch {
    // Keep login screen.
  }
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  errorMessage.textContent = "";
  submitBtn.disabled = true;
  submitBtn.setAttribute("aria-busy", "true");
  submitBtn.dataset.idleLabel = submitBtn.textContent;
  submitBtn.textContent = "Entrando...";

  const payload = {
    username: form.username.value.trim(),
    password: form.password.value,
  };

  try {
    const response = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "same-origin",
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      let message = "Falha ao autenticar.";
      try {
        const body = await response.json();
        message = body?.error || message;
      } catch {
        // Keep default message.
      }
      throw new Error(message);
    }

    window.location.replace("/");
  } catch (error) {
    errorMessage.textContent = error?.message || "Falha ao autenticar.";
  } finally {
    submitBtn.disabled = false;
    submitBtn.setAttribute("aria-busy", "false");
    submitBtn.textContent = submitBtn.dataset.idleLabel || "Entrar";
    delete submitBtn.dataset.idleLabel;
  }
});

checkSession();
