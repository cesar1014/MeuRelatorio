# Site de Relatorio de Gastos (Fundacao Pio XII)

Aplicacao web com:
- frontend em portugues
- API de lancamentos e resumo
- exportacao Excel/PDF/CSV
- topicos travados em `data/topicos.json`
- login obrigatorio antes de acessar o sistema

## Persistencia

O projeto agora suporta 2 modos:

1. `supabase` (recomendado para producao/Vercel)
2. `arquivo_local` (fallback para desenvolvimento local)

Se `SUPABASE_URL` e `SUPABASE_SERVICE_ROLE_KEY` estiverem definidos, usa Supabase.
Se nao estiverem, usa `data/lancamentos.json`.

## Rodar localmente

```bash
npm install
npm run dev
```

Abra `http://localhost:3000`.

## Build da UI React (Configuracoes)

A tela de Configuracoes agora possui um bundle React/Tailwind hibrido (com fallback para o layout legado).

```bash
npm run build:ui
```

Arquivos gerados:
- `public/react/config-app.js`
- `public/react/config-app.css`

## Configurar Supabase

1. Crie um projeto no Supabase.
2. No SQL Editor, execute o arquivo `supabase/site_relatorio_schema.sql`.
3. Copie `.env.example` para `.env` e preencha:

```env
SUPABASE_URL=https://SEU-PROJETO.supabase.co
SUPABASE_SERVICE_ROLE_KEY=SEU_SERVICE_ROLE_KEY
APP_PROJECT_CODE=PEOCON
APP_PROJECT_NAME=Projeto PEOCON
APP_LOGIN_USERS_JSON={"PEOCON":{"password":"SUA_SENHA_FORTE","role":"admin"}}
AUTH_TOKEN_SECRET=COLOQUE_UMA_CHAVE_LONGA_E_ALEATORIA_AQUI
```

4. Execute o bootstrap local -> Supabase:

```bash
npm run supa:bootstrap-project
```

5. Reinicie o servidor.

Obs.: o backend carrega `.env` automaticamente (via `dotenv`).

## Limpeza de payloads suspeitos

Para verificar ou remover registros de teste (ex.: `=2+2`, `HYPERLINK(...)`, texto enorme):

```bash
npm run supa:cleanup-suspicious:check
```

Aplicar limpeza:

```bash
npm run supa:cleanup-suspicious
```

O script limpa local + Supabase e cria backup local em `data/backups/`.

## Configuracao de ambiente

Variaveis principais:

- `SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY`
- `APP_PROJECT_CODE` (default `PEOCON`)
- `APP_PROJECT_NAME` (opcional)
- `SUPABASE_PROJECTS_TABLE` (default `projects`)
- `SUPABASE_LANCAMENTOS_TABLE` (default `lancamentos`)
- `SUPABASE_TOPICOS_TABLE` (default `topicos`)
- `SUPABASE_APP_CONFIG_TABLE` (default `app_config`)
- `SUPABASE_AUTH_SESSIONS_TABLE` (default `auth_sessions`)
- `SUPABASE_AUDIT_LOG_TABLE` (default `audit_log`)
- `APP_LOGIN_USERS_JSON` (RBAC por usuario/projeto)
- `AUTH_TOKEN_SECRET`
- `AUTH_SESSION_TTL_MS`
- `AUTH_MAX_ACTIVE_SESSIONS`
- `LOGIN_RATE_WINDOW_MS`
- `LOGIN_RATE_MAX_ATTEMPTS`
- `LOGIN_RATE_MAX_ATTEMPTS_PER_USER`
- `LOGIN_RATE_GLOBAL_WINDOW_MS`
- `LOGIN_RATE_MAX_ATTEMPTS_GLOBAL`
- `LOGIN_RATE_MAX_TRACKED_KEYS`
- `PDF_EXPORT_MAX_ITEMS`
- `PDF_TEXT_MAX_CHARS`
- `TRUST_PROXY` (default `0`)
- `DATA_DIR`

## Deploy na Vercel

O projeto ja inclui:
- `api/index.js` (adapter serverless)
- `vercel.json` (roteamento API + frontend)

No painel da Vercel:

1. Configure as variaveis acima.
2. Execute o SQL `supabase/site_relatorio_schema.sql` no Supabase.
3. Execute uma vez `npm run supa:bootstrap-project` no ambiente local/CI para carregar dados iniciais.
4. Faca o deploy.

### Seguranca recomendada

- Gire periodicamente a `SUPABASE_SERVICE_ROLE_KEY` no Supabase.
- Nunca commite `.env` no repositorio (apenas `.env.example`).
- Use um `AUTH_TOKEN_SECRET` longo e aleatorio.
- Nao use credenciais padrao; configure usuarios reais em `APP_LOGIN_USERS_JSON`.
- Use papeis de acesso (`admin`, `editor`, `viewer`) para limitar alteracoes.
- O logout revoga a sessao no servidor (token antigo deixa de funcionar).
- Mantenha `TRUST_PROXY=0` por padrao; so altere quando houver proxy reverso confiavel.
- Em desenvolvimento local sem usuarios configurados, o backend gera um usuario temporario `admin` com senha aleatoria (exibida no log).

## Migracao de dados locais (manual)

Se voce ja possui dados em `data/`, o comando abaixo faz upsert para o projeto atual:

```bash
npm run supa:bootstrap-project
```

Ele sincroniza:
- `topicos.json` -> `topicos`
- `lancamentos.json` -> `lancamentos`
- `app-config.json` -> `app_config`
- `auth-sessions.json` -> `auth_sessions`

## Estrutura principal

- `server.js`: API, regras de negocio, exportacoes e integracao Supabase
- `api/index.js`: entrypoint serverless para Vercel
- `public/`: interface web
- `supabase/site_relatorio_schema.sql`: schema SQL completo
- `scripts/bootstrap-supabase-project.js`: bootstrap de dados locais para Supabase
- `scripts/cleanup-suspicious-lancamentos.js`: limpeza de registros suspeitos
- `data/topicos.json`: topicos fixos + orcamento por topico
- `templates/fundacao-template.xlsx`: template oficial do Excel

## Verificacao rapida

`GET /api/health` exige autenticacao:
- usuario `admin`: recebe diagnostico (`projectCode`, `persistencia`, `tabelas`, `trustProxy`)
- demais usuarios autenticados: recebe apenas `{ "ok": true }`
