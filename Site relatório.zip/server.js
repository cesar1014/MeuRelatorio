import "dotenv/config";
import express from "express";
import fs from "node:fs";
import fsp from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";
import { v4 as uuidv4 } from "uuid";
import PDFDocument from "pdfkit";
import XlsxPopulate from "xlsx-populate";
import { createClient } from "@supabase/supabase-js";
import {
  parseFilters,
  filtrarLancamentos,
  montarResumo,
  getPeriodoEfetivo,
} from "./api/reporting-core.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = process.env.PORT || 3000;
const BUNDLE_DATA_DIR = path.join(__dirname, "data");
const DATA_DIR = process.env.DATA_DIR || (process.env.VERCEL ? "/tmp/site-relatorio-data" : BUNDLE_DATA_DIR);
const TOPICOS_FILE = path.join(DATA_DIR, "topicos.json");
const LANCAMENTOS_FILE = path.join(DATA_DIR, "lancamentos.json");
const PENDING_SYNC_FILE = path.join(DATA_DIR, "lancamentos-pending-sync.json");
const APP_CONFIG_FILE = path.join(DATA_DIR, "app-config.json");
const AUTH_SESSION_STORE_FILE = path.join(DATA_DIR, "auth-sessions.json");
const TOPICOS_BUNDLE_FILE = path.join(BUNDLE_DATA_DIR, "topicos.json");
const LANCAMENTOS_BUNDLE_FILE = path.join(BUNDLE_DATA_DIR, "lancamentos.json");
const APP_CONFIG_BUNDLE_FILE = path.join(BUNDLE_DATA_DIR, "app-config.json");
const TEMPLATE_FILE = path.join(__dirname, "templates", "fundacao-template.xlsx");
const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
const SUPABASE_LANCAMENTOS_TABLE = process.env.SUPABASE_LANCAMENTOS_TABLE || "lancamentos";
const SUPABASE_TOPICOS_TABLE = process.env.SUPABASE_TOPICOS_TABLE || "topicos";
const SUPABASE_APP_CONFIG_TABLE = process.env.SUPABASE_APP_CONFIG_TABLE || "app_config";
const SUPABASE_AUTH_SESSIONS_TABLE = process.env.SUPABASE_AUTH_SESSIONS_TABLE || "auth_sessions";
const SUPABASE_AUDIT_LOG_TABLE = process.env.SUPABASE_AUDIT_LOG_TABLE || "audit_log";
const SUPABASE_PROJECTS_TABLE = process.env.SUPABASE_PROJECTS_TABLE || "projects";
const SUPABASE_ENABLED = Boolean(SUPABASE_URL && SUPABASE_SERVICE_ROLE_KEY);
const APP_PROJECT_CODE = normalizeProjectCode(process.env.APP_PROJECT_CODE ?? "PEOCON");
const PENDING_SYNC_INTERVAL_MS = 30_000;
const AUTH_USERS_JSON = String(process.env.APP_LOGIN_USERS_JSON ?? "").trim();
const LEGACY_AUTH_USERNAME = String(process.env.APP_LOGIN_USER ?? "").trim();
const LEGACY_AUTH_PASSWORD = String(process.env.APP_LOGIN_PASSWORD ?? "");
const AUTH_COOKIE_NAME = "peocon_session";
const AUTH_SESSION_TTL_MS = Math.max(60_000, Number(process.env.AUTH_SESSION_TTL_MS ?? 43_200_000));
const AUTH_MAX_ACTIVE_SESSIONS = Math.max(100, Number(process.env.AUTH_MAX_ACTIVE_SESSIONS ?? 2000));
const AUTH_TOKEN_SECRET = String(process.env.AUTH_TOKEN_SECRET ?? "").trim();
const DEV_FALLBACK_AUTH_TOKEN_SECRET = AUTH_TOKEN_SECRET ? "" : crypto.randomBytes(48).toString("hex");
const LOGIN_RATE_WINDOW_MS = Math.max(10_000, Number(process.env.LOGIN_RATE_WINDOW_MS ?? 600_000));
const LOGIN_RATE_MAX_ATTEMPTS = Math.max(1, Number(process.env.LOGIN_RATE_MAX_ATTEMPTS ?? 8));
const LOGIN_RATE_MAX_ATTEMPTS_PER_USER = Math.max(
  1,
  Number(process.env.LOGIN_RATE_MAX_ATTEMPTS_PER_USER ?? LOGIN_RATE_MAX_ATTEMPTS)
);
const LOGIN_RATE_GLOBAL_WINDOW_MS = Math.max(
  10_000,
  Number(process.env.LOGIN_RATE_GLOBAL_WINDOW_MS ?? LOGIN_RATE_WINDOW_MS)
);
const LOGIN_RATE_MAX_ATTEMPTS_GLOBAL = Math.max(
  1,
  Number(process.env.LOGIN_RATE_MAX_ATTEMPTS_GLOBAL ?? 100)
);
const LOGIN_RATE_MAX_TRACKED_KEYS = Math.max(
  1000,
  Number(process.env.LOGIN_RATE_MAX_TRACKED_KEYS ?? 5000)
);
const TRUST_PROXY_RAW = process.env.TRUST_PROXY ?? "0";
const AUTH_ROLE_ADMIN = "admin";
const AUTH_ROLE_EDITOR = "editor";
const AUTH_ROLE_VIEWER = "viewer";
const AUTH_ALLOWED_ROLES = new Set([AUTH_ROLE_ADMIN, AUTH_ROLE_EDITOR, AUTH_ROLE_VIEWER]);
const FIELD_LIMITS = {
  topicoNome: 120,
  topicoGrupo: 80,
  descricao: 500,
  fornecedor: 160,
  responsavel: 160,
};
const PDF_EXPORT_MAX_ITEMS = Math.max(1, Number(process.env.PDF_EXPORT_MAX_ITEMS ?? 1200));
const PDF_TEXT_MAX_CHARS = Math.max(20, Number(process.env.PDF_TEXT_MAX_CHARS ?? 180));
let TEAM_HIRES_UNLOCKED = process.env.TEAM_HIRES_UNLOCKED === "true";
const GROUP_LABELS_PT = {
  "TEAM HIRES": "Contratacoes da Equipe",
  "COMMUNICATIONS & PUBLICATIONS": "Comunicacao e Publicacoes",
  "THIRD PARTY SERVICES": "Servicos de Terceiros",
  "INFRASTRUCTURE & EQUIPMENT": "Infraestrutura e Equipamentos",
};
const TOPIC_LABELS_PT = {
  "Nurse 1": "Enfermeiro 1",
  "Nurse 2": "Enfermeiro 2",
  "Project Coordinator": "Coordenador do Projeto",
  "Administrative Assistant 1": "Assistente Administrativo 1",
  "Administrative Assistant 2": "Assistente Administrativo 2",
  Computer: "Computador",
  "Didactic Material": "Material Didatico",
  Publications: "Publicacoes",
  "Technical Equipment & Infrastructure": "Equipamentos Tecnicos e Infraestrutura",
  "Team Transportation & Meals": "Transporte e Alimentacao da Equipe",
  "Events & Conferences": "Eventos e Conferencias",
  "Just Mine": "Just Mine",
  "External Consultant": "Consultor Externo",
  "Digital Marketing": "Marketing Digital",
};
const TOPICO_ORCAMENTO_BRL_PADRAO = {
  "nurse-1": 268981,
  "nurse-2": 112076,
  "project-coordinator": 75679,
  "administrative-assistant-1": 66243,
  "administrative-assistant-2": 62931,
  computer: 18251,
  "didactic-material": 30000,
  publications: 25000,
  "technical-equipment-infrastructure": 50000,
  "team-transportation-meals": 30000,
  "events-conferences": 60000,
  "just-mine": 100000,
  "external-consultant": 30000,
  "digital-marketing": 20000,
};

const DEFAULT_SECURITY_HEADERS = {
  "X-Content-Type-Options": "nosniff",
  "X-Frame-Options": "DENY",
  "Referrer-Policy": "no-referrer",
  "Permissions-Policy": "camera=(), geolocation=(), microphone=()",
  "Cross-Origin-Opener-Policy": "same-origin",
  "Cross-Origin-Resource-Policy": "same-origin",
};

const CONTENT_SECURITY_POLICY = [
  "default-src 'self'",
  "base-uri 'self'",
  "form-action 'self'",
  "frame-ancestors 'none'",
  "object-src 'none'",
  "script-src 'self'",
  "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
  "font-src 'self' https://fonts.gstatic.com data:",
  "img-src 'self' data:",
  "connect-src 'self' https://fonts.googleapis.com https://fonts.gstatic.com",
].join("; ");

function normalizeProjectCode(value, fallback = "PEOCON") {
  const normalized = String(value ?? "")
    .trim()
    .toUpperCase()
    .replace(/[^A-Z0-9_-]+/g, "_")
    .replace(/^_+|_+$/g, "");
  if (!normalized) return fallback;
  return normalized.slice(0, 64);
}

function parseTrustProxySetting(rawValue) {
  const normalized = String(rawValue ?? "").trim().toLowerCase();
  if (!normalized || normalized === "0" || normalized === "false" || normalized === "off") return false;
  if (normalized === "true" || normalized === "on") return true;

  const numeric = Number(normalized);
  if (Number.isInteger(numeric) && numeric >= 0) return numeric;

  if (["loopback", "linklocal", "uniquelocal"].includes(normalized)) return normalized;
  return normalized;
}

function normalizeAuthRole(roleValue, fallbackRole = AUTH_ROLE_ADMIN) {
  const normalized = String(roleValue ?? "").trim().toLowerCase();
  if (!normalized) return fallbackRole;
  if (AUTH_ALLOWED_ROLES.has(normalized)) return normalized;
  return fallbackRole;
}

function normalizeAuthUser(username, password, role = AUTH_ROLE_ADMIN) {
  const normalizedUsername = String(username ?? "").trim();
  const normalizedPassword = String(password ?? "");
  if (!normalizedUsername || !normalizedPassword) return null;
  return {
    username: normalizedUsername,
    password: normalizedPassword,
    role: normalizeAuthRole(role),
  };
}

function parseAuthUsersFromConfig() {
  const parsedUsers = [];

  if (AUTH_USERS_JSON) {
    let parsed;
    try {
      parsed = JSON.parse(AUTH_USERS_JSON);
    } catch (error) {
      throw new Error(`APP_LOGIN_USERS_JSON invalido: ${error?.message || error}`);
    }

    if (Array.isArray(parsed)) {
      for (const entry of parsed) {
        const normalized = normalizeAuthUser(entry?.username, entry?.password, entry?.role);
        if (normalized) parsedUsers.push(normalized);
      }
    } else if (parsed && typeof parsed === "object") {
      for (const [username, value] of Object.entries(parsed)) {
        if (value && typeof value === "object" && !Array.isArray(value)) {
          const normalized = normalizeAuthUser(username, value.password, value.role);
          if (normalized) parsedUsers.push(normalized);
          continue;
        }

        const normalized = normalizeAuthUser(username, value, AUTH_ROLE_ADMIN);
        if (normalized) parsedUsers.push(normalized);
      }
    } else {
      throw new Error("APP_LOGIN_USERS_JSON deve ser um objeto ou lista de usuarios.");
    }
  }

  if (parsedUsers.length === 0) {
    const legacyUser = normalizeAuthUser(LEGACY_AUTH_USERNAME, LEGACY_AUTH_PASSWORD, AUTH_ROLE_ADMIN);
    if (legacyUser) parsedUsers.push(legacyUser);
  }

  const deduplicated = new Map();
  for (const entry of parsedUsers) {
    if (!deduplicated.has(entry.username)) {
      deduplicated.set(entry.username, {
        password: entry.password,
        role: entry.role,
      });
    }
  }

  return [...deduplicated.entries()].map(([username, value]) => ({
    username,
    password: value.password,
    role: value.role,
  }));
}

let authUsers = parseAuthUsersFromConfig();
const TRUST_PROXY_SETTING = parseTrustProxySetting(TRUST_PROXY_RAW);
const TRUST_PROXY_ENABLED = TRUST_PROXY_SETTING !== false;

if ((SUPABASE_URL && !SUPABASE_SERVICE_ROLE_KEY) || (!SUPABASE_URL && SUPABASE_SERVICE_ROLE_KEY)) {
  console.warn(
    "[config] SUPABASE_URL e SUPABASE_SERVICE_ROLE_KEY devem ser definidos juntos. Usando armazenamento local."
  );
}

if (TRUST_PROXY_ENABLED && process.env.VERCEL !== "1") {
  console.warn(
    "[security] TRUST_PROXY habilitado fora da Vercel. Configure somente atras de proxy confiavel para evitar spoof de IP."
  );
}

console.info(`[config] Projeto ativo: ${APP_PROJECT_CODE}`);

if (authUsers.length === 0) {
  if (process.env.NODE_ENV === "production" || process.env.VERCEL === "1") {
    throw new Error(
      "Nenhum usuario de login configurado. Defina APP_LOGIN_USERS_JSON ou APP_LOGIN_USER/APP_LOGIN_PASSWORD."
    );
  }

  const devPassword = crypto.randomBytes(12).toString("base64url");
  authUsers = [{ username: "admin", password: devPassword, role: AUTH_ROLE_ADMIN }];
  console.warn(
    `[auth] Nenhum usuario configurado. Usuario temporario gerado para dev: admin / ${devPassword}`
  );
}

const AUTH_USERS = authUsers;

if (!AUTH_TOKEN_SECRET) {
  if (process.env.NODE_ENV === "production" || process.env.VERCEL === "1") {
    throw new Error(
      "AUTH_TOKEN_SECRET nao definido. Configure uma string longa e aleatoria no deploy."
    );
  }
  console.warn(
    "[auth] AUTH_TOKEN_SECRET nao definido. Usando segredo temporario aleatorio para a sessao local."
  );
}

const supabase = SUPABASE_ENABLED
  ? createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, {
      auth: { persistSession: false, autoRefreshToken: false },
    })
  : null;

const app = express();
let isSyncingPendingOps = false;
let pendingSyncIntervalHandle = null;
const loginRateIpMap = new Map();
const loginRateUserMap = new Map();
let loginRateGlobalRecord = {
  windowStart: Date.now(),
  count: 0,
};
const jsonFileCache = new Map();
const authSessions = new Map();
let authSessionPersistQueue = Promise.resolve();
const supabaseWarningCache = new Set();
let supabaseProjectEnsured = false;

app.set("trust proxy", TRUST_PROXY_SETTING);
app.use(express.json({ limit: "256kb" }));

function round2(value) {
  return Math.round((value + Number.EPSILON) * 100) / 100;
}

function toNumber(value) {
  if (typeof value === "number") {
    return Number.isFinite(value) ? value : NaN;
  }

  if (typeof value !== "string") {
    return NaN;
  }

  const cleaned = value.trim().replace(/\./g, "").replace(",", ".");
  const numeric = Number(cleaned);
  return Number.isFinite(numeric) ? numeric : NaN;
}

function slugifyId(value, fallback = "topico") {
  const text = String(value ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
  return text || fallback;
}

function makeUniqueId(seed, usedIds) {
  const base = slugifyId(seed);
  if (!usedIds.has(base)) return base;
  let suffix = 2;
  while (usedIds.has(`${base}-${suffix}`)) suffix += 1;
  return `${base}-${suffix}`;
}

function isIsoDate(value) {
  return typeof value === "string" && /^\d{4}-\d{2}-\d{2}$/.test(value);
}

function getAnoSemestre(dateIso) {
  const [anoText, mesText] = dateIso.split("-");
  const ano = Number(anoText);
  const mes = Number(mesText);
  const semestre = mes <= 6 ? "S1" : "S2";
  return { ano, semestre };
}

function formatDateBr(dateIso) {
  if (!isIsoDate(dateIso)) return "";
  const [ano, mes, dia] = dateIso.split("-");
  return `${dia}/${mes}/${ano}`;
}

function formatCurrency(value) {
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
    minimumFractionDigits: 2,
  }).format(value);
}

function getRolePermissions(roleValue) {
  const role = normalizeAuthRole(roleValue, AUTH_ROLE_VIEWER);
  return {
    role,
    canWriteLancamentos: role === AUTH_ROLE_ADMIN || role === AUTH_ROLE_EDITOR,
    canManageConfig: role === AUTH_ROLE_ADMIN,
    canViewDiagnostics: role === AUTH_ROLE_ADMIN,
  };
}

function normalizeRateUserKey(value) {
  const normalized = String(value ?? "").trim().toLowerCase();
  return normalized || "__anonymous__";
}

function validateBoundedString(value, { fieldLabel, required = false, maxLength }) {
  const text = String(value ?? "").trim();
  if (required && !text) {
    return { ok: false, error: `${fieldLabel} e obrigatorio.` };
  }
  if (maxLength && text.length > maxLength) {
    return { ok: false, error: `${fieldLabel} excede o limite de ${maxLength} caracteres.` };
  }
  return { ok: true, value: text };
}

function truncateText(text, maxLength = PDF_TEXT_MAX_CHARS) {
  const normalized = String(text ?? "");
  if (normalized.length <= maxLength) return normalized;
  return `${normalized.slice(0, Math.max(0, maxLength - 1))}…`;
}

function hasSpreadsheetFormulaPrefix(value) {
  return /^[\s\t]*[=+\-@]/.test(String(value ?? ""));
}

function sanitizeCsvCell(value) {
  const text = String(value ?? "").replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  if (/^[\s\t]*[=+\-@]/.test(text)) {
    return `'${text}`;
  }
  return text;
}

function csvEscape(value) {
  const text = sanitizeCsvCell(value);
  if (!/[",\n]/.test(text)) return text;
  return `"${text.replace(/"/g, "\"\"")}"`;
}

function isSupabaseSchemaError(error) {
  const code = String(error?.code ?? "");
  const message = String(error?.message ?? "").toLowerCase();
  if (code === "42P01" || code === "42703") return true;
  return (
    message.includes("does not exist") ||
    message.includes("relation") ||
    message.includes("column")
  );
}

function warnSupabaseOnce(scope, error) {
  const errorKey = `${scope}:${String(error?.code ?? "")}:${String(error?.message ?? error)}`;
  if (supabaseWarningCache.has(errorKey)) return;
  supabaseWarningCache.add(errorKey);
  console.warn(`[supabase] ${scope}: ${error?.message || error}`);
}

function authCookieBaseParts(req) {
  const parts = ["Path=/", "HttpOnly", "SameSite=Lax"];
  if (process.env.NODE_ENV === "production" || req.secure) parts.push("Secure");
  return parts;
}

function parseCookies(headerValue) {
  if (!headerValue || typeof headerValue !== "string") return {};
  return headerValue.split(";").reduce((acc, rawPart) => {
    const [rawKey, ...rest] = rawPart.trim().split("=");
    if (!rawKey) return acc;
    acc[rawKey] = decodeURIComponent(rest.join("=") || "");
    return acc;
  }, {});
}

function getAuthSecretValue() {
  return AUTH_TOKEN_SECRET || DEV_FALLBACK_AUTH_TOKEN_SECRET;
}

function signAuthPayload(encodedPayload) {
  return crypto.createHmac("sha256", getAuthSecretValue()).update(encodedPayload).digest("base64url");
}

function safeEqualText(a, b) {
  const left = Buffer.from(String(a ?? ""), "utf8");
  const right = Buffer.from(String(b ?? ""), "utf8");
  if (left.length !== right.length) return false;
  return crypto.timingSafeEqual(left, right);
}

function createAuthSessionToken(session) {
  const payload = {
    u: session.username,
    r: session.role,
    sid: session.sessionId,
    exp: session.expiresAt,
  };
  const encodedPayload = Buffer.from(JSON.stringify(payload), "utf8").toString("base64url");
  const signature = signAuthPayload(encodedPayload);
  return `${encodedPayload}.${signature}`;
}

function normalizeAuthSessionRecord(record) {
  const sessionId = String(record?.sessionId ?? record?.sid ?? "").trim();
  const username = String(record?.username ?? record?.u ?? "").trim();
  const role = normalizeAuthRole(record?.role ?? record?.r, AUTH_ROLE_ADMIN);
  const expiresAt = Number(record?.expiresAt ?? record?.exp);
  const createdAt = Number(record?.createdAt ?? Date.now());

  if (!sessionId || !username || !Number.isFinite(expiresAt)) return null;
  return {
    sessionId,
    username,
    role,
    expiresAt,
    createdAt: Number.isFinite(createdAt) ? createdAt : Date.now(),
  };
}

function serializeAuthSessions() {
  return [...authSessions.values()].map((session) => ({
    sessionId: session.sessionId,
    username: session.username,
    role: session.role,
    expiresAt: session.expiresAt,
    createdAt: session.createdAt,
  }));
}

function pruneExpiredAuthSessions(now = Date.now()) {
  let changed = false;
  for (const [sessionId, session] of authSessions.entries()) {
    if (!session || !Number.isFinite(session.expiresAt) || session.expiresAt <= now) {
      authSessions.delete(sessionId);
      changed = true;
    }
  }
  return changed;
}

function enforceAuthSessionLimit() {
  if (authSessions.size <= AUTH_MAX_ACTIVE_SESSIONS) return false;

  const sessions = [...authSessions.values()].sort((a, b) => {
    if (a.expiresAt !== b.expiresAt) return a.expiresAt - b.expiresAt;
    return a.createdAt - b.createdAt;
  });

  const overflow = authSessions.size - AUTH_MAX_ACTIVE_SESSIONS;
  for (let index = 0; index < overflow; index += 1) {
    authSessions.delete(sessions[index].sessionId);
  }

  return overflow > 0;
}

function schedulePersistAuthSessions() {
  const snapshot = serializeAuthSessions();
  authSessionPersistQueue = authSessionPersistQueue
    .catch(() => {})
    .then(async () => {
      await writeJson(AUTH_SESSION_STORE_FILE, snapshot);
      if (SUPABASE_ENABLED) {
        try {
          await persistAuthSessionsToSupabase(snapshot);
        } catch (error) {
          warnSupabaseOnce("falha ao persistir sessoes", error);
        }
      }
    });
  return authSessionPersistQueue;
}

async function loadAuthSessionsFromDisk() {
  let raw = null;
  if (SUPABASE_ENABLED) {
    try {
      raw = await loadAuthSessionsFromSupabase();
    } catch (error) {
      warnSupabaseOnce("falha ao carregar sessoes", error);
      raw = null;
    }
  }

  if (!Array.isArray(raw)) {
    raw = await readJson(AUTH_SESSION_STORE_FILE, []);
  }

  authSessions.clear();

  if (Array.isArray(raw)) {
    for (const item of raw) {
      const normalized = normalizeAuthSessionRecord(item);
      if (normalized) {
        authSessions.set(normalized.sessionId, normalized);
      }
    }
  }

  const changed = pruneExpiredAuthSessions() || enforceAuthSessionLimit();
  if (changed) {
    await schedulePersistAuthSessions();
  } else if (SUPABASE_ENABLED) {
    await writeJson(AUTH_SESSION_STORE_FILE, serializeAuthSessions());
  }
}

function parseAuthSessionToken(token) {
  if (!token || typeof token !== "string") return null;
  const [encodedPayload, providedSignature] = token.split(".");
  if (!encodedPayload || !providedSignature) return null;

  const expectedSignature = signAuthPayload(encodedPayload);
  if (!safeEqualText(expectedSignature, providedSignature)) return null;

  let payload;
  try {
    payload = JSON.parse(Buffer.from(encodedPayload, "base64url").toString("utf8"));
  } catch {
    return null;
  }

  const username = String(payload?.u ?? "").trim();
  const sessionId = String(payload?.sid ?? "").trim();
  const role = normalizeAuthRole(payload?.r, AUTH_ROLE_ADMIN);
  const expiresAt = Number(payload?.exp);
  if (!username || !sessionId || !Number.isFinite(expiresAt)) return null;

  if (expiresAt <= Date.now()) {
    if (authSessions.delete(sessionId)) {
      schedulePersistAuthSessions().catch(() => {});
    }
    return null;
  }

  const storedSession = authSessions.get(sessionId);
  if (!storedSession) return null;
  if (storedSession.username !== username) return null;
  if (storedSession.role !== role) return null;
  if (storedSession.expiresAt !== expiresAt) return null;

  return {
    username,
    role,
    expiresAt,
    sessionId,
    permissions: getRolePermissions(role),
  };
}

function cleanupRateMap(map, windowMs) {
  const now = Date.now();
  for (const [key, record] of map.entries()) {
    if (!record || now - record.windowStart > windowMs) {
      map.delete(key);
    }
  }
}

function cleanupGlobalRateRecord() {
  const now = Date.now();
  if (now - loginRateGlobalRecord.windowStart > LOGIN_RATE_GLOBAL_WINDOW_MS) {
    loginRateGlobalRecord = {
      windowStart: now,
      count: 0,
    };
  }
}

function registerFailureInMap(map, key, windowMs) {
  const now = Date.now();
  const current = map.get(key);
  if (!current || now - current.windowStart > windowMs) {
    map.set(key, { count: 1, windowStart: now });
  } else {
    current.count += 1;
    map.set(key, current);
  }

  if (map.size <= LOGIN_RATE_MAX_TRACKED_KEYS) return;

  const sortedKeys = [...map.entries()]
    .sort((a, b) => Number(a[1]?.windowStart ?? 0) - Number(b[1]?.windowStart ?? 0))
    .slice(0, map.size - LOGIN_RATE_MAX_TRACKED_KEYS)
    .map(([itemKey]) => itemKey);

  for (const itemKey of sortedKeys) {
    map.delete(itemKey);
  }
}

function registerGlobalLoginFailure() {
  const now = Date.now();
  if (now - loginRateGlobalRecord.windowStart > LOGIN_RATE_GLOBAL_WINDOW_MS) {
    loginRateGlobalRecord = {
      windowStart: now,
      count: 1,
    };
    return;
  }
  loginRateGlobalRecord.count += 1;
}

function getRequestIp(req) {
  return String(req.ip || req.socket?.remoteAddress || "unknown");
}

function isLoginRateLimited(req, username) {
  cleanupRateMap(loginRateIpMap, LOGIN_RATE_WINDOW_MS);
  cleanupRateMap(loginRateUserMap, LOGIN_RATE_WINDOW_MS);
  cleanupGlobalRateRecord();

  const ip = getRequestIp(req);
  const userKey = normalizeRateUserKey(username);
  const ipAttempts = Number(loginRateIpMap.get(ip)?.count ?? 0);
  const userAttempts = Number(loginRateUserMap.get(userKey)?.count ?? 0);
  const globalAttempts = Number(loginRateGlobalRecord.count ?? 0);

  return (
    ipAttempts >= LOGIN_RATE_MAX_ATTEMPTS ||
    userAttempts >= LOGIN_RATE_MAX_ATTEMPTS_PER_USER ||
    globalAttempts >= LOGIN_RATE_MAX_ATTEMPTS_GLOBAL
  );
}

function registerLoginAttempt(req, username, success) {
  const ip = getRequestIp(req);
  const userKey = normalizeRateUserKey(username);
  if (success) {
    loginRateIpMap.delete(ip);
    loginRateUserMap.delete(userKey);
    return;
  }

  registerFailureInMap(loginRateIpMap, ip, LOGIN_RATE_WINDOW_MS);
  registerFailureInMap(loginRateUserMap, userKey, LOGIN_RATE_WINDOW_MS);
  registerGlobalLoginFailure();
}

function getAuthTokenFromRequest(req) {
  const cookies = parseCookies(req.headers?.cookie);
  return cookies[AUTH_COOKIE_NAME] || "";
}

function getAuthSessionFromRequest(req) {
  if (req && Object.prototype.hasOwnProperty.call(req, "_authSessionCache")) {
    return req._authSessionCache;
  }

  const token = getAuthTokenFromRequest(req);
  const parsed = token ? parseAuthSessionToken(token) : null;

  if (req) {
    req._authSessionCache = parsed;
  }
  return parsed;
}

function isAuthenticatedRequest(req) {
  return Boolean(getAuthSessionFromRequest(req));
}

function setAuthCookie(req, res, token) {
  const maxAgeSeconds = Math.floor(AUTH_SESSION_TTL_MS / 1000);
  const parts = [...authCookieBaseParts(req), `Max-Age=${maxAgeSeconds}`];
  res.setHeader("Set-Cookie", `${AUTH_COOKIE_NAME}=${encodeURIComponent(token)}; ${parts.join("; ")}`);
}

function clearAuthCookie(req, res) {
  const parts = [...authCookieBaseParts(req), "Max-Age=0"];
  res.setHeader("Set-Cookie", `${AUTH_COOKIE_NAME}=; ${parts.join("; ")}`);
}

async function createAuthSession(account) {
  pruneExpiredAuthSessions();

  const now = Date.now();
  const session = {
    sessionId: uuidv4(),
    username: account.username,
    role: normalizeAuthRole(account.role, AUTH_ROLE_ADMIN),
    expiresAt: now + AUTH_SESSION_TTL_MS,
    createdAt: now,
  };

  authSessions.set(session.sessionId, session);
  const trimmed = enforceAuthSessionLimit();
  if (trimmed || authSessions.size > 0) {
    await schedulePersistAuthSessions();
  }

  return createAuthSessionToken(session);
}

function authenticateUser(username, password) {
  for (const account of AUTH_USERS) {
    if (safeEqualText(username, account.username) && safeEqualText(password, account.password)) {
      return {
        username: account.username,
        role: normalizeAuthRole(account.role, AUTH_ROLE_ADMIN),
      };
    }
  }
  return null;
}

function expectedRequestOrigin(req) {
  const host = req.get("x-forwarded-host") || req.get("host");
  if (!host) return null;

  const forwardedProto = req.get("x-forwarded-proto");
  const protocol = forwardedProto ? forwardedProto.split(",")[0].trim() : req.protocol || "http";
  return `${protocol}://${host}`;
}

function isTrustedRequestOrigin(req) {
  const candidate = req.get("origin") || req.get("referer");
  const hasSessionCookie = Boolean(getAuthTokenFromRequest(req));
  if (!candidate) return !hasSessionCookie;

  const expectedOrigin = expectedRequestOrigin(req);
  if (!expectedOrigin) return false;

  try {
    return new URL(candidate).origin === expectedOrigin;
  } catch {
    return false;
  }
}

async function removeAuthSessionByRequest(req) {
  const session = getAuthSessionFromRequest(req);
  if (!session?.sessionId) return false;

  const removed = authSessions.delete(session.sessionId);
  req._authSessionCache = null;
  if (removed) {
    await schedulePersistAuthSessions();
  }
  return removed;
}

function requireAnyRole(allowedRoles) {
  const allowed = new Set(allowedRoles.map((role) => normalizeAuthRole(role, AUTH_ROLE_VIEWER)));

  return (req, res, next) => {
    const session = getAuthSessionFromRequest(req);
    if (!session) {
      res.status(401).json({ error: "Nao autenticado. Faca login para continuar." });
      return;
    }
    if (!allowed.has(session.role)) {
      res.status(403).json({ error: "Sem permissao para executar esta operacao." });
      return;
    }
    next();
  };
}

function groupLabelPt(name) {
  return GROUP_LABELS_PT[name] || name;
}

function topicLabelPt(name) {
  return TOPIC_LABELS_PT[name] || name;
}

function canLancarNoTopico(topico) {
  if (!topico) return false;
  if (topico.permitirLancamento) return true;
  return TEAM_HIRES_UNLOCKED && topico.grupo === "TEAM HIRES";
}

function topicoPublico(topico) {
  return {
    ...topico,
    permitirLancamentoEfetivo: canLancarNoTopico(topico),
  };
}

function topicoFromSupabase(row) {
  if (!row) return null;
  const id = String(row.id ?? "").trim();
  if (!id) return null;
  const orcamento = toNumber(row.orcamento_programa_brl);
  return {
    id,
    nome: String(row.nome ?? "").trim(),
    grupo: String(row.grupo ?? "COMMUNICATIONS & PUBLICATIONS").trim() || "COMMUNICATIONS & PUBLICATIONS",
    templateRow: Number.isFinite(Number(row.template_row)) ? Number(row.template_row) : null,
    incluirNoResumo: row.incluir_no_resumo !== false,
    permitirLancamento: row.permitir_lancamento !== false,
    ordem: Number.isFinite(Number(row.ordem)) ? Number(row.ordem) : 0,
    orcamentoProgramaBRL: Number.isFinite(orcamento)
      ? round2(orcamento)
      : Number(TOPICO_ORCAMENTO_BRL_PADRAO[id] ?? 0),
  };
}

function topicoToSupabase(topico) {
  return {
    project_code: APP_PROJECT_CODE,
    id: String(topico.id ?? "").trim(),
    nome: String(topico.nome ?? "").trim(),
    grupo: String(topico.grupo ?? "COMMUNICATIONS & PUBLICATIONS"),
    template_row: Number.isFinite(Number(topico.templateRow)) ? Number(topico.templateRow) : null,
    incluir_no_resumo: Boolean(topico.incluirNoResumo),
    permitir_lancamento: Boolean(topico.permitirLancamento),
    ordem: Number.isFinite(Number(topico.ordem)) ? Number(topico.ordem) : 0,
    orcamento_programa_brl: round2(Number(topico.orcamentoProgramaBRL ?? 0)),
    updated_at: new Date().toISOString(),
  };
}

function authSessionFromSupabase(row) {
  if (!row) return null;
  return normalizeAuthSessionRecord({
    sessionId: row.session_id,
    username: row.username,
    role: row.role,
    expiresAt: Date.parse(String(row.expires_at ?? "")),
    createdAt: Date.parse(String(row.created_at ?? "")),
  });
}

function authSessionToSupabase(session) {
  return {
    project_code: APP_PROJECT_CODE,
    session_id: String(session.sessionId),
    username: String(session.username),
    role: normalizeAuthRole(session.role, AUTH_ROLE_ADMIN),
    expires_at: new Date(Number(session.expiresAt)).toISOString(),
    created_at: new Date(Number(session.createdAt)).toISOString(),
  };
}

function appConfigFromSupabase(row) {
  if (!row) return null;
  return {
    teamHiresUnlocked: Boolean(row.team_hires_unlocked),
  };
}

function appConfigToSupabase() {
  return {
    project_code: APP_PROJECT_CODE,
    team_hires_unlocked: Boolean(TEAM_HIRES_UNLOCKED),
    updated_at: new Date().toISOString(),
  };
}

function lancamentoFromSupabase(row) {
  if (!row) return null;
  const valor = toNumber(row.valor);
  const ano = Number(row.ano);
  const fallbackDate = String(row.data ?? "");
  const fallback = isIsoDate(fallbackDate) ? getAnoSemestre(fallbackDate) : { ano: 0, semestre: "S1" };

  return {
    id: String(row.id),
    topicoId: String(row.topico_id ?? ""),
    data: fallbackDate,
    descricao: String(row.descricao ?? ""),
    fornecedor: String(row.fornecedor ?? ""),
    responsavel: String(row.responsavel ?? ""),
    valor: Number.isFinite(valor) ? round2(valor) : 0,
    semestre: row.semestre === "S1" || row.semestre === "S2" ? row.semestre : fallback.semestre,
    ano: Number.isFinite(ano) ? ano : fallback.ano,
    criadoEm: row.criado_em ? new Date(row.criado_em).toISOString() : null,
    atualizadoEm: row.atualizado_em ? new Date(row.atualizado_em).toISOString() : null,
  };
}

function lancamentoToSupabase(lancamento) {
  return {
    id: lancamento.id,
    project_code: APP_PROJECT_CODE,
    topico_id: lancamento.topicoId,
    data: lancamento.data,
    descricao: lancamento.descricao,
    fornecedor: lancamento.fornecedor ?? "",
    responsavel: lancamento.responsavel ?? "",
    valor: round2(lancamento.valor),
    semestre: lancamento.semestre,
    ano: lancamento.ano,
    criado_em: lancamento.criadoEm ?? new Date().toISOString(),
    atualizado_em: lancamento.atualizadoEm ?? new Date().toISOString(),
  };
}

async function ensureSupabaseProjectRow() {
  if (!SUPABASE_ENABLED) return;
  if (supabaseProjectEnsured) return;

  try {
    const payload = {
      code: APP_PROJECT_CODE,
      name: APP_PROJECT_CODE,
      is_active: true,
    };
    const { error } = await supabase
      .from(SUPABASE_PROJECTS_TABLE)
      .upsert(payload, { onConflict: "code" });
    if (error) {
      if (isSupabaseSchemaError(error)) {
        warnSupabaseOnce("projects table indisponivel", error);
        return;
      }
      throw new Error(error.message);
    }
    supabaseProjectEnsured = true;
  } catch (error) {
    warnSupabaseOnce("falha ao registrar projeto", error);
  }
}

async function persistTopicosToSupabase(topicos) {
  if (!SUPABASE_ENABLED) return false;
  if (!Array.isArray(topicos)) return false;

  await ensureSupabaseProjectRow();

  const payload = topicos.map(topicoToSupabase).filter((item) => item.id);
  const { data: existingRows, error: existingError } = await supabase
    .from(SUPABASE_TOPICOS_TABLE)
    .select("id")
    .eq("project_code", APP_PROJECT_CODE);

  if (existingError) {
    if (isSupabaseSchemaError(existingError)) {
      warnSupabaseOnce("topicos table indisponivel", existingError);
      return false;
    }
    throw new Error(existingError.message);
  }

  if (payload.length > 0) {
    const { error } = await supabase
      .from(SUPABASE_TOPICOS_TABLE)
      .upsert(payload, { onConflict: "project_code,id" });

    if (error) {
      if (isSupabaseSchemaError(error)) {
        warnSupabaseOnce("topicos table indisponivel", error);
        return false;
      }
      throw new Error(error.message);
    }
  }

  const existingIds = new Set((existingRows ?? []).map((row) => String(row.id ?? "").trim()).filter(Boolean));
  const desiredIds = new Set(payload.map((row) => String(row.id)));
  const idsToDelete = [...existingIds].filter((id) => !desiredIds.has(id));

  if (idsToDelete.length > 0) {
    const { error: deleteError } = await supabase
      .from(SUPABASE_TOPICOS_TABLE)
      .delete()
      .eq("project_code", APP_PROJECT_CODE)
      .in("id", idsToDelete);

    if (deleteError) {
      if (isSupabaseSchemaError(deleteError)) {
        warnSupabaseOnce("topicos table indisponivel", deleteError);
        return false;
      }
      throw new Error(deleteError.message);
    }
  }

  return true;
}

async function loadTopicosFromSupabase() {
  if (!SUPABASE_ENABLED) return null;

  await ensureSupabaseProjectRow();

  const { data, error } = await supabase
    .from(SUPABASE_TOPICOS_TABLE)
    .select("*")
    .eq("project_code", APP_PROJECT_CODE)
    .order("ordem", { ascending: true });

  if (error) {
    if (isSupabaseSchemaError(error)) {
      warnSupabaseOnce("topicos table indisponivel", error);
      return null;
    }
    throw new Error(error.message);
  }

  return (data ?? []).map(topicoFromSupabase).filter(Boolean);
}

async function loadAppConfigFromSupabase() {
  if (!SUPABASE_ENABLED) return null;

  await ensureSupabaseProjectRow();

  const { data, error } = await supabase
    .from(SUPABASE_APP_CONFIG_TABLE)
    .select("project_code, team_hires_unlocked")
    .eq("project_code", APP_PROJECT_CODE)
    .maybeSingle();

  if (error) {
    if (isSupabaseSchemaError(error)) {
      warnSupabaseOnce("app_config table indisponivel", error);
      return null;
    }
    throw new Error(error.message);
  }

  return appConfigFromSupabase(data);
}

async function persistAppConfigToSupabase() {
  if (!SUPABASE_ENABLED) return false;

  await ensureSupabaseProjectRow();

  const { error } = await supabase
    .from(SUPABASE_APP_CONFIG_TABLE)
    .upsert(appConfigToSupabase(), { onConflict: "project_code" });

  if (error) {
    if (isSupabaseSchemaError(error)) {
      warnSupabaseOnce("app_config table indisponivel", error);
      return false;
    }
    throw new Error(error.message);
  }

  return true;
}

async function loadAuthSessionsFromSupabase() {
  if (!SUPABASE_ENABLED) return null;

  await ensureSupabaseProjectRow();

  const { data, error } = await supabase
    .from(SUPABASE_AUTH_SESSIONS_TABLE)
    .select("session_id, username, role, expires_at, created_at")
    .eq("project_code", APP_PROJECT_CODE);

  if (error) {
    if (isSupabaseSchemaError(error)) {
      warnSupabaseOnce("auth_sessions table indisponivel", error);
      return null;
    }
    throw new Error(error.message);
  }

  return (data ?? []).map(authSessionFromSupabase).filter(Boolean);
}

async function persistAuthSessionsToSupabase(snapshot) {
  if (!SUPABASE_ENABLED) return false;

  await ensureSupabaseProjectRow();

  const clearError = await supabase
    .from(SUPABASE_AUTH_SESSIONS_TABLE)
    .delete()
    .eq("project_code", APP_PROJECT_CODE);

  if (clearError.error) {
    if (isSupabaseSchemaError(clearError.error)) {
      warnSupabaseOnce("auth_sessions table indisponivel", clearError.error);
      return false;
    }
    throw new Error(clearError.error.message);
  }

  if (!Array.isArray(snapshot) || snapshot.length === 0) return true;

  const payload = snapshot.map(authSessionToSupabase);
  const { error } = await supabase.from(SUPABASE_AUTH_SESSIONS_TABLE).insert(payload);
  if (error) {
    if (isSupabaseSchemaError(error)) {
      warnSupabaseOnce("auth_sessions table indisponivel", error);
      return false;
    }
    throw new Error(error.message);
  }

  return true;
}

async function writeAuditLog(req, action, entityType, entityId, beforeData = null, afterData = null) {
  if (!SUPABASE_ENABLED) return;
  const session = getAuthSessionFromRequest(req);
  const payload = {
    project_code: APP_PROJECT_CODE,
    actor_username: String(session?.username ?? "system"),
    actor_role: String(session?.role ?? "system"),
    action: String(action ?? "unknown"),
    entity_type: String(entityType ?? "unknown"),
    entity_id: String(entityId ?? ""),
    before_data: beforeData ?? null,
    after_data: afterData ?? null,
    created_at: new Date().toISOString(),
  };

  try {
    const { error } = await supabase.from(SUPABASE_AUDIT_LOG_TABLE).insert(payload);
    if (error) {
      if (isSupabaseSchemaError(error)) {
        warnSupabaseOnce("audit_log table indisponivel", error);
        return;
      }
      throw new Error(error.message);
    }
  } catch (error) {
    warnSupabaseOnce("falha ao gravar auditoria", error);
  }
}

async function copyBundleFileIfMissing(targetPath, sourcePath) {
  if (fs.existsSync(targetPath)) return false;
  if (!sourcePath || !fs.existsSync(sourcePath)) return false;
  if (path.resolve(targetPath) === path.resolve(sourcePath)) return false;
  await fsp.copyFile(sourcePath, targetPath);
  return true;
}

async function ensureStorage() {
  await fsp.mkdir(DATA_DIR, { recursive: true });

  if (!fs.existsSync(TOPICOS_FILE)) {
    const copied = await copyBundleFileIfMissing(TOPICOS_FILE, TOPICOS_BUNDLE_FILE);
    if (copied) {
      console.info(`[storage] topicos inicializados de ${TOPICOS_BUNDLE_FILE} para ${TOPICOS_FILE}`);
    }
  }

  if (!fs.existsSync(TOPICOS_FILE)) {
    await fsp.writeFile(
      TOPICOS_FILE,
      JSON.stringify(
        [
          {
            id: "nurse-1",
            nome: "Nurse 1",
            grupo: "TEAM HIRES",
            templateRow: 15,
            incluirNoResumo: false,
            permitirLancamento: false,
            ordem: 1,
          },
          {
            id: "nurse-2",
            nome: "Nurse 2",
            grupo: "TEAM HIRES",
            templateRow: 16,
            incluirNoResumo: false,
            permitirLancamento: false,
            ordem: 2,
          },
          {
            id: "project-coordinator",
            nome: "Project Coordinator",
            grupo: "TEAM HIRES",
            templateRow: 17,
            incluirNoResumo: false,
            permitirLancamento: false,
            ordem: 3,
          },
          {
            id: "administrative-assistant-1",
            nome: "Administrative Assistant 1",
            grupo: "TEAM HIRES",
            templateRow: 18,
            incluirNoResumo: false,
            permitirLancamento: false,
            ordem: 4,
          },
          {
            id: "administrative-assistant-2",
            nome: "Administrative Assistant 2",
            grupo: "TEAM HIRES",
            templateRow: 19,
            incluirNoResumo: false,
            permitirLancamento: false,
            ordem: 5,
          },
          {
            id: "computer",
            nome: "Computer",
            grupo: "COMMUNICATIONS & PUBLICATIONS",
            templateRow: 21,
            incluirNoResumo: true,
            permitirLancamento: true,
            ordem: 6,
          },
          {
            id: "didactic-material",
            nome: "Didactic Material",
            grupo: "COMMUNICATIONS & PUBLICATIONS",
            templateRow: 22,
            incluirNoResumo: true,
            permitirLancamento: true,
            ordem: 7,
          },
          {
            id: "publications",
            nome: "Publications",
            grupo: "COMMUNICATIONS & PUBLICATIONS",
            templateRow: 23,
            incluirNoResumo: true,
            permitirLancamento: true,
            ordem: 8,
          },
          {
            id: "technical-equipment-infrastructure",
            nome: "Technical Equipment & Infrastructure",
            grupo: "COMMUNICATIONS & PUBLICATIONS",
            templateRow: 24,
            incluirNoResumo: true,
            permitirLancamento: true,
            ordem: 9,
          },
          {
            id: "team-transportation-meals",
            nome: "Team Transportation & Meals",
            grupo: "COMMUNICATIONS & PUBLICATIONS",
            templateRow: 25,
            incluirNoResumo: true,
            permitirLancamento: true,
            ordem: 10,
          },
          {
            id: "events-conferences",
            nome: "Events & Conferences",
            grupo: "COMMUNICATIONS & PUBLICATIONS",
            templateRow: 26,
            incluirNoResumo: true,
            permitirLancamento: true,
            ordem: 11,
          },
          {
            id: "just-mine",
            nome: "Just Mine",
            grupo: "THIRD PARTY SERVICES",
            templateRow: 28,
            incluirNoResumo: true,
            permitirLancamento: true,
            ordem: 12,
          },
          {
            id: "external-consultant",
            nome: "External Consultant",
            grupo: "THIRD PARTY SERVICES",
            templateRow: 29,
            incluirNoResumo: true,
            permitirLancamento: true,
            ordem: 13,
          },
          {
            id: "digital-marketing",
            nome: "Digital Marketing",
            grupo: "THIRD PARTY SERVICES",
            templateRow: 30,
            incluirNoResumo: true,
            permitirLancamento: true,
            ordem: 14,
          },
        ],
        null,
        2
      ),
      "utf8"
    );
  }

  if (!fs.existsSync(LANCAMENTOS_FILE)) {
    const copied = await copyBundleFileIfMissing(LANCAMENTOS_FILE, LANCAMENTOS_BUNDLE_FILE);
    if (!copied) {
      await fsp.writeFile(LANCAMENTOS_FILE, "[]", "utf8");
    }
  }

  if (!fs.existsSync(PENDING_SYNC_FILE)) {
    await fsp.writeFile(PENDING_SYNC_FILE, "[]", "utf8");
  }

  if (!fs.existsSync(APP_CONFIG_FILE)) {
    await copyBundleFileIfMissing(APP_CONFIG_FILE, APP_CONFIG_BUNDLE_FILE);
  }
  if (!fs.existsSync(AUTH_SESSION_STORE_FILE)) {
    await fsp.writeFile(AUTH_SESSION_STORE_FILE, "[]", "utf8");
  }

  await ensureSupabaseProjectRow();
  await loadTeamHiresConfig();
  await loadAuthSessionsFromDisk();
}

async function readJson(filePath, fallbackValue) {
  try {
    const stats = await fsp.stat(filePath);
    const cached = jsonFileCache.get(filePath);
    if (cached && cached.mtimeMs === stats.mtimeMs) {
      return cached.value;
    }

    const raw = await fsp.readFile(filePath, "utf8");
    const parsed = JSON.parse(raw);
    jsonFileCache.set(filePath, {
      mtimeMs: stats.mtimeMs,
      value: parsed,
    });
    return parsed;
  } catch {
    return fallbackValue;
  }
}

async function writeJson(filePath, value) {
  await fsp.writeFile(filePath, JSON.stringify(value, null, 2), "utf8");
  try {
    const stats = await fsp.stat(filePath);
    jsonFileCache.set(filePath, {
      mtimeMs: stats.mtimeMs,
      value,
    });
  } catch {
    jsonFileCache.delete(filePath);
  }
}

async function readLocalLancamentos() {
  const lancamentos = await readJson(LANCAMENTOS_FILE, []);
  return Array.isArray(lancamentos) ? lancamentos : [];
}

async function writeLocalLancamentos(lancamentos) {
  await writeJson(LANCAMENTOS_FILE, Array.isArray(lancamentos) ? lancamentos : []);
}

async function readPendingSyncQueue() {
  const queue = await readJson(PENDING_SYNC_FILE, []);
  return Array.isArray(queue) ? queue : [];
}

async function writePendingSyncQueue(queue) {
  await writeJson(PENDING_SYNC_FILE, Array.isArray(queue) ? queue : []);
}

async function enqueuePendingSyncOperation(type, lancamentoId, payload = null, errorMessage = "") {
  if (!SUPABASE_ENABLED) return;

  const queue = await readPendingSyncQueue();
  queue.push({
    id: uuidv4(),
    projectCode: APP_PROJECT_CODE,
    type,
    lancamentoId,
    payload,
    createdAt: new Date().toISOString(),
    retryCount: 0,
    lastError: errorMessage ? String(errorMessage) : "",
  });
  await writePendingSyncQueue(queue);
  console.warn(
    `[sync] Operacao pendente registrada type=${type} lancamentoId=${lancamentoId} pendentes=${queue.length}`
  );
}

function applyPendingQueueToLancamentos(baseLancamentos, queue) {
  const map = new Map((baseLancamentos ?? []).map((item) => [item.id, item]));

  for (const op of queue ?? []) {
    if (!op || !op.type) continue;
    if (op.projectCode && op.projectCode !== APP_PROJECT_CODE) continue;
    if ((op.type === "create" || op.type === "update") && op.payload?.id) {
      map.set(op.payload.id, op.payload);
      continue;
    }
    if (op.type === "delete" && op.lancamentoId) {
      map.delete(op.lancamentoId);
    }
  }

  return [...map.values()].sort((a, b) => String(b.data).localeCompare(String(a.data)));
}

async function syncPendingOpsToSupabase() {
  if (!SUPABASE_ENABLED) return { synced: 0, pending: 0, skipped: true };
  if (isSyncingPendingOps) return { synced: 0, pending: 0, skipped: true };

  isSyncingPendingOps = true;
  try {
    const queue = await readPendingSyncQueue();
    if (queue.length === 0) return { synced: 0, pending: 0, skipped: false };

    const foreignProjectQueue = queue.filter((op) => op?.projectCode && op.projectCode !== APP_PROJECT_CODE);
    const currentProjectQueue = queue.filter((op) => !op?.projectCode || op.projectCode === APP_PROJECT_CODE);
    if (currentProjectQueue.length === 0) {
      return { synced: 0, pending: queue.length, skipped: false };
    }

    for (let index = 0; index < currentProjectQueue.length; index += 1) {
      const op = currentProjectQueue[index];
      try {
        if (op.type === "create" || op.type === "update") {
          if (!op.payload) {
            throw new Error("Payload ausente para operacao create/update.");
          }
          let { error } = await supabase
            .from(SUPABASE_LANCAMENTOS_TABLE)
            .upsert(lancamentoToSupabase(op.payload), { onConflict: "project_code,id" });
          if (error && isSupabaseSchemaError(error)) {
            warnSupabaseOnce("sync pendencias em modo legado", error);
            const legacyPayload = { ...lancamentoToSupabase(op.payload) };
            delete legacyPayload.project_code;
            ({ error } = await supabase
              .from(SUPABASE_LANCAMENTOS_TABLE)
              .upsert(legacyPayload, { onConflict: "id" }));
          }
          if (error) {
            throw new Error(error.message);
          }
        } else if (op.type === "delete") {
          let { error } = await supabase
            .from(SUPABASE_LANCAMENTOS_TABLE)
            .delete()
            .eq("id", op.lancamentoId)
            .eq("project_code", APP_PROJECT_CODE);
          if (error && isSupabaseSchemaError(error)) {
            warnSupabaseOnce("sync delete pendencias em modo legado", error);
            ({ error } = await supabase.from(SUPABASE_LANCAMENTOS_TABLE).delete().eq("id", op.lancamentoId));
          }
          if (error) {
            throw new Error(error.message);
          }
        } else {
          throw new Error(`Tipo de operacao invalido: ${op.type}`);
        }
      } catch (error) {
        const pendingCurrent = currentProjectQueue.slice(index);
        pendingCurrent[0] = {
          ...pendingCurrent[0],
          retryCount: Number(pendingCurrent[0].retryCount ?? 0) + 1,
          lastError: String(error?.message || error),
        };
        await writePendingSyncQueue([...foreignProjectQueue, ...pendingCurrent]);
        console.warn(
          `[sync] Falha ao processar pendencia type=${op.type} lancamentoId=${op.lancamentoId} erro=${error?.message || error}`
        );
        return { synced: index, pending: foreignProjectQueue.length + pendingCurrent.length, skipped: false };
      }
    }

    await writePendingSyncQueue(foreignProjectQueue);
    console.info(`[sync] Pendencias sincronizadas com sucesso: ${currentProjectQueue.length}`);
    return { synced: currentProjectQueue.length, pending: foreignProjectQueue.length, skipped: false };
  } finally {
    isSyncingPendingOps = false;
  }
}

function triggerPendingSync() {
  if (!SUPABASE_ENABLED) return;
  syncPendingOpsToSupabase().catch((error) => {
    console.warn(`[sync] Erro no sincronizador: ${error?.message || error}`);
  });
}

function ensurePendingSyncWorker() {
  if (!SUPABASE_ENABLED || pendingSyncIntervalHandle) return;
  pendingSyncIntervalHandle = setInterval(() => {
    triggerPendingSync();
  }, PENDING_SYNC_INTERVAL_MS);
  pendingSyncIntervalHandle.unref?.();
}

async function loadTeamHiresConfig() {
  if (SUPABASE_ENABLED) {
    try {
      const configFromSupabase = await loadAppConfigFromSupabase();
      if (typeof configFromSupabase?.teamHiresUnlocked === "boolean") {
        TEAM_HIRES_UNLOCKED = configFromSupabase.teamHiresUnlocked;
        await writeJson(APP_CONFIG_FILE, { teamHiresUnlocked: TEAM_HIRES_UNLOCKED });
        return;
      }
    } catch (error) {
      warnSupabaseOnce("falha ao carregar app_config", error);
    }
  }

  const configFromFile = await readJson(APP_CONFIG_FILE, {});
  if (typeof configFromFile?.teamHiresUnlocked === "boolean") {
    TEAM_HIRES_UNLOCKED = configFromFile.teamHiresUnlocked;
  }
}

async function saveTeamHiresConfig() {
  if (SUPABASE_ENABLED) {
    const persisted = await persistAppConfigToSupabase();
    if (!persisted) {
      throw new Error(
        `Persistencia de configuracao no Supabase indisponivel. Configure a tabela ${SUPABASE_APP_CONFIG_TABLE}.`
      );
    }
  }
  await writeJson(APP_CONFIG_FILE, {
    teamHiresUnlocked: TEAM_HIRES_UNLOCKED,
  });
}

function normalizeTopicosList(topicos) {
  return [...(Array.isArray(topicos) ? topicos : [])]
    .map((topico) => ({
      ...topico,
      orcamentoProgramaBRL: Number(
        topico.orcamentoProgramaBRL ?? TOPICO_ORCAMENTO_BRL_PADRAO[topico.id] ?? 0
      ),
    }))
    .sort((a, b) => (a.ordem ?? 0) - (b.ordem ?? 0));
}

async function getTopicos() {
  if (SUPABASE_ENABLED) {
    try {
      const fromSupabase = await loadTopicosFromSupabase();
      if (Array.isArray(fromSupabase) && fromSupabase.length > 0) {
        const normalized = normalizeTopicosList(fromSupabase);
        await writeJson(TOPICOS_FILE, normalized);
        return normalized;
      }

      const topicosLocal = normalizeTopicosList(await readJson(TOPICOS_FILE, []));
      if (topicosLocal.length > 0) {
        const persisted = await persistTopicosToSupabase(topicosLocal);
        if (persisted) {
          return topicosLocal;
        }
      }
    } catch (error) {
      warnSupabaseOnce("falha ao carregar topicos", error);
    }
  }

  const topicos = await readJson(TOPICOS_FILE, []);
  return normalizeTopicosList(topicos);
}

async function persistTopicos(topicos) {
  const normalized = normalizeTopicosList(topicos);
  if (SUPABASE_ENABLED) {
    const persisted = await persistTopicosToSupabase(normalized);
    if (!persisted) {
      throw new Error(
        `Persistencia de topicos no Supabase indisponivel. Configure a tabela ${SUPABASE_TOPICOS_TABLE}.`
      );
    }
  }
  await writeJson(TOPICOS_FILE, normalized);
  return normalized;
}

async function getLancamentos() {
  if (SUPABASE_ENABLED) {
    try {
      let { data, error } = await supabase
        .from(SUPABASE_LANCAMENTOS_TABLE)
        .select("*")
        .eq("project_code", APP_PROJECT_CODE)
        .order("data", { ascending: false });

      if (error && isSupabaseSchemaError(error)) {
        warnSupabaseOnce("lancamentos sem coluna project_code (modo legado)", error);
        ({ data, error } = await supabase
          .from(SUPABASE_LANCAMENTOS_TABLE)
          .select("*")
          .order("data", { ascending: false }));
      }

      if (error) {
        throw new Error(`Erro ao consultar Supabase (${SUPABASE_LANCAMENTOS_TABLE}): ${error.message}`);
      }

      const fromSupabase = (data ?? []).map(lancamentoFromSupabase).filter(Boolean);
      const queue = await readPendingSyncQueue();
      const merged = applyPendingQueueToLancamentos(fromSupabase, queue);
      await writeLocalLancamentos(merged);
      triggerPendingSync();
      return merged;
    } catch (error) {
      console.warn(`[lancamentos] Fallback para arquivo local: ${error?.message || error}`);
    }
  }

  return readLocalLancamentos();
}

async function getLancamentoById(id) {
  const lancamentos = await getLancamentos();
  return lancamentos.find((item) => item.id === id) ?? null;
}

async function insertLancamento(lancamento) {
  const lancamentos = await readLocalLancamentos();
  lancamentos.push(lancamento);
  await writeLocalLancamentos(lancamentos);

  if (!SUPABASE_ENABLED) {
    return { item: lancamento, syncStatus: "synced" };
  }

  try {
    const payload = lancamentoToSupabase(lancamento);
    let { data, error } = await supabase
      .from(SUPABASE_LANCAMENTOS_TABLE)
      .insert(payload)
      .select("*")
      .single();

    if (error && isSupabaseSchemaError(error)) {
      warnSupabaseOnce("insert lancamento em modo legado", error);
      const legacyPayload = { ...payload };
      delete legacyPayload.project_code;
      ({ data, error } = await supabase
        .from(SUPABASE_LANCAMENTOS_TABLE)
        .insert(legacyPayload)
        .select("*")
        .single());
    }

    if (error) {
      throw new Error(error.message);
    }

    triggerPendingSync();
    return { item: lancamentoFromSupabase(data) ?? lancamento, syncStatus: "synced" };
  } catch (error) {
    await enqueuePendingSyncOperation("create", lancamento.id, lancamento, error?.message || error);
    triggerPendingSync();
    return {
      item: lancamento,
      syncStatus: "pending",
      syncMessage: "Falha temporaria no banco. Lancamento salvo localmente e pendente de sincronizacao.",
    };
  }
}

async function updateLancamentoById(id, lancamento) {
  const lancamentos = await readLocalLancamentos();
  const index = lancamentos.findIndex((item) => item.id === id);
  if (index === -1) return { item: null, syncStatus: "synced" };
  lancamentos[index] = lancamento;
  await writeLocalLancamentos(lancamentos);

  if (!SUPABASE_ENABLED) {
    return { item: lancamentos[index], syncStatus: "synced" };
  }

  try {
    const payload = lancamentoToSupabase(lancamento);
    let { data, error } = await supabase
      .from(SUPABASE_LANCAMENTOS_TABLE)
      .upsert(payload, { onConflict: "project_code,id" })
      .select("*")
      .maybeSingle();

    if (error && isSupabaseSchemaError(error)) {
      warnSupabaseOnce("upsert lancamento em modo legado", error);
      const legacyPayload = { ...payload };
      delete legacyPayload.project_code;
      ({ data, error } = await supabase
        .from(SUPABASE_LANCAMENTOS_TABLE)
        .upsert(legacyPayload, { onConflict: "id" })
        .select("*")
        .maybeSingle());
    }

    if (error) {
      throw new Error(error.message);
    }

    triggerPendingSync();
    return { item: data ? lancamentoFromSupabase(data) : lancamento, syncStatus: "synced" };
  } catch (error) {
    await enqueuePendingSyncOperation("update", id, lancamento, error?.message || error);
    triggerPendingSync();
    return {
      item: lancamento,
      syncStatus: "pending",
      syncMessage: "Falha temporaria no banco. Alteracao salva localmente e pendente de sincronizacao.",
    };
  }
}

async function deleteLancamentoById(id) {
  const lancamentos = await readLocalLancamentos();
  const filtered = lancamentos.filter((item) => item.id !== id);
  if (filtered.length === lancamentos.length) return { removed: false, syncStatus: "synced" };
  await writeLocalLancamentos(filtered);

  if (!SUPABASE_ENABLED) {
    return { removed: true, syncStatus: "synced" };
  }

  try {
    let { error } = await supabase
      .from(SUPABASE_LANCAMENTOS_TABLE)
      .delete()
      .eq("id", id)
      .eq("project_code", APP_PROJECT_CODE);

    if (error && isSupabaseSchemaError(error)) {
      warnSupabaseOnce("delete lancamento em modo legado", error);
      ({ error } = await supabase.from(SUPABASE_LANCAMENTOS_TABLE).delete().eq("id", id));
    }

    if (error) {
      throw new Error(error.message);
    }
    triggerPendingSync();
    return { removed: true, syncStatus: "synced" };
  } catch (error) {
    await enqueuePendingSyncOperation("delete", id, null, error?.message || error);
    triggerPendingSync();
    return {
      removed: true,
      syncStatus: "pending",
      syncMessage: "Falha temporaria no banco. Exclusao registrada e pendente de sincronizacao.",
    };
  }
}

function rowsToFormula(coluna, rows) {
  if (rows.length === 0) return "0";
  const refs = rows.map((row) => `${coluna}${row}`).join(",");
  return `SUM(${refs})`;
}

function parseJsonBody(req, res) {
  if (!req.body || typeof req.body !== "object") {
    res.status(400).json({ error: "Corpo da requisicao invalido." });
    return null;
  }
  return req.body;
}

app.use((req, res, next) => {
  for (const [header, value] of Object.entries(DEFAULT_SECURITY_HEADERS)) {
    res.setHeader(header, value);
  }

  res.setHeader("Content-Security-Policy", CONTENT_SECURITY_POLICY);

  if (process.env.NODE_ENV === "production" || req.secure) {
    res.setHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
  }

  if (req.path.startsWith("/api/")) {
    res.setHeader("Cache-Control", "no-store");
  }

  next();
});

app.use((req, res, next) => {
  const method = req.method.toUpperCase();
  const isStateChanging = method === "POST" || method === "PUT" || method === "PATCH" || method === "DELETE";

  if (!isStateChanging || !req.path.startsWith("/api/")) {
    next();
    return;
  }

  if (isTrustedRequestOrigin(req)) {
    next();
    return;
  }

  res.status(403).json({ error: "Origem da requisicao nao permitida." });
});

app.get("/login", (req, res) => {
  if (isAuthenticatedRequest(req)) {
    res.redirect("/");
    return;
  }
  res.sendFile(path.join(__dirname, "public", "login.html"));
});

app.get("/login.html", (_req, res) => {
  res.redirect("/login");
});

app.get("/api/auth/status", (req, res) => {
  const session = getAuthSessionFromRequest(req);
  if (!session) {
    res.json({ authenticated: false });
    return;
  }
  const permissions = getRolePermissions(session.role);
  res.json({
    authenticated: true,
    username: session.username,
    projectCode: APP_PROJECT_CODE,
    role: permissions.role,
    permissions,
    expiresAt: new Date(session.expiresAt).toISOString(),
  });
});

app.post("/api/auth/login", async (req, res) => {
  const body = parseJsonBody(req, res);
  if (!body) return;

  const username = String(body.username ?? "").trim();
  const password = String(body.password ?? "");
  if (isLoginRateLimited(req, username)) {
    res.status(429).json({
      error: "Muitas tentativas de login. Aguarde alguns minutos e tente novamente.",
    });
    return;
  }

  const authenticatedAccount = authenticateUser(username, password);
  const valid = Boolean(authenticatedAccount);

  if (!valid) {
    registerLoginAttempt(req, username, false);
    res.status(401).json({ error: "Credenciais invalidas." });
    return;
  }

  registerLoginAttempt(req, username, true);
  const token = await createAuthSession(authenticatedAccount);
  const permissions = getRolePermissions(authenticatedAccount.role);
  setAuthCookie(req, res, token);
  await writeAuditLog(req, "auth.login", "session", authenticatedAccount.username, null, {
    username: authenticatedAccount.username,
    role: permissions.role,
  });
  res.json({
    ok: true,
    authenticated: true,
    username: authenticatedAccount.username,
    projectCode: APP_PROJECT_CODE,
    role: permissions.role,
    permissions,
  });
});

app.post("/api/auth/logout", async (req, res) => {
  const session = getAuthSessionFromRequest(req);
  await removeAuthSessionByRequest(req);
  clearAuthCookie(req, res);
  if (session) {
    await writeAuditLog(req, "auth.logout", "session", session.sessionId, {
      username: session.username,
      role: session.role,
    }, null);
  }
  res.json({ ok: true });
});

app.use((req, res, next) => {
  const openPath =
    req.path === "/login" ||
    req.path === "/login.html" ||
    req.path === "/login.js" ||
    req.path.startsWith("/api/auth/");

  if (openPath) {
    next();
    return;
  }

  if (isAuthenticatedRequest(req)) {
    next();
    return;
  }

  if (req.path.startsWith("/api/")) {
    res.status(401).json({ error: "Nao autenticado. Faca login para continuar." });
    return;
  }

  res.redirect("/login");
});

app.use(
  express.static(path.join(__dirname, "public"), {
    etag: true,
    maxAge: 0,
    setHeaders(res, filePath) {
      if (filePath.endsWith(".html")) {
        res.setHeader("Cache-Control", "no-store");
        return;
      }
      if (/\.js$/i.test(filePath)) {
        // Evita stale bundle no cliente apos restart/deploy local.
        res.setHeader("Cache-Control", "no-store");
        return;
      }
      if (/\.(css|svg)$/i.test(filePath)) {
        res.setHeader("Cache-Control", "public, max-age=0, must-revalidate");
      }
    },
  })
);

app.get("/api/topicos", async (_req, res) => {
  const topicos = await getTopicos();
  res.json(topicos.map(topicoPublico));
});

app.post("/api/topicos", requireAnyRole([AUTH_ROLE_ADMIN]), async (req, res) => {
  const body = parseJsonBody(req, res);
  if (!body) return;

  const topicos = await getTopicos();
  const nomeValidation = validateBoundedString(body.nome, {
    fieldLabel: "Nome do topico",
    required: true,
    maxLength: FIELD_LIMITS.topicoNome,
  });
  if (!nomeValidation.ok) {
    res.status(400).json({ error: nomeValidation.error });
    return;
  }
  const nome = nomeValidation.value;

  const grupoValidation = validateBoundedString(body.grupo ?? "COMMUNICATIONS & PUBLICATIONS", {
    fieldLabel: "Grupo",
    required: true,
    maxLength: FIELD_LIMITS.topicoGrupo,
  });
  if (!grupoValidation.ok) {
    res.status(400).json({ error: grupoValidation.error });
    return;
  }
  const grupo = grupoValidation.value || "COMMUNICATIONS & PUBLICATIONS";
  const orcamentoProgramaBRL = toNumber(body.orcamentoProgramaBRL);
  if (!Number.isFinite(orcamentoProgramaBRL) || orcamentoProgramaBRL < 0) {
    res.status(400).json({ error: "Orcamento invalido." });
    return;
  }

  const incluirNoResumo = body.incluirNoResumo !== undefined ? Boolean(body.incluirNoResumo) : true;
  const permitirLancamento =
    body.permitirLancamento !== undefined ? Boolean(body.permitirLancamento) : grupo !== "TEAM HIRES";

  const usedIds = new Set(topicos.map((item) => String(item.id)));
  const requestedId = String(body.id ?? "").trim();
  const id = requestedId ? makeUniqueId(requestedId, usedIds) : makeUniqueId(nome, usedIds);
  const maxOrdem = topicos.reduce((acc, item) => Math.max(acc, Number(item.ordem ?? 0)), 0);
  const ordem = Number.isFinite(Number(body.ordem)) ? Number(body.ordem) : maxOrdem + 1;
  const templateRow = Number.isFinite(Number(body.templateRow)) ? Number(body.templateRow) : null;

  const novoTopico = {
    id,
    nome,
    grupo,
    templateRow,
    incluirNoResumo,
    permitirLancamento,
    ordem,
    orcamentoProgramaBRL: round2(orcamentoProgramaBRL),
  };

  topicos.push(novoTopico);
  try {
    await persistTopicos(topicos);
  } catch (error) {
    res.status(503).json({ error: error?.message || "Falha ao persistir topicos." });
    return;
  }
  await writeAuditLog(req, "topico.create", "topico", novoTopico.id, null, novoTopico);
  res.status(201).json(topicoPublico(novoTopico));
});

app.put("/api/topicos/:id", requireAnyRole([AUTH_ROLE_ADMIN]), async (req, res) => {
  const body = parseJsonBody(req, res);
  if (!body) return;

  const topicos = await getTopicos();
  const index = topicos.findIndex((item) => item.id === req.params.id);
  if (index === -1) {
    res.status(404).json({ error: "Topico nao encontrado." });
    return;
  }

  const atual = topicos[index];

  const nomeValidation = validateBoundedString(
    body.nome !== undefined ? body.nome : atual.nome,
    {
      fieldLabel: "Nome do topico",
      required: true,
      maxLength: FIELD_LIMITS.topicoNome,
    }
  );
  if (!nomeValidation.ok) {
    res.status(400).json({ error: nomeValidation.error });
    return;
  }
  const nome = nomeValidation.value;

  const orcamentoInput =
    body.orcamentoProgramaBRL !== undefined ? body.orcamentoProgramaBRL : atual.orcamentoProgramaBRL;
  const orcamentoProgramaBRL = toNumber(orcamentoInput);
  if (!Number.isFinite(orcamentoProgramaBRL) || orcamentoProgramaBRL < 0) {
    res.status(400).json({ error: "Orcamento invalido." });
    return;
  }

  const incluirNoResumo =
    body.incluirNoResumo !== undefined ? Boolean(body.incluirNoResumo) : Boolean(atual.incluirNoResumo);
  const permitirLancamento =
    body.permitirLancamento !== undefined
      ? Boolean(body.permitirLancamento)
      : Boolean(atual.permitirLancamento);

  const atualizado = {
    ...atual,
    nome,
    orcamentoProgramaBRL: round2(orcamentoProgramaBRL),
    incluirNoResumo,
    permitirLancamento,
  };
  topicos[index] = atualizado;

  try {
    await persistTopicos(topicos);
  } catch (error) {
    res.status(503).json({ error: error?.message || "Falha ao persistir topicos." });
    return;
  }
  await writeAuditLog(req, "topico.update", "topico", atualizado.id, atual, atualizado);
  res.json(topicoPublico(atualizado));
});

app.delete("/api/topicos/:id", requireAnyRole([AUTH_ROLE_ADMIN]), async (req, res) => {
  const topicId = String(req.params.id ?? "").trim();
  if (!topicId) {
    res.status(400).json({ error: "Topico invalido." });
    return;
  }

  const [topicos, lancamentos] = await Promise.all([getTopicos(), getLancamentos()]);
  const index = topicos.findIndex((item) => item.id === topicId);
  if (index === -1) {
    res.status(404).json({ error: "Topico nao encontrado." });
    return;
  }

  const linkedCount = lancamentos.reduce(
    (count, item) => count + (String(item?.topicoId ?? "") === topicId ? 1 : 0),
    0
  );
  if (linkedCount > 0) {
    res.status(409).json({
      error: `Nao e possivel remover. Este topico possui ${linkedCount} lancamento(s) vinculado(s).`,
    });
    return;
  }

  const removedTopic = topicos[index];
  topicos.splice(index, 1);
  try {
    await persistTopicos(topicos);
  } catch (error) {
    res.status(503).json({ error: error?.message || "Falha ao persistir topicos." });
    return;
  }

  await writeAuditLog(req, "topico.delete", "topico", topicId, removedTopic, null);
  res.json({ ok: true, removedId: topicId });
});

app.get("/api/filtros", async (_req, res) => {
  const lancamentos = await getLancamentos();
  const anoAtual = new Date().getFullYear();
  const anos = [...new Set(lancamentos.map((item) => Number(item.ano)).filter(Number.isFinite))];
  anos.push(anoAtual);
  anos.sort((a, b) => a - b);

  res.json({
    anos: [...new Set(anos)],
    anoAtual,
  });
});

app.get("/api/config/topicos-travados", (_req, res) => {
  res.json({
    teamHiresUnlocked: TEAM_HIRES_UNLOCKED,
  });
});

async function updateTeamHiresLock(req, res) {
  const body = parseJsonBody(req, res);
  if (!body) return;
  if (typeof body.teamHiresUnlocked !== "boolean") {
    res.status(400).json({ error: "teamHiresUnlocked deve ser booleano." });
    return;
  }

  const previous = TEAM_HIRES_UNLOCKED;
  TEAM_HIRES_UNLOCKED = body.teamHiresUnlocked;
  try {
    await saveTeamHiresConfig();
  } catch (error) {
    console.error("[config] Falha ao persistir topicos-travados:", error?.message || error);
    TEAM_HIRES_UNLOCKED = previous;
    res.status(503).json({ error: "Falha ao salvar configuracao. Tente novamente." });
    return;
  }
  await writeAuditLog(
    req,
    "config.team_hires_lock.update",
    "app_config",
    APP_PROJECT_CODE,
    { teamHiresUnlocked: previous },
    { teamHiresUnlocked: TEAM_HIRES_UNLOCKED }
  );
  res.json({
    teamHiresUnlocked: TEAM_HIRES_UNLOCKED,
  });
}

app.put("/api/config/topicos-travados", requireAnyRole([AUTH_ROLE_ADMIN]), updateTeamHiresLock);
app.post("/api/config/topicos-travados", requireAnyRole([AUTH_ROLE_ADMIN]), updateTeamHiresLock);

app.get("/api/lancamentos", async (req, res) => {
  const [topicos, lancamentos] = await Promise.all([getTopicos(), getLancamentos()]);
  const topicosMap = new Map(topicos.map((t) => [t.id, t]));
  const filters = parseFilters(req.query);

  const filtrados = filtrarLancamentos(lancamentos, filters)
    .map((item) => ({
      ...item,
      topicoNome: topicosMap.get(item.topicoId)?.nome ?? "Topico removido",
    }))
    .sort((a, b) => b.data.localeCompare(a.data));

  res.json({
    total: filtrados.length,
    items: filtrados,
  });
});

app.post("/api/lancamentos", requireAnyRole([AUTH_ROLE_ADMIN, AUTH_ROLE_EDITOR]), async (req, res) => {
  const body = parseJsonBody(req, res);
  if (!body) return;

  const topicos = await getTopicos();
  const topicoIdValidation = validateBoundedString(body.topicoId, {
    fieldLabel: "Topico",
    required: true,
    maxLength: 80,
  });
  if (!topicoIdValidation.ok) {
    res.status(400).json({ error: topicoIdValidation.error });
    return;
  }
  const topicoId = topicoIdValidation.value;
  const topico = topicos.find((item) => item.id === topicoId);

  if (!topico || !canLancarNoTopico(topico)) {
    res.status(400).json({ error: "Topico invalido ou bloqueado." });
    return;
  }

  if (!isIsoDate(body.data)) {
    res.status(400).json({ error: "Data invalida. Use YYYY-MM-DD." });
    return;
  }

  const descricaoValidation = validateBoundedString(body.descricao, {
    fieldLabel: "Descricao",
    required: true,
    maxLength: FIELD_LIMITS.descricao,
  });
  if (!descricaoValidation.ok) {
    res.status(400).json({ error: descricaoValidation.error });
    return;
  }
  const descricao = descricaoValidation.value;
  if (hasSpreadsheetFormulaPrefix(descricao)) {
    res.status(400).json({ error: "Descricao nao pode iniciar com formula de planilha." });
    return;
  }

  const valor = toNumber(body.valor);
  if (!Number.isFinite(valor) || valor <= 0) {
    res.status(400).json({ error: "Valor invalido." });
    return;
  }

  const fornecedorValidation = validateBoundedString(body.fornecedor ?? "", {
    fieldLabel: "Fornecedor",
    maxLength: FIELD_LIMITS.fornecedor,
  });
  if (!fornecedorValidation.ok) {
    res.status(400).json({ error: fornecedorValidation.error });
    return;
  }

  const responsavelValidation = validateBoundedString(body.responsavel ?? "", {
    fieldLabel: "Responsavel",
    maxLength: FIELD_LIMITS.responsavel,
  });
  if (!responsavelValidation.ok) {
    res.status(400).json({ error: responsavelValidation.error });
    return;
  }

  const fornecedor = fornecedorValidation.value;
  const responsavel = responsavelValidation.value;
  const { ano, semestre } = getAnoSemestre(body.data);

  const novo = {
    id: uuidv4(),
    topicoId,
    data: body.data,
    descricao,
    fornecedor,
    responsavel,
    valor: round2(valor),
    semestre,
    ano,
    criadoEm: new Date().toISOString(),
    atualizadoEm: new Date().toISOString(),
  };

  const result = await insertLancamento(novo);
  await writeAuditLog(req, "lancamento.create", "lancamento", result.item?.id ?? novo.id, null, result.item ?? novo);
  res.status(201).json({
    ...result.item,
    syncStatus: result.syncStatus,
    syncMessage: result.syncMessage ?? null,
  });
});

app.put("/api/lancamentos/:id", requireAnyRole([AUTH_ROLE_ADMIN, AUTH_ROLE_EDITOR]), async (req, res) => {
  const body = parseJsonBody(req, res);
  if (!body) return;

  const [topicos, existente] = await Promise.all([getTopicos(), getLancamentoById(req.params.id)]);

  if (!existente) {
    res.status(404).json({ error: "Lancamento nao encontrado." });
    return;
  }

  const topicoIdValidation = validateBoundedString(
    body.topicoId !== undefined ? body.topicoId : existente.topicoId,
    {
      fieldLabel: "Topico",
      required: true,
      maxLength: 80,
    }
  );
  if (!topicoIdValidation.ok) {
    res.status(400).json({ error: topicoIdValidation.error });
    return;
  }
  const topicoId = topicoIdValidation.value;
  const topico = topicos.find((item) => item.id === topicoId);
  if (!topico || !canLancarNoTopico(topico)) {
    res.status(400).json({ error: "Topico invalido ou bloqueado." });
    return;
  }

  const data = body.data ?? existente.data;
  if (!isIsoDate(data)) {
    res.status(400).json({ error: "Data invalida. Use YYYY-MM-DD." });
    return;
  }

  const descricaoValidation = validateBoundedString(
    body.descricao !== undefined ? body.descricao : existente.descricao,
    {
      fieldLabel: "Descricao",
      required: true,
      maxLength: FIELD_LIMITS.descricao,
    }
  );
  if (!descricaoValidation.ok) {
    res.status(400).json({ error: descricaoValidation.error });
    return;
  }
  const descricao = descricaoValidation.value;
  if (hasSpreadsheetFormulaPrefix(descricao)) {
    res.status(400).json({ error: "Descricao nao pode iniciar com formula de planilha." });
    return;
  }

  const valor = body.valor !== undefined ? toNumber(body.valor) : existente.valor;
  if (!Number.isFinite(valor) || valor <= 0) {
    res.status(400).json({ error: "Valor invalido." });
    return;
  }

  const fornecedorValidation = validateBoundedString(
    body.fornecedor !== undefined ? body.fornecedor : existente.fornecedor ?? "",
    {
      fieldLabel: "Fornecedor",
      maxLength: FIELD_LIMITS.fornecedor,
    }
  );
  if (!fornecedorValidation.ok) {
    res.status(400).json({ error: fornecedorValidation.error });
    return;
  }

  const responsavelValidation = validateBoundedString(
    body.responsavel !== undefined ? body.responsavel : existente.responsavel ?? "",
    {
      fieldLabel: "Responsavel",
      maxLength: FIELD_LIMITS.responsavel,
    }
  );
  if (!responsavelValidation.ok) {
    res.status(400).json({ error: responsavelValidation.error });
    return;
  }

  const { ano, semestre } = getAnoSemestre(data);

  const atualizado = {
    ...existente,
    topicoId,
    data,
    descricao,
    fornecedor: fornecedorValidation.value,
    responsavel: responsavelValidation.value,
    valor: round2(valor),
    ano,
    semestre,
    atualizadoEm: new Date().toISOString(),
  };

  const result = await updateLancamentoById(req.params.id, atualizado);
  if (!result.item) {
    res.status(404).json({ error: "Lancamento nao encontrado." });
    return;
  }
  await writeAuditLog(req, "lancamento.update", "lancamento", req.params.id, existente, result.item);
  res.json({
    ...result.item,
    syncStatus: result.syncStatus,
    syncMessage: result.syncMessage ?? null,
  });
});

app.delete("/api/lancamentos/:id", requireAnyRole([AUTH_ROLE_ADMIN, AUTH_ROLE_EDITOR]), async (req, res) => {
  const existente = await getLancamentoById(req.params.id);
  const result = await deleteLancamentoById(req.params.id);
  if (!result.removed) {
    res.status(404).json({ error: "Lancamento nao encontrado." });
    return;
  }
  await writeAuditLog(req, "lancamento.delete", "lancamento", req.params.id, existente, null);
  res.status(204).end();
});

app.get("/api/resumo", async (req, res) => {
  const [topicos, lancamentos] = await Promise.all([getTopicos(), getLancamentos()]);
  const filters = parseFilters(req.query);
  const resumo = montarResumo(topicos, lancamentos, filters);

  res.json({
    filtros: filters,
    ...resumo,
  });
});

app.get("/api/topicos/:id/detalhes", async (req, res) => {
  const [topicos, lancamentos] = await Promise.all([getTopicos(), getLancamentos()]);
  const topico = topicos.find((item) => item.id === req.params.id);

  if (!topico) {
    res.status(404).json({ error: "Topico nao encontrado." });
    return;
  }

  const filters = parseFilters(req.query);
  filters.topicoId = topico.id;

  const filtrados = filtrarLancamentos(lancamentos, filters).sort((a, b) => b.data.localeCompare(a.data));
  const total = round2(filtrados.reduce((sum, item) => sum + item.valor, 0));

  res.json({
    topico,
    filtros: filters,
    total,
    items: filtrados,
  });
});

app.get("/api/export/csv", async (req, res) => {
  const [topicos, lancamentos] = await Promise.all([getTopicos(), getLancamentos()]);
  const topicosOrdenados = [...topicos].sort(
    (a, b) =>
      (a.ordem ?? 0) - (b.ordem ?? 0) ||
      String(a.nome ?? "").localeCompare(String(b.nome ?? ""))
  );
  const topicosMap = new Map(topicosOrdenados.map((topico) => [topico.id, topico]));
  const filters = parseFilters(req.query);

  const linhas = filtrarLancamentos(lancamentos, filters).sort((a, b) => a.data.localeCompare(b.data));
  const header = [
    "Topico",
    "Data",
    "Descricao",
    "Fornecedor",
    "Responsavel",
    "Valor",
    "Semestre",
    "Ano",
  ];

  const body = linhas.map((item) => [
    topicLabelPt(topicosMap.get(item.topicoId)?.nome ?? item.topicoId),
    item.data,
    item.descricao,
    item.fornecedor ?? "",
    item.responsavel ?? "",
    item.valor.toFixed(2),
    item.semestre,
    String(item.ano),
  ]);

  const resumo = montarResumo(topicosOrdenados, lancamentos, filters);
  const resumoByTopico = new Map(resumo.rows.map((row) => [row.topicoId, row]));
  const resumoHeader = [
    "Topico",
    "Grupo",
    "Orcamento",
    "Despesas Anteriores",
    "Despesas Periodo",
    "Despesas Totais",
    "Saldo",
    "% Execucao",
  ];

  const resumoBody = topicosOrdenados
    .filter((topico) => topico?.incluirNoResumo !== false)
    .map((topico) => {
      const resumoRow = resumoByTopico.get(topico.id);
      const orcamento = round2(Number(resumoRow?.orcamentoProgramaBRL ?? topico.orcamentoProgramaBRL ?? 0));
      const anteriores = round2(Number(resumoRow?.despesasAnteriores ?? 0));
      const periodo = round2(Number(resumoRow?.despesasPeriodo ?? 0));
      const total = round2(Number(resumoRow?.despesasAteData ?? anteriores + periodo));
      const saldo = round2(Number(resumoRow?.saldoRemanescente ?? orcamento - total));
      const percentual =
        orcamento > 0
          ? round2((total / orcamento) * 100)
          : total > 0
          ? 999
          : 0;

      return [
        topicLabelPt(topico?.nome ?? topico.id),
        groupLabelPt(topico?.grupo || "SEM GRUPO"),
        orcamento.toFixed(2),
        anteriores.toFixed(2),
        periodo.toFixed(2),
        total.toFixed(2),
        saldo.toFixed(2),
        percentual.toFixed(2),
      ];
    });

  const csvRows = [
    header,
    ...body,
    [],
    ["Resumo por Topico"],
    resumoHeader,
    ...resumoBody,
  ];
  const csv = csvRows.map((row) => row.map(csvEscape).join(",")).join("\n");
  const fileName = `lancamentos_${new Date().toISOString().slice(0, 10)}.csv`;

  res.setHeader("Content-Type", "text/csv; charset=utf-8");
  res.setHeader("Content-Disposition", `attachment; filename="${fileName}"`);
  res.send(`\uFEFF${csv}`);
});

app.get("/api/export/pdf", async (req, res) => {
  const [topicos, lancamentos] = await Promise.all([getTopicos(), getLancamentos()]);
  const filters = parseFilters(req.query);

  const filtrados = filtrarLancamentos(lancamentos, filters).sort((a, b) => a.data.localeCompare(b.data));
  if (filtrados.length > PDF_EXPORT_MAX_ITEMS) {
    res.status(413).json({
      error: `Exportacao PDF limitada a ${PDF_EXPORT_MAX_ITEMS} lancamentos por vez. Refine os filtros.`,
    });
    return;
  }
  const topicosOrdenados = [...topicos].sort((a, b) => (a.ordem ?? 0) - (b.ordem ?? 0));
  const topicosResumo = topicosOrdenados.filter((topico) => topico?.incluirNoResumo !== false);
  const groupOrder = [
    "TEAM HIRES",
    "COMMUNICATIONS & PUBLICATIONS",
    "THIRD PARTY SERVICES",
  ];

  const lancamentosPorTopico = new Map();
  for (const item of filtrados) {
    if (!lancamentosPorTopico.has(item.topicoId)) {
      lancamentosPorTopico.set(item.topicoId, []);
    }
    lancamentosPorTopico.get(item.topicoId).push(item);
  }

  const topicosPorGrupo = new Map();
  for (const topico of topicosResumo) {
    const groupName = topico.grupo || "SEM GRUPO";
    if (!topicosPorGrupo.has(groupName)) {
      topicosPorGrupo.set(groupName, []);
    }
    topicosPorGrupo.get(groupName).push(topico);
  }

  const gruposExtras = [...topicosPorGrupo.keys()]
    .filter((groupName) => !groupOrder.includes(groupName))
    .sort((a, b) => a.localeCompare(b));
  const gruposOrdenados = [
    ...groupOrder.filter((groupName) => topicosPorGrupo.has(groupName)),
    ...gruposExtras,
  ];

  const resumoTopicos = new Map();
  for (const topico of topicosResumo) {
    const items = lancamentosPorTopico.get(topico.id) ?? [];
    const totalS1 = round2(
      items
        .filter((item) => item.semestre === "S1")
        .reduce((sum, item) => sum + item.valor, 0)
    );
    const totalS2 = round2(
      items
        .filter((item) => item.semestre === "S2")
        .reduce((sum, item) => sum + item.valor, 0)
    );
    const total = round2(totalS1 + totalS2);

    resumoTopicos.set(topico.id, {
      totalS1,
      totalS2,
      total,
      quantidade: items.length,
    });
  }

  const resumoGrupos = gruposOrdenados.map((grupo) => {
    const topicosDoGrupo = topicosPorGrupo.get(grupo) ?? [];
    const totalS1 = round2(
      topicosDoGrupo.reduce((sum, topico) => sum + (resumoTopicos.get(topico.id)?.totalS1 ?? 0), 0)
    );
    const totalS2 = round2(
      topicosDoGrupo.reduce((sum, topico) => sum + (resumoTopicos.get(topico.id)?.totalS2 ?? 0), 0)
    );
    const total = round2(totalS1 + totalS2);
    const quantidadeLancamentos = topicosDoGrupo.reduce(
      (sum, topico) => sum + (resumoTopicos.get(topico.id)?.quantidade ?? 0),
      0
    );

    return {
      grupo,
      totalS1,
      totalS2,
      total,
      quantidadeLancamentos,
      quantidadeTopicos: topicosDoGrupo.length,
    };
  });
  const resumoGrupoMap = new Map(resumoGrupos.map((row) => [row.grupo, row]));
  const totalGeral = round2(resumoGrupos.reduce((sum, row) => sum + row.total, 0));

  const fileName = `relatorio_${new Date().toISOString().slice(0, 10)}.pdf`;

  res.setHeader("Content-Type", "application/pdf");
  res.setHeader("Content-Disposition", `attachment; filename="${fileName}"`);

  const doc = new PDFDocument({ size: "A4", margin: 36 });
  doc.pipe(res);

  const palette = {
    topBar: "#123a43",
    topBarSoft: "#d4e6ea",
    sectionBar: "#1f5f70",
    groupBar: "#2a7f92",
    topicBar: "#eff5f8",
    cardBg: "#f5f9fc",
    cardBorder: "#d4e1ea",
    tableHeaderBg: "#e8eff5",
    tableHeaderText: "#173042",
    rowAlt: "#f9fcff",
    border: "#d9e3ea",
    text: "#1f2f3a",
    textMuted: "#5a6f7d",
  };

  const marginX = doc.page.margins.left;
  const marginBottom = doc.page.margins.bottom;
  const pageWidth = doc.page.width;
  const contentWidth = pageWidth - marginX * 2;
  const generatedAt = new Date().toLocaleString("pt-BR");
  let pageNumber = 1;
  const periodoEfetivo = getPeriodoEfetivo(filters, filtrados);
  const periodLabel = periodoEfetivo.label;

  function drawPageHeader(cover = false) {
    if (cover) {
      doc.save();
      doc.rect(0, 0, pageWidth, 98).fill(palette.topBar);
      doc
        .fillColor("#ffffff")
        .font("Helvetica-Bold")
        .fontSize(19)
        .text("Relatorio Financeiro por Grupo e Topico", marginX, 30, {
          width: contentWidth,
          lineBreak: false,
          ellipsis: true,
        });
      doc
        .fillColor(palette.topBarSoft)
        .font("Helvetica")
        .fontSize(10)
        .text("Fundacao Pio XII", marginX, 57, {
          width: contentWidth,
          lineBreak: false,
        });
      doc
        .fontSize(8)
        .text(`Gerado em ${generatedAt}`, marginX, 73, {
          width: contentWidth - 80,
          lineBreak: false,
        });
      doc
        .font("Helvetica-Bold")
        .text(`Pagina ${pageNumber}`, marginX, 73, {
          width: contentWidth,
          align: "right",
          lineBreak: false,
        });
      doc.restore();
      doc.y = 110;
      return;
    }

    doc.save();
    doc.rect(0, 0, pageWidth, 34).fill(palette.topBar);
    doc
      .fillColor("#ffffff")
      .font("Helvetica-Bold")
      .fontSize(9)
      .text("Relatorio Financeiro por Grupo e Topico", marginX, 12, {
        width: contentWidth - 90,
        lineBreak: false,
        ellipsis: true,
      });
    doc
      .fillColor(palette.topBarSoft)
      .font("Helvetica-Bold")
      .fontSize(8)
      .text(`Pagina ${pageNumber}`, marginX, 12, {
        width: contentWidth,
        align: "right",
        lineBreak: false,
      });
    doc.restore();
    doc.y = 44;
  }

  function addPage() {
    doc.addPage();
    pageNumber += 1;
    drawPageHeader(false);
  }

  function ensureSpace(requiredHeight, onPageBreak) {
    if (doc.y + requiredHeight <= doc.page.height - marginBottom) return;
    addPage();
    if (onPageBreak) onPageBreak();
  }

  function drawSectionTitle(title) {
    ensureSpace(30);
    const y = doc.y;
    doc.roundedRect(marginX, y, contentWidth, 22, 5).fill(palette.sectionBar);
    doc
      .fillColor("#ffffff")
      .font("Helvetica-Bold")
      .fontSize(10)
      .text(title, marginX + 10, y + 7, {
        width: contentWidth - 20,
        lineBreak: false,
        ellipsis: true,
      });
    doc.y = y + 30;
  }

  function drawMetaCards() {
    const cards = [
      { label: "Ano", value: filters.ano ?? "Todos" },
      { label: "Semestre", value: filters.semestre ?? "Todos" },
      { label: "Periodo", value: periodLabel },
      {
        label: "Lancamentos",
        value: `${filtrados.length} itens | Total ${formatCurrency(totalGeral)}`,
      },
    ];

    const gap = 8;
    const cardHeight = 46;
    const cardWidth = (contentWidth - gap * (cards.length - 1)) / cards.length;
    ensureSpace(cardHeight + 10);
    const baseY = doc.y;

    for (let index = 0; index < cards.length; index += 1) {
      const card = cards[index];
      const x = marginX + index * (cardWidth + gap);
      doc
        .roundedRect(x, baseY, cardWidth, cardHeight, 5)
        .fillAndStroke(palette.cardBg, palette.cardBorder);
      doc
        .fillColor(palette.textMuted)
        .font("Helvetica")
        .fontSize(7)
        .text(card.label, x + 8, baseY + 8, {
          width: cardWidth - 16,
          lineBreak: false,
          ellipsis: true,
        });
      doc
        .fillColor(palette.text)
        .font("Helvetica-Bold")
        .fontSize(9)
        .text(card.value, x + 8, baseY + 20, {
          width: cardWidth - 16,
          lineBreak: false,
          ellipsis: true,
        });
    }

    doc.y = baseY + cardHeight + 12;
  }

  function drawTableHeader(columns) {
    const height = 20;
    ensureSpace(height + 1);
    const y = doc.y;
    doc.rect(marginX, y, contentWidth, height).fill(palette.tableHeaderBg);

    let x = marginX;
    doc.fillColor(palette.tableHeaderText).font("Helvetica-Bold").fontSize(8);
    for (const col of columns) {
      doc.text(col.label, x + 4, y + 6, {
        width: col.width - 8,
        align: col.align ?? "left",
        lineBreak: false,
        ellipsis: true,
      });
      x += col.width;
      doc.moveTo(x, y).lineTo(x, y + height).lineWidth(0.4).strokeColor(palette.border).stroke();
    }
    doc.rect(marginX, y, contentWidth, height).lineWidth(0.5).strokeColor(palette.border).stroke();
    doc.y = y + height;
  }

  function drawTableRow(columns, values, options = {}) {
    const height = options.height ?? 18;
    ensureSpace(height + 1, options.onPageBreak);
    const y = doc.y;

    if (options.fill) {
      doc.rect(marginX, y, contentWidth, height).fill(options.fill);
    }

    let x = marginX;
    doc
      .fillColor(options.textColor ?? palette.text)
      .font(options.bold ? "Helvetica-Bold" : "Helvetica")
      .fontSize(options.fontSize ?? 8);

    for (let index = 0; index < columns.length; index += 1) {
      const col = columns[index];
      const value = String(values[index] ?? "");
      doc.text(value, x + 4, y + 5, {
        width: col.width - 8,
        align: col.align ?? "left",
        lineBreak: false,
        ellipsis: true,
      });
      x += col.width;
      doc.moveTo(x, y).lineTo(x, y + height).lineWidth(0.35).strokeColor(palette.border).stroke();
    }

    doc.rect(marginX, y, contentWidth, height).lineWidth(0.35).strokeColor(palette.border).stroke();
    doc.y = y + height;
  }

  function drawGroupHeader(groupName, groupStats, compact = false) {
    const height = compact ? 20 : 22;
    ensureSpace(height + 6);
    const y = doc.y;
    doc
      .roundedRect(marginX, y, contentWidth, height, 5)
      .fill(compact ? "#327f90" : palette.groupBar);
    doc
      .fillColor("#ffffff")
      .font("Helvetica-Bold")
      .fontSize(compact ? 8 : 9)
      .text(groupName, marginX + 10, y + (compact ? 6 : 7), {
        width: contentWidth - 220,
        lineBreak: false,
        ellipsis: true,
      });
    doc
      .text(
        `Topicos ${groupStats.quantidadeTopicos} | Lanc. ${groupStats.quantidadeLancamentos} | Total ${formatCurrency(
          groupStats.total
        )}`,
        marginX + 210,
        y + (compact ? 6 : 7),
        {
          width: contentWidth - 220,
          align: "right",
          lineBreak: false,
          ellipsis: true,
        }
      );
    doc.y = y + height + 6;
  }

  function drawTopicHeader(groupName, topicoNome, stats, compact = false) {
    const height = compact ? 18 : 20;
    ensureSpace(height + 4);
    const y = doc.y;
    doc
      .roundedRect(marginX, y, contentWidth, height, 4)
      .fill(compact ? "#f4f8fb" : palette.topicBar);
    doc
      .fillColor(palette.text)
      .font("Helvetica-Bold")
      .fontSize(compact ? 8 : 9)
      .text(topicoNome, marginX + 8, y + (compact ? 5 : 6), {
        width: contentWidth - 220,
        lineBreak: false,
        ellipsis: true,
      });
    doc
      .fillColor(palette.textMuted)
      .font("Helvetica-Bold")
      .fontSize(8)
      .text(
        `S1 ${formatCurrency(stats.totalS1)} | S2 ${formatCurrency(stats.totalS2)} | Total ${formatCurrency(
          stats.total
        )}`,
        marginX + 210,
        y + (compact ? 5 : 6),
        {
          width: contentWidth - 220,
          align: "right",
          lineBreak: false,
          ellipsis: true,
        }
      );

    if (compact) {
      doc
        .fillColor(palette.textMuted)
        .font("Helvetica")
        .fontSize(7)
        .text(groupName, marginX + 8, y + 13, {
          width: contentWidth - 16,
          lineBreak: false,
          ellipsis: true,
        });
      doc.y = y + height + 5;
      return;
    }

    doc.y = y + height + 4;
  }

  drawPageHeader(true);
  drawMetaCards();

  drawSectionTitle("Resumo por Grupo");
  const groupColumns = [
    { label: "Grupo", width: contentWidth - 334 },
    { label: "S1", width: 92, align: "right" },
    { label: "S2", width: 92, align: "right" },
    { label: "Total", width: 100, align: "right" },
    { label: "Lanc.", width: 50, align: "right" },
  ];
  drawTableHeader(groupColumns);

  resumoGrupos.forEach((row, index) => {
    drawTableRow(
      groupColumns,
      [
        groupLabelPt(row.grupo),
        formatCurrency(row.totalS1),
        formatCurrency(row.totalS2),
        formatCurrency(row.total),
        String(row.quantidadeLancamentos),
      ],
      { fill: index % 2 === 0 ? "#ffffff" : palette.rowAlt }
    );
  });

  drawTableRow(
    groupColumns,
    [
      "TOTAL GERAL",
      formatCurrency(resumoGrupos.reduce((sum, row) => sum + row.totalS1, 0)),
      formatCurrency(resumoGrupos.reduce((sum, row) => sum + row.totalS2, 0)),
      formatCurrency(totalGeral),
      String(filtrados.length),
    ],
    { fill: "#edf4fa", bold: true }
  );

  doc.moveDown(0.4);
  drawSectionTitle("Detalhamento por Grupo > Topico > Lancamentos");

  const detailColumns = [
    { label: "Data", width: 64 },
    { label: "Descricao", width: 160 },
    { label: "Fornecedor", width: 84 },
    { label: "Responsavel", width: 84 },
    { label: "Sem", width: 40, align: "center" },
    { label: "Valor", width: 91, align: "right" },
  ];

  for (const groupName of gruposOrdenados) {
    const groupStats = resumoGrupoMap.get(groupName);
    const topicosDoGrupo = topicosPorGrupo.get(groupName) ?? [];
    const groupDisplay = truncateText(groupLabelPt(groupName), 90);
    drawGroupHeader(groupDisplay, groupStats);

    for (const topico of topicosDoGrupo) {
      const stats = resumoTopicos.get(topico.id) ?? {
        totalS1: 0,
        totalS2: 0,
        total: 0,
        quantidade: 0,
      };
      const items = lancamentosPorTopico.get(topico.id) ?? [];
      const topicDisplay = truncateText(topicLabelPt(topico.nome), 90);
      drawTopicHeader(groupDisplay, topicDisplay, stats);

      if (items.length === 0) {
        ensureSpace(16);
        const y = doc.y;
        doc
          .fillColor(palette.textMuted)
          .font("Helvetica-Oblique")
          .fontSize(8)
          .text("Sem lancamentos para este topico nos filtros selecionados.", marginX + 10, y + 1, {
            width: contentWidth - 20,
          });
        doc.y = y + 15;
        doc.moveDown(0.25);
        continue;
      }

      drawTableHeader(detailColumns);

      items.forEach((item, index) => {
        drawTableRow(
          detailColumns,
          [
            formatDateBr(item.data),
            truncateText(item.descricao, PDF_TEXT_MAX_CHARS),
            truncateText(item.fornecedor || "-", 70),
            truncateText(item.responsavel || "-", 70),
            item.semestre,
            formatCurrency(item.valor),
          ],
          {
            fill: index % 2 === 0 ? "#ffffff" : palette.rowAlt,
            onPageBreak: () => {
              drawGroupHeader(groupDisplay, groupStats, true);
              drawTopicHeader(groupDisplay, `${topicDisplay} (continua)`, stats, true);
              drawTableHeader(detailColumns);
            },
          }
        );
      });

      doc.moveDown(0.3);
    }

    doc.moveDown(0.4);
  }

  doc.end();
});

app.get("/api/export/excel", async (req, res) => {
  if (!fs.existsSync(TEMPLATE_FILE)) {
    res.status(500).json({ error: "Template Excel nao encontrado em templates/fundacao-template.xlsx" });
    return;
  }

  const [topicos, lancamentos] = await Promise.all([getTopicos(), getLancamentos()]);
  const filters = parseFilters(req.query);
  const lancamentosFiltrados = filtrarLancamentos(lancamentos, filters);
  const periodoEfetivo = getPeriodoEfetivo(filters, lancamentosFiltrados);
  const resumo = montarResumo(topicos, lancamentos, filters);
  const resumoByTopico = new Map(resumo.rows.map((row) => [row.topicoId, row]));

  const workbook = await XlsxPopulate.fromFileAsync(TEMPLATE_FILE);
  const sheet = workbook.sheet("Expenditure");

  const mappedIncluded = [];
  const mappedExcluded = [];
  const extrasIncluded = [];

  for (const topico of topicos) {
    const incluirNoResumo = topico?.incluirNoResumo !== false;
    const templateRow = Number.isFinite(Number(topico?.templateRow)) ? Number(topico.templateRow) : null;

    if (templateRow && templateRow > 0) {
      if (incluirNoResumo) {
        mappedIncluded.push({ ...topico, templateRow });
      } else {
        mappedExcluded.push({ ...topico, templateRow });
      }
      continue;
    }

    if (incluirNoResumo) {
      extrasIncluded.push(topico);
    }
  }

  function buildResumoMetric(topico, resumoRow) {
    const budget = round2(Number(resumoRow?.orcamentoProgramaBRL ?? topico.orcamentoProgramaBRL ?? 0));
    const prior = round2(Number(resumoRow?.despesasAnteriores ?? 0));
    const current = round2(Number(resumoRow?.despesasPeriodo ?? 0));
    const total = round2(Number(resumoRow?.despesasAteData ?? prior + current));
    const balance = round2(Number(resumoRow?.saldoRemanescente ?? budget - total));
    const percent =
      budget > 0
        ? round2((total / budget) * 100)
        : total > 0
        ? 999
        : 0;
    return { budget, prior, current, total, balance, percent };
  }

  for (const topico of mappedIncluded) {
    const row = topico.templateRow;
    const resumoRow = resumoByTopico.get(topico.id);
    const metric = buildResumoMetric(topico, resumoRow);

    sheet.cell(`B${row}`).value(metric.budget);
    sheet.cell(`C${row}`).value(metric.prior);
    sheet.cell(`D${row}`).value(metric.current);
    sheet.cell(`E${row}`).formula(`+C${row}+D${row}`);
    sheet.cell(`F${row}`).formula(`+B${row}-E${row}`);
    sheet.cell(`G${row}`).formula(`IF(B${row}=0,0,E${row}/B${row}*100)`);
  }

  for (const topico of mappedExcluded) {
    const row = topico.templateRow;
    sheet.range(`B${row}:G${row}`).value([[null, null, null, null, null, null]]);
  }

  const TABLE_COLUMNS = ["A", "B", "C", "D", "E", "F", "G"];
  const EXTRA_START_ROW = 31;
  const BASE_TOTAL_ROW = 32;

  const extraTemplateStyleIds = TABLE_COLUMNS.map((col) => sheet.cell(`${col}${EXTRA_START_ROW}`)._styleId);
  const extraTemplateRowHeight = sheet.row(EXTRA_START_ROW).height();
  const totalTemplateStyleIds = TABLE_COLUMNS.map((col) => sheet.cell(`${col}${BASE_TOTAL_ROW}`)._styleId);
  const totalTemplateRowHeight = sheet.row(BASE_TOTAL_ROW).height();
  const totalTemplateLabel = sheet.cell(`A${BASE_TOTAL_ROW}`).value();

  function clearRowCells(rowNumber) {
    sheet.range(`A${rowNumber}:G${rowNumber}`).value([[null, null, null, null, null, null, null]]);
  }

  function copyRowCells(sourceRow, targetRow) {
    for (const col of TABLE_COLUMNS) {
      const sourceCell = sheet.cell(`${col}${sourceRow}`);
      const targetCell = sheet.cell(`${col}${targetRow}`);
      targetCell._styleId = sourceCell._styleId;
      const formula = sourceCell.formula();
      if (formula && formula !== "SHARED") {
        targetCell.formula(formula);
      } else {
        targetCell.value(sourceCell.value());
      }
    }

    const sourceRowHeight = sheet.row(sourceRow).height();
    if (sourceRowHeight !== undefined && sourceRowHeight !== null) {
      sheet.row(targetRow).height(sourceRowHeight);
    }
  }

  function applyExtraTemplateRow(rowNumber) {
    for (let i = 0; i < TABLE_COLUMNS.length; i += 1) {
      sheet.cell(`${TABLE_COLUMNS[i]}${rowNumber}`)._styleId = extraTemplateStyleIds[i];
    }
    if (extraTemplateRowHeight !== undefined && extraTemplateRowHeight !== null) {
      sheet.row(rowNumber).height(extraTemplateRowHeight);
    }
  }

  function applyTotalTemplateRow(rowNumber) {
    for (let i = 0; i < TABLE_COLUMNS.length; i += 1) {
      sheet.cell(`${TABLE_COLUMNS[i]}${rowNumber}`)._styleId = totalTemplateStyleIds[i];
    }
    if (totalTemplateRowHeight !== undefined && totalTemplateRowHeight !== null) {
      sheet.row(rowNumber).height(totalTemplateRowHeight);
    }
  }

  // A linha 31 ja existe no template para overflow.
  // Quando houver mais de 1 topico extra, deslocamos o bloco abaixo (total + certificacao)
  // para abrir espaco e listar cada topico extra em sua propria linha na Expenditure.
  const extraOverflowRows = Math.max(0, extrasIncluded.length - 1);
  if (extraOverflowRows > 0) {
    const movableStartRow = BASE_TOTAL_ROW + 1;
    const usedRange = sheet.usedRange();
    const usedEndRow = Math.max(
      movableStartRow,
      Number(usedRange?.endCell()?.rowNumber?.() ?? 44),
      44
    );

    for (let row = usedEndRow; row >= movableStartRow; row -= 1) {
      copyRowCells(row, row + extraOverflowRows);
    }
    for (let row = movableStartRow; row < movableStartRow + extraOverflowRows; row += 1) {
      clearRowCells(row);
    }
  }

  if (extrasIncluded.length === 0) {
    clearRowCells(EXTRA_START_ROW);
  } else {
    extrasIncluded.forEach((topico, index) => {
      const row = EXTRA_START_ROW + index;
      applyExtraTemplateRow(row);
      clearRowCells(row);

      const resumoRow = resumoByTopico.get(topico.id);
      const metric = buildResumoMetric(topico, resumoRow);
      sheet.cell(`A${row}`).value(String(topico?.nome ?? topico?.id ?? "Topico extra"));
      sheet.cell(`B${row}`).value(metric.budget);
      sheet.cell(`C${row}`).value(metric.prior);
      sheet.cell(`D${row}`).value(metric.current);
      sheet.cell(`E${row}`).formula(`+C${row}+D${row}`);
      sheet.cell(`F${row}`).formula(`+B${row}-E${row}`);
      sheet.cell(`G${row}`).formula(`IF(B${row}=0,0,E${row}/B${row}*100)`);
    });
  }

  const totalRow = BASE_TOTAL_ROW + extraOverflowRows;
  const totalStartRow = 14;
  const totalEndRow = totalRow - 1;
  applyTotalTemplateRow(totalRow);
  sheet
    .cell(`A${totalRow}`)
    .value(totalTemplateLabel ?? "Total Budget and Expenditure");
  sheet.cell(`B${totalRow}`).formula(`SUM(B${totalStartRow}:B${totalEndRow})`);
  sheet.cell(`C${totalRow}`).formula(`SUM(C${totalStartRow}:C${totalEndRow})`);
  sheet.cell(`D${totalRow}`).formula(`SUM(D${totalStartRow}:D${totalEndRow})`);
  sheet.cell(`E${totalRow}`).formula(`SUM(E${totalStartRow}:E${totalEndRow})`);
  sheet.cell(`F${totalRow}`).formula(`SUM(F${totalStartRow}:F${totalEndRow})`);
  sheet.cell(`G${totalRow}`).formula(`IF(B${totalRow}=0,0,E${totalRow}/B${totalRow}*100)`);

  let extrasSheet = workbook.sheet("Topicos Extras");
  if (!extrasSheet) {
    extrasSheet = workbook.addSheet("Topicos Extras");
  }

  if (extrasSheet.usedRange()) {
    extrasSheet.usedRange().clear();
  }

  extrasSheet.range("A1:H1").value([
    [
      "Topico",
      "Grupo",
      "Orcamento",
      "Despesas Anteriores",
      "Despesas Periodo",
      "Despesas Totais",
      "Saldo",
      "% Execucao",
    ],
  ]);

  if (extrasIncluded.length === 0) {
    extrasSheet.cell("A2").value("Sem topicos extras incluidos no resumo.");
  } else {
    extrasIncluded.forEach((topico, index) => {
      const rowIndex = index + 2;
      const resumoRow = resumoByTopico.get(topico.id);
      const metric = buildResumoMetric(topico, resumoRow);
      extrasSheet.range(`A${rowIndex}:H${rowIndex}`).value([
        [
          String(topico?.nome ?? topico?.id ?? ""),
          String(topico?.grupo ?? ""),
          metric.budget,
          metric.prior,
          metric.current,
          metric.total,
          metric.balance,
          metric.percent,
        ],
      ]);
    });
  }

  if (periodoEfetivo.inicio) {
    sheet.cell("G4").value(new Date(`${periodoEfetivo.inicio}T00:00:00`));
  } else {
    sheet.cell("G4").value(null);
  }

  if (periodoEfetivo.fim) {
    sheet.cell("G7").value(new Date(`${periodoEfetivo.fim}T00:00:00`));
  } else {
    sheet.cell("G7").value(null);
  }

  const output = await workbook.outputAsync();
  const fileName = `Fundacao_Expenditure_Atualizado_${new Date().toISOString().slice(0, 10)}.xlsx`;

  res.setHeader(
    "Content-Type",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
  );
  res.setHeader("Content-Disposition", `attachment; filename="${fileName}"`);
  res.send(Buffer.from(output));
});

app.get("/api/health", (req, res) => {
  const session = getAuthSessionFromRequest(req);
  const diagnosticsAllowed = Boolean(session?.permissions?.canViewDiagnostics);

  if (!diagnosticsAllowed) {
    res.json({ ok: true });
    return;
  }

  res.json({
    ok: true,
    projectCode: APP_PROJECT_CODE,
    persistencia: SUPABASE_ENABLED ? "supabase" : "arquivo_local",
    tabelas: SUPABASE_ENABLED
      ? {
          lancamentos: SUPABASE_LANCAMENTOS_TABLE,
          topicos: SUPABASE_TOPICOS_TABLE,
          appConfig: SUPABASE_APP_CONFIG_TABLE,
          authSessions: SUPABASE_AUTH_SESSIONS_TABLE,
          auditLog: SUPABASE_AUDIT_LOG_TABLE,
        }
      : null,
    trustProxy: TRUST_PROXY_SETTING,
  });
});

app.use("/api", (_req, res) => {
  res.status(404).json({ error: "Rota de API nao encontrada." });
});

app.use((_req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

export async function createServerApp() {
  await ensureStorage();
  ensurePendingSyncWorker();
  triggerPendingSync();
  return app;
}

export async function startServer(port = PORT) {
  await ensureStorage();
  ensurePendingSyncWorker();
  triggerPendingSync();
  return new Promise((resolve) => {
    const server = app.listen(port, () => {
      console.log(`Servidor iniciado em http://localhost:${port}`);
      resolve(server);
    });
  });
}

const currentFile = path.resolve(fileURLToPath(import.meta.url));
const entryFile = process.argv[1] ? path.resolve(process.argv[1]) : "";
if (currentFile === entryFile) {
  await startServer(PORT);
}
